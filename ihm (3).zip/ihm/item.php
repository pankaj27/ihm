<?php include('action/item_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php if($case == "list"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		<?php
        		if($item_w==0 ){}else{ ?> <a class="btn custom_border" href="<?php inventory_display(ROOT_PATH)?>/additem"><i class="fa fa-plus" aria-hidden="true"></i> Add Item</a> <?php  }  ?>
								
			
				</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Item List</h2>
        </header>
        <div class="card-body">
        	 <table class="table table-bordered table-striped mb-0" id="datatable_with_search">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Unit</th>
                        <th>Price</th>
                        <th>Category</th>
                        <th>Subcategory</th>
                        <th>Suplied Vendor</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "add"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> Add Item</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" action = "<?php inventory_display(ROOT_PATH)?>/additem" >
            	<div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" required="required"  name = "item_name" value="<?php inventory_display($item_name)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Category<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "category" id ="item_category">
                            <option value="">Select</option>
                            <?php foreach($category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $category){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row" id="sub_category_div">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Subcategory<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "subcategory">
                            <option value="">Select</option>
                            <?php foreach($sub_category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $subcategory){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row" >
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Unit<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "item_unit">
                            <option value="">Select</option>
                            <?php foreach($unit_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $item_unit){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Price<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="price" name = "price" value="<?php inventory_display($price)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service_name">Is Stockable<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <div class="switch switch-sm switch-primary">
                            <input type="checkbox" name="is_stockable" id="is_stockable" data-plugin-ios-switch <?php if($is_stockable == '1'){?>  checked="checked" <?php }?> />
                        </div>
                    </div>
                </div>
                <div id="sotockable_div" <?php if($is_stockable != "1"){?> class ="display_none" <?php } ?>>
                	<div class="form-group row">
                        <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Stock<span class="required">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control" id="stock" name = "stock" value="<?php inventory_display($stock)?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Alert Quantity<span class="required">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control" id="alert_quantity" name = "alert_quantity" value="<?php inventory_display($alert_quantity)?>">
                        </div>
                    </div>
                </div>
                <br>
                <div class="form-group row" >
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Tax<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "tax">
                            <option value="">Select</option>
                            <?php foreach($tax_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $tax){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <!----- vendor for ---->
                
                <div class="form-group row" >
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Vedor<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select class="form-control populate" name = "vendors[]"  data-plugin-multiselect data-plugin-options='{ "maxHeight": 200 }' id="ms_example0">
                            
                            <?php foreach($vendor_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" ><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                
                <!-------------------------->
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_item">Add Item</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>
<?php if($case == "edit"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> Edit Item</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post"  action = "<?php inventory_display(ROOT_PATH)?>/updateitem" >
            	<div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" required="required"  name = "item_name" value="<?php inventory_display($item_name)?>">
                        <input type="hidden" name="itemid" value="<?php  echo $item_id ; ?>"/>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Category<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "category" id ="item_category2" onchange="getsubcate()">
                            <option value="">Select</option>
                            <?php foreach($category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $category){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row" id="sub_category_div">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Subcategory<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "subcategory" id="subcate">
                            <option value="">Select</option>
                            <?php foreach($sub_category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $subcategory){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row" >
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Unit<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "item_unit">
                            <option value="">Select</option>
                            <?php foreach($unit_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $item_unit){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Price<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="price" name = "price" value="<?php inventory_display($price)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service_name">Is Stockable<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <div class="switch switch-sm switch-primary">
                            <input type="checkbox" name="is_stockable" id="is_stockable" data-plugin-ios-switch <?php if($is_stockable == '1'){?>  checked="checked" <?php }?> />
                        </div>
                    </div>
                </div>
                <div id="sotockable_div" <?php if($is_stockable != "1"){?> class ="display_none" <?php } ?>>
                	<div class="form-group row">
                        <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Stock<span class="required">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control" id="stock" name = "stock" value="<?php inventory_display($stock)?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Alert Quantity<span class="required">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control" id="alert_quantity" name = "alert_quantity" value="<?php inventory_display($alert_quantity)?>">
                        </div>
                    </div>
                </div>
                <br>
                <div class="form-group row" >
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Tax<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "tax">
                            <option value="">Select</option>
                            <?php foreach($tax_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $tax){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <?php if(isset($vendoredit) && !empty($vendoredit)){ ?>
                	<?php $vendoredites=explode(",",$vendoredit); ?>
                <div class="form-group row" >
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Vedor<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select class="form-control populate" name = "vendors[]" data-plugin-multiselect data-plugin-options='{ "maxHeight": 200 }' id="ms_example0">
                            
                            <?php foreach($vendor_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if(in_array($key,$vendoredites)){ echo "selected"; } ?>  ><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                
                <?php  }else{ ?>
                	
                	
                	<div class="form-group row" >
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Vedor<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select class="form-control populate" name = "vendors[]" multiple="multiple" data-plugin-multiselect data-plugin-options='{ "maxHeight": 200 }' id="ms_example0">
                            
                            <?php foreach($vendor_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" ><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                	
                	
                	
                <?php  } ?>
                
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service_name">Isactive<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <div class="switch switch-sm switch-primary">
                            <input type="checkbox" name="is_active" data-plugin-ios-switch <?php if($is_active == '1'){?>  checked="checked" <?php }?> />
                        </div>
                    </div>
                </div>
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_item">Update Item</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>
<script>
	
	function getsubcate(){
		var cat=$("#item_category2").val();
		
		$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getsubcat.php",
  			data :{'cat':cat},
  			success : function(data){
  				$("#subcate").html(data);
  				 
  				}
  			
          }); 
		
	}
</script>