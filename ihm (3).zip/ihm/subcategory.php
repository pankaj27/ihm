<?php include('action/subcategory_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php if($case == "list"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		
        		<?php 	if($subcat_w==0 ){ }else{ ?>
				<a class="btn custom_border" href="<?php inventory_display(ROOT_PATH)?>/addsubcategory"><i class="fa fa-plus" aria-hidden="true"></i> Add Subcategory</a>
			<?php } ?>
				
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Subcategory List</h2>
        </header>
        <div class="card-body">
        	 <table class="table table-bordered table-striped mb-0" id="datatable_with_search">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "add"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> Add Subcategory</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="add_subcategory_form" action = "<?php inventory_display(ROOT_PATH)?>/addsubcategory" >
            	<div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Category<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "category">
                            <option value="">Select</option>
                            <?php foreach($category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $category){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            	 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="subcategory_name" name = "subcategory_name" value="<?php inventory_display($subcategory_name)?>">
                    </div>
                </div>
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_subcategory">Add Subcategory</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>
<?php if($case == "edit"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Subcategory</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="edit_subcategory_form" action = "<?php inventory_display(ROOT_PATH)?>/updatesubcategory" >
            	<div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Category<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "category" disabled>
                            <option value="">Select</option>
                            <?php foreach($category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $category){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            	 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="subcategory_name" name = "subcategory_name" value="<?php inventory_display($subcategory_name)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service_name">Isactive<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <div class="switch switch-sm switch-primary">
                            <input type="checkbox" name="is_active" data-plugin-ios-switch <?php if($is_active == '1'){?>  checked="checked" <?php }?> />
                        </div>
                    </div>
                </div>
                <input type="hidden" id="sub_category_id" name = "sub_category_id" value="<?php inventory_display(track64_encode($sub_category_id))?>">
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="edit_subcategory">Edit Subcategory</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>