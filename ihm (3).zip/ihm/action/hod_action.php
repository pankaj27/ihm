<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		 
		 $sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $hod_r=$rst_rw['hod_r'];
		 $hod_w=$rst_rw['hod_w'];
		 $hod_d=$rst_rw['hod_d'];
		
		if($hod_r==0 && $hod_w==0 && $hod_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		 
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
		 * */
	}else{
		//echo 2;
		include("nopermission.php");
		exit();
	}
	if($case == "delete"){
		if($hod_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$hodid = track64_decode(inventory_get_get('hod_id'));
		
		$select_department_query = "SELECT * FROM `tbl_hod`  WHERE `fld_ai_id` = '".$hodid."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$sql="delete from `tbl_hod`  WHERE `fld_ai_id` = '".$hodid."'";
			$qry = inventory_query($sql);
			$succee_msg = "HOD Successfully Deleted";
			$case = "list";
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "edit"){
		if($hod_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$hodid = track64_decode(inventory_get_get('hod_id'));
		
		$select_department_query = "SELECT * FROM `tbl_hod`  WHERE `fld_ai_id` = '".$hodid."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$row_data = inventory_fetch_assoc($select_department_query_result);
			//$hodid = $row_data['fld_department_id'];
			//$dept_name = $row_data['fld_department'];
			  $hodid=$row_data['fld_hod_id'];
				$depid=$row_data['dep_id'];
				$hodnam=$row_data['fld_hod_name'];
				$username=$row_data['fld_hod_username'];
				$pass=$row_data['fld_hod_password'];
			   //$user_ai_id=$row_data['fld_ai_id'];
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "update"){
		if($hod_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$hod_id = "";
		$hod_name = "";
		$hod_user="";
		$hod_pass="";
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('update_hod')){	
			 $hod_id = inventory_get_post_escape('hod_id');
			 $hod_name = inventory_get_post_escape('hod_name');
			 $hod_user = inventory_get_post_escape('hod_user');
			 $hod_pass = inventory_get_post_escape('hod_pass');
			  //$hod_dep = inventory_get_post_escape('hod_dep');
			  $hodd_id= inventory_get_post_escape('hod_idd');
			   $hod_dep =implode(",",$_POST['hod_dep']) ;
			  
			  if(inventory_validation($hod_id,true,40,2,true,true,false,false,"HOD Id") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_id,true,40,2,true,true,false,false,"HOD Id");
			}
			
			if(inventory_validation($hod_name,true,40,2,false,true,false,false,"HOD Name ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_name,true,40,2,false,true,false,false,"HOD Name");
			}
			if(inventory_validation($hod_user,true,40,2,false,true,false,false,"Username ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_user,true,40,2,false,true,false,false,"Username");
			}
			if(inventory_validation($hod_pass,true,40,2,false,true,false,false,"Password ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_pass,true,40,2,false,true,false,false,"Password");
			}
			
			  
			// $select_department_query = "SELECT `fld_department_id`,`fld_department` FROM `tbl_department` WHERE `fld_ai_id` = '".$department_id."';";
			//$select_department_query_result = inventory_query($select_department_query); 
			/*if(inventory_num_rows($select_department_query_result)>0){
				$row_data = inventory_fetch_assoc($select_department_query_result);
				$dept_id_db = $row_data['fld_department_id'];
				$dept_name_db = $row_data['fld_department'];*/
				//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
				
				if($error_msg == ""){
					$ckeck_duplicate_department_id = "SELECT `fld_ai_id` FROM `tbl_hod` WHERE LOWER(`fld_hod_id`) = LOWER('".$hod_id."');";
				    $ckeck_duplicate_department_id_result = inventory_query($ckeck_duplicate_department_id); 
				    if(inventory_num_rows($ckeck_duplicate_department_id_result)){
					/*$ckeck_duplicate_department_name = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department`) = LOWER('".$dept_name."');";
					$ckeck_duplicate_department_name_result = inventory_query($ckeck_duplicate_department_name); 
					if(!inventory_num_rows($ckeck_duplicate_department_name_result)){*/
					
					 $selectuserisqry="SELECT * FROM `tbl_user`  WHERE `venid` = '".$hod_id."'";
					$selectuserisqryrslt=inventory_query($selectuserisqry);
					
					$selectuserisqryrsltrw=inventory_fetch_assoc($selectuserisqryrslt);
					$useriiid=$selectuserisqryrsltrw['fld_ai_id'];
					
					
					
					
					 
			if(isset($_POST['category_r']) && !empty($_POST['category_r'])){ $category_r=$_POST['category_r']; }else{ $category_r=0; }
			if(isset($_POST['category_w']) && !empty($_POST['category_w'])){ $category_w=$_POST['category_w']; }else{ $category_w=0; }
			 if(isset($_POST['category_d']) && !empty($_POST['category_d'])){ $category_d=$_POST['category_d']; }else{ $category_d=0; }
			 
			 
			 if(isset($_POST['subcat_r']) && !empty($_POST['subcat_r'])){ $subcat_r=$_POST['subcat_r']; }else{ $subcat_r=0; }
			 if(isset($_POST['subcat_w']) && !empty($_POST['subcat_w'])){ $subcat_w=$_POST['subcat_w']; }else{ $subcat_w=0; }
			 if(isset($_POST['subcat_d']) && !empty($_POST['subcat_d'])){ $subcat_d=$_POST['subcat_d']; }else{ $subcat_d=0; }
			 
			 
			 if(isset($_POST['deep_r']) && !empty($_POST['deep_r'])){ $deep_r=$_POST['deep_r']; }else{ $deep_r=0; }
			 if(isset($_POST['deep_w']) && !empty($_POST['deep_w'])){ $deep_w=$_POST['deep_w']; }else{ $deep_w=0; }
			 if(isset($_POST['deep_d']) && !empty($_POST['deep_d'])){ $deep_d=$_POST['deep_d']; }else{ $deep_d=0; }
			 
			 if(isset($_POST['tax_r']) && !empty($_POST['tax_r'])){ $tax_r=$_POST['tax_r']; }else{ $tax_r=0; }
			 if(isset($_POST['tax_w']) && !empty($_POST['tax_w'])){ $tax_w=$_POST['tax_w']; }else{ $tax_w=0; }
			 if(isset($_POST['tax_d']) && !empty($_POST['tax_d'])){ $tax_d=$_POST['tax_d']; }else{ $tax_d=0; }
			 
			 
			 if(isset($_POST['item_r']) && !empty($_POST['item_r'])){ $item_r=$_POST['item_r']; }else{ $item_r=0; }
			 if(isset($_POST['item_w']) && !empty($_POST['item_w'])){ $item_w=$_POST['item_w']; }else{ $item_w=0; }
			 if(isset($_POST['item_d']) && !empty($_POST['item_d'])){ $item_d=$_POST['item_d']; }else{ $item_d=0; }
			
			 if(isset($_POST['indent_r']) && !empty($_POST['indent_r'])){ $indent_r=$_POST['indent_r']; }else{ $indent_r=0; }
			 if(isset($_POST['indent_w']) && !empty($_POST['indent_w'])){ $indent_w=$_POST['indent_w']; }else{ $indent_w=0; }
			 if(isset($_POST['indent_d']) && !empty($_POST['indent_d'])){ $indent_d=$_POST['indent_d']; }else{ $indent_d=0; }
			 
			 if(isset($_POST['po_r']) && !empty($_POST['po_r'])){ $po_r=$_POST['po_r']; }else{ $po_r=0; }
			 if(isset($_POST['po_w']) && !empty($_POST['po_w'])){ $po_w=$_POST['po_w']; }else{ $po_w=0; }
			 if(isset($_POST['po_d']) && !empty($_POST['po_d'])){ $po_d=$_POST['po_d']; }else{ $po_d=0; }
			 
			 if(isset($_POST['cashp_r']) && !empty($_POST['cashp_r'])){ $cashp_r=$_POST['cashp_r']; }else{ $cashp_r=0; }
			 if(isset($_POST['cashp_w']) && !empty($_POST['cashp_w'])){ $cashp_w=$_POST['cashp_w']; }else{ $cashp_w=0; }
			 if(isset($_POST['cashp_d']) && !empty($_POST['cashp_d'])){ $cashp_d=$_POST['cashp_d']; }else{ $cashp_d=0; }
			 
			 
			  if(isset($_POST['por_r']) && !empty($_POST['por_r'])){ $por_r=$_POST['por_r']; }else{ $por_r=0; }
			  if(isset($_POST['por_w']) && !empty($_POST['por_w'])){ $por_w=$_POST['por_w']; }else{ $por_w=0; }
			  if(isset($_POST['por_d']) && !empty($_POST['por_d'])){ $por_d=$_POST['por_d']; }else{ $por_d=0; }
			 
			 
			  if(isset($_POST['indentr_r']) && !empty($_POST['indentr_r'])){ $indentr_r=$_POST['indentr_r']; }else{ $indentr_r=0; }
			  if(isset($_POST['indentr_w']) && !empty($_POST['indentr_w'])){ $indentr_w=$_POST['indentr_w']; }else{ $indentr_w=0; }
			  if(isset($_POST['indentr_d']) && !empty($_POST['indentr_d'])){ $indentr_d=$_POST['indentr_d']; }else{ $indentr_d=0; }
			 
			 if(isset($_POST['vendorr_r']) && !empty($_POST['vendorr_r'])){ $vendorr_r=$_POST['vendorr_r']; }else{ $vendorr_r=0; }
			 if(isset($_POST['vendorr_w']) && !empty($_POST['vendorr_w'])){ $vendorr_w=$_POST['vendorr_w']; }else{ $vendorr_w=0; }
			 if(isset($_POST['vendorr_d']) && !empty($_POST['vendorr_d'])){ $vendorr_d=$_POST['vendorr_d']; }else{ $vendorr_d=0; }
			 
			 if(isset($_POST['por_r']) && !empty($_POST['por_r'])){ $por_r=$_POST['por_r']; }else{ $por_r=0; }
			 if(isset($_POST['por_w']) && !empty($_POST['por_w'])){ $por_w=$_POST['por_w']; }else{ $por_w=0; }
			 if(isset($_POST['por_d']) && !empty($_POST['por_d'])){ $por_d=$_POST['por_d']; }else{ $por_d=0; }
			 
			 
			 if(isset($_POST['receiver_r']) && !empty($_POST['receiver_r'])){ $receiver_r=$_POST['receiver_r']; }else{ $receiver_r=0; }
			 if(isset($_POST['receiver_w']) && !empty($_POST['receiver_w'])){ $receiver_w=$_POST['receiver_w']; }else{ $receiver_w=0; }
			 if(isset($_POST['receiver_d']) && !empty($_POST['receiver_d'])){ $receiver_d=$_POST['receiver_d']; }else{ $receiver_d=0; }
			 
			 
			 if(isset($_POST['user_r']) && !empty($_POST['user_r'])){ $user_r=$_POST['user_r']; }else{ $user_r=0; }
			 if(isset($_POST['user_w']) && !empty($_POST['user_w'])){ $user_w=$_POST['user_w']; }else{ $user_w=0; }
			 if(isset($_POST['user_d']) && !empty($_POST['user_d'])){ $user_d=$_POST['user_d']; }else{ $user_d=0; }
			 
			 
			 if(isset($_POST['hod_r']) && !empty($_POST['hod_r'])){ $hod_r=$_POST['hod_r']; }else{ $hod_r=0; }
			 if(isset($_POST['hod_w']) && !empty($_POST['hod_w'])){ $hod_w=$_POST['hod_w']; }else{ $hod_w=0; }
			 if(isset($_POST['hod_d']) && !empty($_POST['hod_d'])){ $hod_d=$_POST['hod_d']; }else{ $hod_d=0; }
			 
			 if(isset($_POST['storek_r']) && !empty($_POST['storek_r'])){ $storek_r=$_POST['storek_r']; }else{ $storek_r=0; }
			 if(isset($_POST['storek_w']) && !empty($_POST['storek_w'])){ $storek_w=$_POST['storek_w']; }else{ $storek_w=0; }
			 if(isset($_POST['storek_d']) && !empty($_POST['storek_d'])){ $storek_d=$_POST['storek_d']; }else{ $storek_d=0;}			
			
			 if(isset($_POST['porr_r']) && !empty($_POST['porr_r'])){ $porr_r=$_POST['porr_r']; }else{ $porr_r=0; }
			 if(isset($_POST['porr_w']) && !empty($_POST['porr_w'])){ $porr_w=$_POST['porr_w']; }else{ $porr_w=0; }
			 if(isset($_POST['porr_d']) && !empty($_POST['porr_d'])){ $porr_d=$_POST['porr_d']; }else{ $porr_d=0; }
			 
			 if(isset($_POST['cashprecive_r']) && !empty($_POST['cashprecive_r'])){ $cashprecive_r=$_POST['cashprecive_r']; }else{ $cashprecive_r=0; }
			 if(isset($_POST['cashprecive_w']) && !empty($_POST['cashprecive_w'])){ $cashprecive_w=$_POST['cashprecive_w']; }else{ $cashprecive_w=0; }
			 if(isset($_POST['cashprecive_d']) && !empty($_POST['cashprecive_d'])){ $cashprecive_d=$_POST['cashprecive_d']; }else{ $cashprecive_d=0;}			
			
			 
			 
			 
			 //check user details exist or not account permission
			 
			 $qryt="select * from module_permission where user_id ='".$useriiid."'";
			 $qrtyy_reslt=inventory_query($qryt);
			 $rowdtre = inventory_fetch_assoc($qrtyy_reslt);
			 if(isset($rowdtre) && !empty($rowdtre)){
			 	
				   $qrtyupdte="update module_permission set 
									category_r='".$category_r."',
									category_w='".$category_w."',
									category_d='".$category_d."',
									subcat_r='".$subcat_r."',
									subcat_w='".$subcat_w."',
									subcat_d='".$subcat_d."',
									deep_r='".$deep_r."',
									deep_w='".$deep_w."',
									deep_d='".$deep_d."',
									tax_r='".$tax_r."',
									tax_w='".$tax_w."',
									tax_d='".$tax_d."',
									item_r='".$item_r."',
									item_w='".$item_w."',
									item_d='".$item_d."',
									indent_r='".$indent_r."',
									indent_w='".$indent_w."',
									indent_d='".$indent_d."',
									po_r='".$po_r."',
									po_w='".$po_w."',
									po_d='".$po_d."',
									cashp_r='".$cashp_r."',
									cashp_w='".$cashp_w."',
									cashp_d='".$cashp_d."',
									vendorr_r='".$vendorr_r."',
									vendorr_w='".$vendorr_w."',
									vendorr_d='".$vendorr_d."',
									por_r='".$por_r."',
									por_w='".$por_w."',
									por_d='".$por_d."',
									indentr_r='".$indentr_r."',
									indentr_w='".$indentr_w."',
									indentr_d='".$indentr_d."',
									receiver_r='".$receiver_r."',
									receiver_w='".$receiver_w."',
									receiver_d='".$receiver_d."',
									user_r='".$user_r."',
									user_w='".$user_w."',
									user_d='".$user_d."',
									hod_r='".$hod_r."',
									hod_w='".$hod_w."',
									hod_d='".$hod_d."',
									storek_r='".$storek_r."',
									storek_w='".$storek_w."',
									storek_d='".$storek_d."',
									cashprecive_d='".$cashprecive_d."',
									cashprecive_w='".$cashprecive_w."',
									cashprecive_r='".$cashprecive_r."'
									
									
									where  user_id='".$useriiid."'
									
									
				
				
							";
							//echo $qrtyupdte; exit;
							
							$qrtyytt=inventory_query($qrtyupdte);
				
				//echo $qrtyupdte; exit;
				
				
				
			 }else{
					
					 $qrtyupdte="insert into module_permission ( 
									category_r,
									category_w,
									category_d,
									subcat_r,
									subcat_w,
									subcat_d,
									deep_r,
									deep_w,
									deep_d,
									tax_r,
									tax_w,
									tax_d,
									item_r,
									item_w,
									item_d,
									indent_r,
									indent_w,
									indent_d,
									po_r,
									po_w,
									po_d,
									cashp_r,
									cashp_w,
									cashp_d,
									vendorr_r,
									vendorr_w,
									vendorr_d,
									por_r,
									por_w,
									por_d,
									indentr_r,
									indentr_w,
									indentr_d,
									receiver_r,
									receiver_w,
									receiver_d,
									user_r,
									user_w,
									user_d,
									hod_r,
									hod_w,
									hod_d,
									storek_r,
									storek_w,
									storek_d,
									cashprecive_d,
									cashprecive_w,
									cashprecive_r,
									user_id
									)
									values(
									'".$category_r."',
									'".$category_w."',
									'".$category_d."',
									'".$subcat_r."',
									'".$subcat_w."',
									'".$subcat_d."',
									'".$deep_r."',
									'".$deep_w."',
									'".$deep_d."',
									'".$tax_r."',
									'".$tax_w."',
									'".$tax_d."',
									'".$item_r."',
									'".$item_w."',
									'".$item_d."',
									'".$indent_r."',
									'".$indent_w."',
									'".$indent_d."',
									'".$po_r."',
									'".$po_w."',
									'".$po_d."',
									'".$cashp_r."',
									'".$cashp_w."',
									'".$cashp_d."',
								    '".$vendorr_r."',
									'".$vendorr_w."',
									'".$vendorr_d."',
									'".$por_r."',
									'".$por_w."',
									'".$por_d."',
									'".$indentr_r."',
									'".$indentr_w."',
									'".$indentr_d."',
									'".$receiver_r."',
									'".$receiver_w."',
									'".$receiver_d."',
									'".$user_r."',
									'".$user_w."',
									'".$user_d."',
									'".$hod_r."',
									'".$hod_w."',
									'".$hod_d."',
									'".$storek_r."',
									'".$storek_w."',
									'".$storek_d."',
									'".$cashprecive_d."',
									'".$cashprecive_w."',
									'".$cashprecive_r."',
									'".$useriiid."'
									
									
									
									
									)
									
									
									
				
				
							";
							
							
							$qrtyytt=inventory_query($qrtyupdte);
			 	
				
			 }
			 
			 
					
					
					
					
						 $inset_into_department_query = "update `tbl_hod` set
																	fld_hod_name='".$hod_name."',
																	fld_hod_username='".$hod_user."',
																	fld_hod_password='".$hod_pass."',
																	dep_id='".$hod_dep."'
																where
																	fld_ai_id='".$hodd_id."'
																
																
						                                          ";
						 $qrtyytt11=inventory_query($inset_into_department_query);
						                                          
						  	$sql_query = "update `tbl_user` set
																	fld_name='".$hod_name."',
																	fld_username='".$hod_user."',
																	fld_password='".$hod_pass."'
																
																where
																	venid='".$hod_id."'
																
																
						                                          ";
						                                          
						  $qrtyytt22=inventory_query($sql_query);
						//$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if($qrtyytt22==true && $qrtyytt11== true){
							$succee_msg = "HOD Successfully Updated";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					/*}else{
						$error_msg = "Duplicate Department Name Found";	
					}*/
				}else{
					$error_msg = "Duplicate HOD Id Found";	
				}
				}else{
					$case = "edit";	
				}
			/*}else{
				include("nopermission.php");
				exit();
			}*/
		}
	}
	if($case == "add"){
		if($hod_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		//echo 1;exit;
		$hod_id = "";
		$hod_name = "";
		$hod_user="";
		$hod_pass="";
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(isset($_POST['add_hod'])){	
			  $hod_id = inventory_get_post_escape('hod_id');
			 $hod_name = inventory_get_post_escape('hod_name');
			 $hod_user = inventory_get_post_escape('hod_user');
			 $hod_pass = inventory_get_post_escape('hod_pass');
			   $hod_dep =implode(",",$_POST['hod_dep']) ;
			 
			//exit;
			//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
			if(inventory_validation($hod_id,true,40,2,true,true,false,false,"HOD Id") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_id,true,40,2,true,true,false,false,"HOD Id");
			}
			
			if(inventory_validation($hod_name,true,40,2,false,true,false,false,"HOD Name ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_name,true,40,2,false,true,false,false,"HOD Name");
			}
			if(inventory_validation($hod_user,true,40,2,false,true,false,false,"Username ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_user,true,40,2,false,true,false,false,"Username");
			}
			if(inventory_validation($hod_pass,true,40,2,false,true,false,false,"Password ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($hod_pass,true,40,2,false,true,false,false,"Password");
			}
		
			if($error_msg == ""){
				$ckeck_duplicate_department_id = "SELECT `fld_ai_id` FROM `tbl_hod` WHERE LOWER(`fld_hod_id`) = LOWER('".$hod_id."');";
				$ckeck_duplicate_department_id_result = inventory_query($ckeck_duplicate_department_id); 
				if(!inventory_num_rows($ckeck_duplicate_department_id_result)){
					/*$ckeck_duplicate_department_name = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department`) = LOWER('".$dept_name."');";
					$ckeck_duplicate_department_name_result = inventory_query($ckeck_duplicate_department_name); 
					if(!inventory_num_rows($ckeck_duplicate_department_name_result)){*/
						$inset_into_department_query = "INSERT INTO `tbl_hod`
						                                          (`fld_hod_id`,`dep_id`,`fld_hod_name`,`fld_hod_username`,`fld_hod_password`,`fld_is_active`)
						                                VALUES('".$hod_id."','".$hod_dep."','".$hod_name."','".$hod_user."','".$hod_pass."','1')";
				     	$sql_hod="INSERT INTO `tbl_user`
						                                          (`fld_name`,`venid`,`fld_username`,`fld_password`,`fld_user_type`,`fld_is_active`)
						                                VALUES('".$hod_name."','".$hod_id."','".$hod_user."','".$hod_pass."','hod','1')";
		                /*$insert_user_hod="INSERT INTO `tbl_hod`
						                                          (`fld_hod_id`,`dep_id`,`fld_hod_name`,`fld_hod_username`,`fld_hod_password`,`fld_is_active`)
						                                VALUES('".$hod_id."','".$hod_dep."','".$hod_name."','".$hod_user."','".$hod_pass."','1')";*/
						                  	$inset_into_department_query_result1 = inventory_query($sql_hod); 
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if(inventory_affected_rows()>0){
							$succee_msg = "HOD Successfully Added";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					/*}else{
						$error_msg = "Duplicate Department Name Found";	
					}*/
				}else{
					$error_msg = "Duplicate HOD Id Found";	
				}
			}
		}
	}
	if($case == "list"){
		if($hod_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$list = "";
		$select_department_query = "SELECT * FROM `tbl_hod` ORDER BY `fld_is_active`DESC,`fld_hod_id` ASC";
		$select_department_query_result = inventory_query($select_department_query); 
		if(inventory_num_rows($select_department_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_department_query_result)){
				$active_class = '';
				$icon_class = "";
				$status = "Active";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
					$status = "Inactive";
				}
				
				$dep_id=explode(",",$row_data['dep_id']);
				$depar=array();
				for($ij=0;$ij<count($dep_id);$ij++){
				$select_department_query2 = "SELECT * FROM tbl_department WHERE fld_is_active ='1' and fld_ai_id='".$dep_id[$ij]."'";
			   $select_department_query_result2 = inventory_query($select_department_query2); 
			   $res=inventory_fetch_assoc($select_department_query_result2);
			      array_push($depar,$res['fld_department']);
				}
				
				$deparimpl=implode(",",$depar);
						
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_hod_id'].'</td>
								<td>'.$deparimpl.'</td>
								<td>'.$row_data['fld_hod_name'].'</td>
								
								<td>'.$row_data['fld_hod_username'].'</td>
								<td>'.$row_data['fld_hod_password'].'</td>
								<td>'.$status.'</td>';
								
					if($hod_w==0){
						$list .= 	'<td></td></tr>';	
						
					}else{
							$list .= 	'<td><center><a href="'.ROOT_PATH.'/edithod/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
								&nbsp;<a href="'.ROOT_PATH.'/deletehod/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-trash" aria-hidden="true"></i></a></center></td></center></td>
							</tr>';	
								}
							
						
								
			}
		}
	}
	
?>