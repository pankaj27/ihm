<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		
		//get all category related data
		
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $deep_r=$rst_rw['deep_r'];
		 $deep_w=$rst_rw['deep_w'];
		 $deep_d=$rst_rw['deep_d'];
		
		if($deep_r==0 && $deep_w==0 && $deep_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
		 * 
		 */
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "edit"){
		if($deep_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$department_id = track64_decode(inventory_get_get('department_id'));
		
		$select_department_query = "SELECT * FROM `tbl_department` WHERE `fld_ai_id` = '".$department_id."';";
		$select_department_query_result = inventory_query($select_department_query); 
		if(inventory_num_rows($select_department_query_result)>0){
			$row_data = inventory_fetch_assoc($select_department_query_result);
			$dept_id = $row_data['fld_department_id'];
			$dept_name = $row_data['fld_department'];
			$section= $row_data['section'];
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "update"){
		if($deep_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$log_text = "";
		$update_text = "";
		$succee_msg = "";
		$error_msg = "";
		if(inventory_post_isset('edit_department')){	
			$dept_id = inventory_get_post_escape('dept_id');
			$dept_name = inventory_get_post_escape('dept_name');
			$section=implode(",",$_POST['section']);
			
			$department_id = track64_decode(inventory_get_post_escape('department_id'));
			$select_department_query = "SELECT `fld_department_id`,`fld_department` FROM `tbl_department` WHERE `fld_ai_id` = '".$department_id."';";
			$select_department_query_result = inventory_query($select_department_query); 
			if(inventory_num_rows($select_department_query_result)>0){
				$row_data = inventory_fetch_assoc($select_department_query_result);
				$dept_id_db = $row_data['fld_department_id'];
				$dept_name_db = $row_data['fld_department'];
				//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
				if(inventory_validation($dept_id,true,40,2,true,true,false,false,"Department Id") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($dept_id,true,40,2,true,true,false,false,"Department Id");
				}
				if(inventory_validation($dept_name,true,40,2,false,true,false,false,"Department Name") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($dept_name,true,40,2,false,true,false,false,"Department Name");
				}
				if($error_msg == ""){
					$ckeck_duplicate_department_id = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department_id`) = LOWER('".$dept_id."') AND `fld_ai_id` != '".$department_id."';";
					$ckeck_duplicate_department_id_result = inventory_query($ckeck_duplicate_department_id); 
					if(!inventory_num_rows($ckeck_duplicate_department_id_result)){
						$ckeck_duplicate_department_name = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department`) = LOWER('".$dept_name."') AND `fld_ai_id` != '".$department_id."';";
						$ckeck_duplicate_department_name_result = inventory_query($ckeck_duplicate_department_name); 
						if(!inventory_num_rows($ckeck_duplicate_department_name_result)){
							if($dept_id != $dept_id_db){
								if($log_text != ""){
									$log_text .= ",";	
									$update_text .= ",";	
								}
								$log_text .= "fld_department_id =>".$dept_id_db;	
								$update_text .= "fld_department_id = '".$dept_id."' ";
							}
							if($dept_name != $dept_name_db){
								if($log_text != ""){
									$log_text .= ",";	
									$update_text .= ",";	
								}
								$log_text .= "fld_department =>".$dept_name_db;	
								$update_text .= "fld_department = '".$dept_name."' ";
							}
							//if($log_text != ""){
								inventory_commit_off();
								$update_department_query = "UPDATE `tbl_department` SET  `section`='".$section."'".$update_text." WHERE `fld_ai_id` = '".$department_id."';";
								$update_department_query_result = inventory_query($update_department_query);
								if(inventory_affected_rows() >0){
									$insert_into_log_query = "INSERT INTO `tbi_edit_log`(`fld_id`,`fld_type`,`fld_log_text`,`fld_edited_by`) VALUES ('".$department_id."','department','".$log_text."','".$user_id."');";
									$insert_into_log_query_result = inventory_query($insert_into_log_query);
									if(inventory_affected_rows() >0){
										inventory_commit();
										$succee_msg = "Department Successfully Updated";
										$case = "list";
									}else{
										$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
										inventory_rollback();
										$case = "edit";
									}
								}else{
									$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
									inventory_rollback();
									$case = "edit";
								}
								inventory_commit_on();
							//}else{
							//	$succee_msg = "Nothing To Update";
							//	$case = "list";	
							//}
						}else{
							$error_msg = "Duplicate Department Name Found";	
							$case = "edit";
						}
					}else{
						$error_msg = "Duplicate Department Id Found";
						$case = "edit";	
					}
				}else{
					$case = "edit";	
				}
			}else{
				include("nopermission.php");
				exit();
			}
		}
	}
	if($case == "add"){
		if($deep_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$dept_id = "";
		$dept_name = "";
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('add_department')){	
			$dept_id = inventory_get_post_escape('dept_id');
			$dept_name = inventory_get_post_escape('dept_name');
			$section=implode(",",$_POST['section']);
			
			//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
			if(inventory_validation($dept_id,true,40,2,true,true,false,false,"Department Id") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($dept_id,true,40,2,true,true,false,false,"Department Id");
			}
			if(inventory_validation($dept_name,true,40,2,false,true,false,false,"Department Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($dept_name,true,40,2,false,true,false,false,"Department Name");
			}
			if($error_msg == ""){
				$ckeck_duplicate_department_id = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department_id`) = LOWER('".$dept_id."');";
				$ckeck_duplicate_department_id_result = inventory_query($ckeck_duplicate_department_id); 
				if(!inventory_num_rows($ckeck_duplicate_department_id_result)){
					$ckeck_duplicate_department_name = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department`) = LOWER('".$dept_name."');";
					$ckeck_duplicate_department_name_result = inventory_query($ckeck_duplicate_department_name); 
					if(!inventory_num_rows($ckeck_duplicate_department_name_result)){
						$inset_into_department_query = "INSERT INTO `tbl_department`(`fld_department_id`,`fld_department`,`fld_is_active`,`section`) VALUES('".$dept_id."','".$dept_name."','1','".$section."')";
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if(inventory_affected_rows()>0){
							$succee_msg = "Department Successfully Added";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					}else{
						$error_msg = "Duplicate Department Name Found";	
					}
				}else{
					$error_msg = "Duplicate Department Id Found";	
				}
			}
		}
	}
	if($case == "list"){
		if($deep_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$list = "";
		$select_department_query = "SELECT `section`,`fld_ai_id`,`fld_department_id`,`fld_department`,`fld_is_active` FROM `tbl_department` ORDER BY `fld_is_active`DESC,`fld_department` ASC;";
		$select_department_query_result = inventory_query($select_department_query); 
		if(inventory_num_rows($select_department_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_department_query_result)){
				$active_class = '';
				$icon_class = "";
				$status = "Active";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
					$status = "Inactive";
				}
				
				$sec=explode(",",$row_data['section']);
				$secarr=array();
				for($ijj=0;$ijj<count($sec) ;$ijj++){
					$select_semester_query2 = "SELECT * FROM  tbl_section where fld_ai_id='".$sec[$ijj]."'";
					$select_semester_query_result2 = inventory_query($select_semester_query2); 
				    $row_data112 = inventory_fetch_assoc($select_semester_query_result2);
					$nbb=$row_data112['fld_category'];
					array_push($secarr,$nbb);
					
				}
				$secarrimpl=implode(",",$secarr);
				
                            		  
                            	//echo $semester;
                       
				
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_department_id'].'</td>
								<td>'.$row_data['fld_department'].'</td>
								<td>'.$secarrimpl.'</td>
								<td>'.$status.'</td>';
				if($deep_w==0){
					//include("nopermission.php");
					//exit();
					$list .= '<td></td>
							</tr>';
					
				}else{
					
					$list .= 	'<td><center><a href="'.ROOT_PATH.'/editdepartment/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></center></td>
							</tr>';
				}				
				
			}
		}
	}
	
?>