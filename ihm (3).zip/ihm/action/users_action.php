<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		
		 $sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $user_r=$rst_rw['user_r'];
		 $user_w=$rst_rw['user_w'];
		 $user_d=$rst_rw['user_d'];
		
		if($user_r==0 && $user_w==0 && $user_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
		 * 
		 * */
		 
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "edit"){
		if( $user_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT `fld_name`,`fld_mobile_number`,`fld_email`,`fld_city`,`fld_address`,`fld_pin`,`fld_user_type`,`fld_is_active` FROM `tbl_user` WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$name = $row_data['fld_name'];
			$mobile_number = $row_data['fld_mobile_number'];
			$email = $row_data['fld_email'];
			$city = $row_data['fld_city'];
			$address = $row_data['fld_address'];
			$pin = $row_data['fld_pin'];
			$user_type = usertype($row_data['fld_user_type']);
			$is_active = $row_data['fld_is_active'];
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		if( $user_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('edit_user')){
			$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
			$city = inventory_get_post_escape('city');
			$address = inventory_get_post_escape('address');
			$pin = inventory_get_post_escape('pin');
			$password = inventory_get_post_escape('password');
			if(inventory_post_isset('is_active')){
				$is_active = 1;	
			}else{
				$is_active = 0;	
			}
			$select_user_details_query = "SELECT `fld_name`,`fld_mobile_number`,`fld_email`,`fld_city`,`fld_address`,`fld_pin`,`fld_user_type`,`fld_is_active` FROM `tbl_user` WHERE `fld_ai_id` = '".$user_ai_id."';";
			$select_user_details_query_result = inventory_query($select_user_details_query); 
			if(inventory_num_rows($select_user_details_query_result)>0){
				$row_data = inventory_fetch_assoc($select_user_details_query_result);
				$name = $row_data['fld_name'];
				$mobile_number = $row_data['fld_mobile_number'];
				$email = $row_data['fld_email'];
				$city_db = $row_data['fld_city'];
				$address_db  = $row_data['fld_address'];
				$pin_db  = $row_data['fld_pin'];
				$user_type = usertype($row_data['fld_user_type']);
				$is_active_db  = $row_data['fld_is_active'];
				
				//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
				if(inventory_validation($city,true,40,4,false,false,false,false,"City") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($city,true,40,4,false,false,false,false,"City");
				}
				if(inventory_validation($address,true,40,4,false,false,false,false,"Address") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($address,true,40,4,false,false,false,false,"Address");
				}
				if(inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code");
				}
			}else{
				include("nopermission.php");
				exit();
			}
		}
	}
	if($case == "list"){
		if( $user_r==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		$select_user_details_query = "SELECT `fld_ai_id`,`fld_name`,`fld_mobile_number`,`fld_email`,`fld_user_type`,`fld_is_active` FROM `tbl_user` WHERE `fld_user_type` != 'admin' ORDER BY `fld_is_active` DESC ,`fld_name` ASC";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_name'].'</td>
								<td>'.$row_data['fld_email'].'</td>
								<td>'.$row_data['fld_mobile_number'].'</td>
								<td>'.usertype($row_data['fld_user_type']).'</td>
							
								<td>'.$status_array[$row_data['fld_is_active']].'</td>
								<td><center><a href="'.ROOT_PATH.'/edituser/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></center></td>
							</tr>';
			}
		}
	}
?>