<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $item_tagg_read=$rst_rw['item_tagg_read'];
		 $item_tagg_write=$rst_rw['item_tagg_write'];
		 $item_tagg_delete=$rst_rw['item_tagg_delete'];
		
		if($item_tagg_read==0 && $item_tagg_write==0 && $item_tagg_delete==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
	}else{
		include("nopermission.php");
		exit();
	}
	
	if($case == "getsubcategoryitem"){
		$option_list = "";
		if(inventory_post_isset('category') && inventory_post_isset('category') ){
			$category = inventory_get_post_escape('category');	
			$subcat=inventory_get_post_escape('subcat');
			$select_category_query = "select * from tbl_item where fld_is_active='1' and fld_category_id='".$category."' and fld_sub_category_id='".$subcat."'";
			$select_sub_category_query_result = inventory_query($select_category_query);
			if(inventory_num_rows($select_sub_category_query_result)>0){
					
				while($row_data_subcategory = inventory_fetch_assoc($select_sub_category_query_result))	{
					//echo '<option value="'.$row_data_subcategory['fld_ai_id'].'">'.$row_data_subcategory['fld_name'].'</option>';
					$option_list .='<input type="checkbox" name="items[]" value="'.$row_data_subcategory['fld_ai_id'].'"  />'.$row_data_subcategory['fld_name']."&nbsp;";
				}
				
			}									
			
			echo '<label class="col-lg-3 control-label text-lg-right pt-2" for="service">Items<span class="required">*</span></label>
                    <div class="col-lg-6">
                        
                            '.$option_list.'
                        
                    </div>';
		}
	}	


	if($case == "update"){
		if($item_tagg_write==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$category_array = array();
		$sub_category_array = array();
		$category = "";
		$subcategory = "";
		$succee_msg = "";
		$error_msg = "";
		$select_category_query = "SELECT `fld_ai_id`,`fld_category` FROM `tbl_category` WHERE `fld_isactive` = '1'";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$category_array[$row_data['fld_ai_id']] = $row_data['fld_category'];
			}
		}
		
		
		
		
		
		              	
			
		}else{
			include("nopermission.php");
			exit();
		}
	
?>
