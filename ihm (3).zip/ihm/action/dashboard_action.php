<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
	}else{
		include("nopermission.php");
		exit();
	}
?>