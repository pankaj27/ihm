<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $tax_r=$rst_rw['tax_r'];
		 $tax_w=$rst_rw['tax_w'];
		 $tax_d=$rst_rw['tax_d'];
		
		if($tax_r==0 && $tax_w==0 && $tax_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		
		
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
		 * 
		 * 
		 */
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "edit"){
		if($tax_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$sgst = "";
		$cgst = "";
		$is_active  = "";
		$tax_id = track64_decode(inventory_get_get('tax_id'));
		
		$select_category_query = "SELECT `fld_sgst`,`fld_cgst`,`fld_is_active` FROM `tbl_tax`  WHERE `fld_ai_id` = '".$tax_id."';";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			$row_data = inventory_fetch_assoc($select_category_query_result);
			$sgst = $row_data['fld_sgst'];
			$cgst = $row_data['fld_cgst'];
			$is_active  = $row_data['fld_is_active'];
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		if($tax_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$log_text = "";
		$update_text = "";
		$succee_msg = "";
		$error_msg = "";
		if(inventory_post_isset('edit_tax')){	
			$sgst = inventory_get_post_escape('sgst');
			$cgst = inventory_get_post_escape('cgst');
			if(inventory_post_isset('is_active')){
				$is_active = 1;
			}else{
				$is_active = 0;
			}
			$tax_id = track64_decode(inventory_get_post_escape('tax_id'));
			$select_category_query ="SELECT `fld_sgst`,`fld_cgst`,`fld_is_active` FROM `tbl_tax`  WHERE `fld_ai_id` = '".$tax_id."';";
			$select_category_query_result = inventory_query($select_category_query); 
			if(inventory_num_rows($select_category_query_result)>0){
				$row_data = inventory_fetch_assoc($select_category_query_result);
				$sgst_db = $row_data['fld_sgst'];
				$cgst_db = $row_data['fld_cgst'];
				$is_active_db  = $row_data['fld_is_active'];
				if(inventory_validation($sgst,true,40,1,false,false,false,true,"SGST") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($sgst,true,40,1,false,false,false,true,"SGST");
				}
				if(inventory_validation($cgst,true,40,1,false,false,false,true,"CGST") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($cgst,true,40,1,false,false,false,true,"CGST");
				}
				if($error_msg == ""){
					$check_duplicate_category_query = "SELECT `fld_ai_id` FROM `tbl_tax` WHERE `fld_sgst` = '".$sgst."' AND `fld_cgst` = '".$cgst."' AND `fld_ai_id` != '".$tax_id."'";
					$check_duplicate_category_query_result = inventory_query($check_duplicate_category_query); 
					if(!inventory_num_rows($check_duplicate_category_query_result)){
						if($cgst != $cgst_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_cgst =>".$cgst_db;	
							$update_text .= "fld_cgst = '".$cgst."' ";
						}
						if($sgst != $sgst_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_sgst =>".$sgst_db;	
							$update_text .= "fld_sgst = '".$sgst."' ";
						}
						if($is_active != $is_active_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_is_active =>".$is_active_db;	
							$update_text .= "fld_is_active = '".$is_active."' ";
						}
						if($update_text != ""){
							inventory_commit_off();
							$update_department_query = "UPDATE `tbl_tax` SET ".$update_text." WHERE `fld_ai_id` = '".$tax_id."';";
							$update_department_query_result = inventory_query($update_department_query);
							if(inventory_affected_rows() >0){
								$insert_into_log_query = "INSERT INTO `tbi_edit_log`(`fld_id`,`fld_type`,`fld_log_text`,`fld_edited_by`) VALUES ('".$tax_id."','tax','".$log_text."','".$user_id."');";
								$insert_into_log_query_result = inventory_query($insert_into_log_query);
								if(inventory_affected_rows() >0){
									inventory_commit();
									$succee_msg = "Tax Successfully Updated";
									$case = "list";
								}else{
									$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
									inventory_rollback();
									$case = "edit";
								}
							}else{
								$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
								inventory_rollback();
								$case = "edit";
							}
							inventory_commit_on();
						}else{
							$succee_msg = "Nothing To Update";
							$case = "list";	
						}
					}else{
						$error_msg = "Duplicate Tax Found";
						$case = "edit";	
					}
				}else{
					$case = "edit";	
				}
			}else{
				include("nopermission.php");
				exit();
			}
			
		}
	}
	if($case == "add"){
		if($tax_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$sgst = "";
		$cgst = "";
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('add_tax')){	
			$sgst = inventory_get_post_escape('sgst');
			$cgst = inventory_get_post_escape('cgst');
			if(inventory_validation($sgst,true,40,1,false,false,false,true,"SGST") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($sgst,true,40,1,false,false,false,true,"SGST");
			}
			if(inventory_validation($cgst,true,40,1,false,false,false,true,"CGST") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($cgst,true,40,1,false,false,false,true,"CGST");
			}
			if($error_msg == ""){
				$check_duplicate_category_query = "SELECT `fld_ai_id` FROM `tbl_tax` WHERE `fld_sgst` = '".$sgst."' AND `fld_cgst` = '".$cgst."'";
				$check_duplicate_category_query_result = inventory_query($check_duplicate_category_query); 
				if(!inventory_num_rows($check_duplicate_category_query_result)){
					$insert_into_category = "INSERT INTO `tbl_tax`(`fld_sgst`,`fld_cgst`,`fld_is_active`) VALUES('".$sgst."','".$cgst."','1');";
					$insert_into_category_result = inventory_query($insert_into_category); 
					if(inventory_affected_rows()>0){
						$succee_msg = "Tax Successfully Added";
						$case = "list";
						break;
					}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
					}
				}else{
					$error_msg = "Duplicate Tax Found";	
				}
			}
		}
	}
	if($case == "list"){
		if($tax_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$category_array = array();
		$list = "";	
		$category_or_clause = "";
		
		$select_category_query = "SELECT `fld_ai_id`,`fld_sgst`,`fld_cgst`,`fld_is_active` FROM `tbl_tax` ORDER BY `fld_is_active` ASC";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_sgst'].'</td>
								<td>'.$row_data['fld_cgst'].'</td>';
			   if($tax_w==0){
					//include("nopermission.php");
					//exit();
					$list .= '<td></td>
							</tr>';
					
				}else{
					
					$list .= 	'<td><center><a href="'.ROOT_PATH.'/edittax/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></center></td>
							</tr>';
					
				}
								
			}
		}
	}
?>