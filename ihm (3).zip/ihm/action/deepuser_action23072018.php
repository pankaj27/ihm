<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
		 * */
		 $sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $user_r=$rst_rw['user_r'];
		 $user_w=$rst_rw['user_w'];
		 $user_d=$rst_rw['user_d'];
		
		if($user_r==0 && $user_w==0 && $user_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		 
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "delete"){
		if( $user_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_id = track64_decode(inventory_get_get('user_id'));
		
		 $select_department_query = "SELECT * FROM `tbl_user`  WHERE `fld_ai_id` = '".$user_id."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$sql="delete from `tbl_user`  WHERE `fld_ai_id` = '".$user_id."'";
			$qry = inventory_query($sql);
			$succee_msg = "User Successfully Deleted";
			$case = "list";
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "edit"){
		if( $user_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT * FROM `tbl_user` WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$name = $row_data['fld_name'];
			$mobile_number = $row_data['fld_mobile_number'];
		//	$email = $row_data['fld_email'];
		//	$city = $row_data['fld_city'];
		//	$address = $row_data['fld_address'];
		//	$pin = $row_data['fld_pin'];
			$username=$row_data['fld_username'];
			$deepid=$row_data['deepuser_id'];
			$paewd=$row_data['fld_password'];
			$user_type = $row_data['fld_user_type'];
			$userdep=$row_data['deepuser_id'];
			$is_active = $row_data['fld_is_active'];
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		if( $user_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('edit_user')){
			$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
			//$city = inventory_get_post_escape('city');
			//$address = inventory_get_post_escape('address');
			//$pin = inventory_get_post_escape('pin');
			$password = inventory_get_post_escape('password');
			$username=inventory_get_post_escape('username');
			$name=inventory_get_post_escape('name');
			 $mobile_number=inventory_get_post_escape('mobile_number');
		    $utype=inventory_get_post_escape('user_type');
		     $user_dep=inventory_get_post_escape('user_dep');
			 
			 //acount permission
			 
			if(isset($_POST['category_r']) && !empty($_POST['category_r'])){ $category_r=$_POST['category_r']; }else{ $category_r=0; }
			if(isset($_POST['category_w']) && !empty($_POST['category_w'])){ $category_w=$_POST['category_w']; }else{ $category_w=0; }
			 if(isset($_POST['category_d']) && !empty($_POST['category_d'])){ $category_d=$_POST['category_d']; }else{ $category_d=0; }
			 
			 
			 if(isset($_POST['subcat_r']) && !empty($_POST['subcat_r'])){ $subcat_r=$_POST['subcat_r']; }else{ $subcat_r=0; }
			 if(isset($_POST['subcat_w']) && !empty($_POST['subcat_w'])){ $subcat_w=$_POST['subcat_w']; }else{ $subcat_w=0; }
			 if(isset($_POST['subcat_d']) && !empty($_POST['subcat_d'])){ $subcat_d=$_POST['subcat_d']; }else{ $subcat_d=0; }
			 
			 
			 if(isset($_POST['deep_r']) && !empty($_POST['deep_r'])){ $deep_r=$_POST['deep_r']; }else{ $deep_r=0; }
			 if(isset($_POST['deep_w']) && !empty($_POST['deep_w'])){ $deep_w=$_POST['deep_w']; }else{ $deep_w=0; }
			 if(isset($_POST['deep_d']) && !empty($_POST['deep_d'])){ $deep_d=$_POST['deep_d']; }else{ $deep_d=0; }
			 
			 if(isset($_POST['tax_r']) && !empty($_POST['tax_r'])){ $tax_r=$_POST['tax_r']; }else{ $tax_r=0; }
			 if(isset($_POST['tax_w']) && !empty($_POST['tax_w'])){ $tax_w=$_POST['tax_w']; }else{ $tax_w=0; }
			 if(isset($_POST['tax_d']) && !empty($_POST['tax_d'])){ $tax_d=$_POST['tax_d']; }else{ $tax_d=0; }
			 
			 
			 if(isset($_POST['item_r']) && !empty($_POST['item_r'])){ $item_r=$_POST['item_r']; }else{ $item_r=0; }
			 if(isset($_POST['item_w']) && !empty($_POST['item_w'])){ $item_w=$_POST['item_w']; }else{ $item_w=0; }
			 if(isset($_POST['item_d']) && !empty($_POST['item_d'])){ $item_d=$_POST['item_d']; }else{ $item_d=0; }
			
			 if(isset($_POST['indent_r']) && !empty($_POST['indent_r'])){ $indent_r=$_POST['indent_r']; }else{ $indent_r=0; }
			 if(isset($_POST['indent_w']) && !empty($_POST['indent_w'])){ $indent_w=$_POST['indent_w']; }else{ $indent_w=0; }
			 if(isset($_POST['indent_d']) && !empty($_POST['indent_d'])){ $indent_d=$_POST['indent_d']; }else{ $indent_d=0; }
			 
			 if(isset($_POST['po_r']) && !empty($_POST['po_r'])){ $po_r=$_POST['po_r']; }else{ $po_r=0; }
			 if(isset($_POST['po_w']) && !empty($_POST['po_w'])){ $po_w=$_POST['po_w']; }else{ $po_w=0; }
			 if(isset($_POST['po_d']) && !empty($_POST['po_d'])){ $po_d=$_POST['po_d']; }else{ $po_d=0; }
			 
			 if(isset($_POST['cashp_r']) && !empty($_POST['cashp_r'])){ $cashp_r=$_POST['cashp_r']; }else{ $cashp_r=0; }
			 if(isset($_POST['cashp_w']) && !empty($_POST['cashp_w'])){ $cashp_w=$_POST['cashp_w']; }else{ $cashp_w=0; }
			 if(isset($_POST['cashp_d']) && !empty($_POST['cashp_d'])){ $cashp_d=$_POST['cashp_d']; }else{ $cashp_d=0; }
			 
			 
			  if(isset($_POST['por_r']) && !empty($_POST['por_r'])){ $por_r=$_POST['por_r']; }else{ $por_r=0; }
			  if(isset($_POST['por_w']) && !empty($_POST['por_w'])){ $por_w=$_POST['por_w']; }else{ $por_w=0; }
			  if(isset($_POST['por_d']) && !empty($_POST['por_d'])){ $por_d=$_POST['por_d']; }else{ $por_d=0; }
			 
			 
			  if(isset($_POST['indentr_r']) && !empty($_POST['indentr_r'])){ $indentr_r=$_POST['indentr_r']; }else{ $indentr_r=0; }
			  if(isset($_POST['indentr_w']) && !empty($_POST['indentr_w'])){ $indentr_w=$_POST['indentr_w']; }else{ $indentr_w=0; }
			  if(isset($_POST['indentr_d']) && !empty($_POST['indentr_d'])){ $indentr_d=$_POST['indentr_d']; }else{ $indentr_d=0; }
			 
			 if(isset($_POST['vendorr_r']) && !empty($_POST['vendorr_r'])){ $vendorr_r=$_POST['vendorr_r']; }else{ $vendorr_r=0; }
			 if(isset($_POST['vendorr_w']) && !empty($_POST['vendorr_w'])){ $vendorr_w=$_POST['vendorr_w']; }else{ $vendorr_w=0; }
			 if(isset($_POST['vendorr_d']) && !empty($_POST['vendorr_d'])){ $vendorr_d=$_POST['vendorr_d']; }else{ $vendorr_d=0; }
			 
			 if(isset($_POST['por_r']) && !empty($_POST['por_r'])){ $por_r=$_POST['por_r']; }else{ $por_r=0; }
			 if(isset($_POST['por_w']) && !empty($_POST['por_w'])){ $por_w=$_POST['por_w']; }else{ $por_w=0; }
			 if(isset($_POST['por_d']) && !empty($_POST['por_d'])){ $por_d=$_POST['por_d']; }else{ $por_d=0; }
			 
			 
			 if(isset($_POST['receiver_r']) && !empty($_POST['receiver_r'])){ $receiver_r=$_POST['receiver_r']; }else{ $receiver_r=0; }
			 if(isset($_POST['receiver_w']) && !empty($_POST['receiver_w'])){ $receiver_w=$_POST['receiver_w']; }else{ $receiver_w=0; }
			 if(isset($_POST['receiver_d']) && !empty($_POST['receiver_d'])){ $receiver_d=$_POST['receiver_d']; }else{ $receiver_d=0; }
			 
			 
			 if(isset($_POST['user_r']) && !empty($_POST['user_r'])){ $user_r=$_POST['user_r']; }else{ $user_r=0; }
			 if(isset($_POST['user_w']) && !empty($_POST['user_w'])){ $user_w=$_POST['user_w']; }else{ $user_w=0; }
			 if(isset($_POST['user_d']) && !empty($_POST['user_d'])){ $user_d=$_POST['user_d']; }else{ $user_d=0; }
			 
			 
			 if(isset($_POST['hod_r']) && !empty($_POST['hod_r'])){ $hod_r=$_POST['hod_r']; }else{ $hod_r=0; }
			 if(isset($_POST['hod_w']) && !empty($_POST['hod_w'])){ $hod_w=$_POST['hod_w']; }else{ $hod_w=0; }
			 if(isset($_POST['hod_d']) && !empty($_POST['hod_d'])){ $hod_d=$_POST['hod_d']; }else{ $hod_d=0; }
			 
			 if(isset($_POST['storek_r']) && !empty($_POST['storek_r'])){ $storek_r=$_POST['storek_r']; }else{ $storek_r=0; }
			 if(isset($_POST['storek_w']) && !empty($_POST['storek_w'])){ $storek_w=$_POST['storek_w']; }else{ $storek_w=0; }
			 if(isset($_POST['storek_d']) && !empty($_POST['storek_d'])){ $storek_d=$_POST['storek_d']; }else{ $storek_d=0;}			
			
			 
			 
			 
			 //check user details exist or not account permission
			 
			 $qryt="select * from module_permission where user_id ='".$user_ai_id."'";
			 $qrtyy_reslt=inventory_query($qryt);
			 $rowdtre = inventory_fetch_assoc($qrtyy_reslt);
			 if(isset($rowdtre) && !empty($rowdtre)){
			 	
				  $qrtyupdte="update module_permission set 
									category_r='".$category_r."',
									category_w='".$category_w."',
									category_d='".$category_d."',
									subcat_r='".$subcat_r."',
									subcat_w='".$subcat_w."',
									subcat_d='".$subcat_d."',
									deep_r='".$deep_r."',
									deep_w='".$deep_w."',
									deep_d='".$deep_d."',
									tax_r='".$tax_r."',
									tax_w='".$tax_w."',
									tax_d='".$tax_d."',
									item_r='".$item_r."',
									item_w='".$item_w."',
									item_d='".$item_d."',
									indent_r='".$indent_r."',
									indent_w='".$indent_w."',
									indent_d='".$indent_d."',
									po_r='".$po_r."',
									po_w='".$po_w."',
									po_d='".$po_d."',
									cashp_r='".$cashp_r."',
									cashp_w='".$cashp_w."',
									cashp_d='".$cashp_d."',
									vendorr_r='".$vendorr_r."',
									vendorr_w='".$vendorr_w."',
									vendorr_d='".$vendorr_d."',
									por_r='".$por_r."',
									por_w='".$por_w."',
									por_d='".$por_d."',
									indentr_r='".$indentr_r."',
									indentr_w='".$indentr_w."',
									indentr_d='".$indentr_d."',
									receiver_r='".$receiver_r."',
									receiver_w='".$receiver_w."',
									receiver_d='".$receiver_d."',
									user_r='".$user_r."',
									user_w='".$user_w."',
									user_d='".$user_d."',
									hod_r='".$hod_r."',
									hod_w='".$hod_w."',
									hod_d='".$hod_d."',
									storek_r='".$storek_r."',
									storek_w='".$storek_w."',
									storek_d='".$storek_d."'
									
									where  user_id='".$user_ai_id."'
									
									
				
				
							";
							//echo $qrtyupdte; exit;
							
							$qrtyytt=inventory_query($qrtyupdte);
				
				//echo $qrtyupdte; exit;
				
				
				
			 }else{
					
					$qrtyupdte="insert into module_permission ( 
									category_r,
									category_w,
									category_d,
									subcat_r,
									subcat_w,
									subcat_d,
									deep_r,
									deep_w,
									deep_d,
									tax_r,
									tax_w,
									tax_d,
									item_r,
									item_w,
									item_d,
									indent_r,
									indent_w,
									indent_d,
									po_r,
									po_w,
									po_d,
									cashp_r,
									cashp_w,
									cashp_d,
									vendorr_r,
									vendorr_w,
									vendorr_d,
									por_r,
									por_w,
									por_d,
									indentr_r,
									indentr_w,
									indentr_d,
									receiver_r,
									receiver_w,
									receiver_d,
									user_r,
									user_w,
									user_d,
									hod_r,
									hod_w,
									hod_d,
									storek_r,
									storek_w,
									storek_d,
									user_id
									)
									values(
									'".$category_r."',
									'".$category_w."',
									'".$category_d."',
									'".$subcat_r."',
									'".$subcat_w."',
									'".$subcat_d."',
									'".$deep_r."',
									'".$deep_w."',
									'".$deep_d."',
									'".$tax_r."',
									'".$tax_w."',
									'".$tax_d."',
									'".$item_r."',
									'".$item_w."',
									'".$item_d."',
									'".$indent_r."',
									'".$indent_w."',
									'".$indent_d."',
									'".$po_r."',
									'".$po_w."',
									'".$po_d."',
									'".$cashp_r."',
									'".$cashp_w."',
									'".$cashp_d."',
								    '".$vendorr_r."',
									'".$vendorr_w."',
									'".$vendorr_d."',
									'".$por_r."',
									'".$por_w."',
									'".$por_d."',
									'".$indentr_r."',
									'".$indentr_w."',
									'".$indentr_d."',
									'".$receiver_r."',
									'".$receiver_w."',
									'".$receiver_d."',
									'".$user_r."',
									'".$user_w."',
									'".$user_d."',
									'".$hod_r."',
									'".$hod_w."',
									'".$hod_d."',
									'".$storek_r."',
									'".$storek_w."',
									'".$storek_d."',
									'".$user_ai_id."'
									
									
									
									
									)
									
									
									
				
				
							";
							
							
							$qrtyytt=inventory_query($qrtyupdte);
			 	
				
			 }
			 
			 
			 
			 
			 
			 
		//	 $email=inventory_get_post_escape('email');
			//exit;
			if(inventory_post_isset('is_active')){
				$is_active = 1;	
			}else{
				$is_active = 0;	
			}
			$select_user_details_query = "SELECT * FROM `tbl_user` where fld_ai_id='".$user_ai_id."'  ";
			$select_user_details_query_result = inventory_query($select_user_details_query); 
			if((inventory_num_rows($select_user_details_query_result))>0 ){
				
				
				//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
				
			
				/*if(inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code");
				}
				*/
				if($error_msg == ""){
					
					
						 $inset_into_department_query="update tbl_user set 
						 									fld_name='".$name."',
						 									fld_username='".$username."',
						 									fld_mobile_number='".$mobile_number."',
						 									fld_password='".$password."',
						 								    fld_user_type='".$utype."',
						 									fld_is_active='".$is_active."',
						 									deepuser_id='".$user_dep."'
						 								where 
						 									fld_ai_id='".$user_ai_id."'
						 								";
						                                      	//echo $qry2;
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if($qrtyytt==true){
							$succee_msg = "User Successfully Updated";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					
					
				}
				
				
				
			}else{
				$error_msg = "Duplicate Username or Email or Mobile No Found";	
				//exit();
			}
		}
	}
if($case == "add"){
	if( $user_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
	       //$user_ai_id = "";
			$name="";
		//	$email="";
		//	$city = "";
		//	$address = "";
		//	$pin ="";
			$password = "";
			$mobile_number="";
			$username="";
		//	$password="";
			$user_dep="";
			$is_active=1;
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('add_user')){
			//$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
		//	$city = inventory_get_post_escape('city');
		//	$address = inventory_get_post_escape('address');
		//	$pin = inventory_get_post_escape('pin');
			$password = inventory_get_post_escape('password');
			$username=inventory_get_post_escape('username');
			$name=inventory_get_post_escape('name');
			$mobile_number=inventory_get_post_escape('mobile_number');
			$utype=inventory_get_post_escape('user_type');
			$user_dep=inventory_get_post_escape('user_dep');
		//	$email=inventory_get_post_escape('email');
			if(inventory_post_isset('is_active')){
				$is_active = 1;	
			}else{
				$is_active = 0;	
			}
			 $select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."'  or fld_mobile_number='".trim($mobile_number)."'  ";
			$select_user_details_query_result = inventory_query($select_user_details_query); 
			if((inventory_num_rows($select_user_details_query_result))==0 ){
				
				
				//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
				
				/*if(inventory_validation($city,true,40,4,false,false,false,false,"City") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($city,true,40,4,false,false,false,false,"City");
				}*/
				/*if(inventory_validation($address,true,40,4,false,false,false,false,"Address") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($address,true,40,4,false,false,false,false,"Address");
				}*/
				/*if(inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code");
				}
				*/
				if($error_msg == ""){
					
					/*$inset_into_department_query = "INSERT INTO `tbl_vendor`
					                                            (`fld_name`,
					                                             `fld_username`,
					                                             `fld_mobile_number`,
					                                             `fld_email`,
					                                             `fld_password`,
					                                             `fld_city`,`
					                                             fld_address`,
					                                             `fld_pin`,
					                                             `fld_is_active`
					                                             
					                                             )
						                                      VALUES(
						                                      	'".$name."',
						                                      	'".$username."',
						                                      	'".$mobile_number."',
						                                      	'".$email."',
						                                      	'".$password."',
						                                      	'".$city."',
						                                      	'".$address."',
						                                      	'".$pin."',
						                                      	'".$is_active."'
						                                      	)";
						                       */               	
						                             $inset_into_department_query="INSERT INTO `tbl_user` (`fld_name`, `fld_username`, `fld_mobile_number`,  `fld_password`,  `fld_user_type`, `fld_is_active`,`deepuser_id`)
													  VALUES ( '".$name."',
						                                      	'".$username."',
						                                      	'".$mobile_number."',
						                                      	'".$password."',
						                                      	'".$utype."',
						                                      	'".$is_active."',
						                                      	'".$user_dep."'
						                                      	
						                                      	);";
						                                      	//echo $qry2;
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if(inventory_affected_rows()>0){
							$succee_msg = "User Successfully Added";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					
					
				}
				
				
				
			}else{
				$error_msg = "Duplicate Username  or Mobile No Found";	
				//exit();
			}
		}
	}
	if($case == "list"){
		
		if( $user_r==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		$select_user_details_query = "SELECT * FROM `tbl_user` WHERE `fld_user_type` = 'user' ORDER BY `fld_is_active` DESC ,`fld_name` ASC";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
			    
			    $select_department_query2 = "SELECT * FROM tbl_department WHERE fld_is_active ='1' and fld_ai_id='".$row_data['deepuser_id']."'";
			   $select_department_query_result2 = inventory_query($select_department_query2); 
			   $res=inventory_fetch_assoc($select_department_query_result2);
			     // array_push($depar,$res['fld_department']);
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_name'].'</td>
								<td>'.$row_data['fld_mobile_number'].'</td>
								<td>'.usertype($row_data['fld_user_type']).'</td>
								<td>'.$res['fld_department'].'</td>
								<td>'.$status_array[$row_data['fld_is_active']].'</td>';
								
								if( $user_w==0 ){
										$list .= 	'<td></td></tr>';
										
									}else{
									$list .= 	'<td><center><a href="'.ROOT_PATH.'/editduser/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
										&nbsp;<a href="'.ROOT_PATH.'/deleteduser/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-trash-o" aria-hidden="true"></i></a></center></td>
									</tr>';
									}
								
			}
		}
	}
?>