<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $subcat_r=$rst_rw['subcat_r'];
		 $subcat_w=$rst_rw['subcat_w'];
		 $subcat_d=$rst_rw['subcat_d'];
		
		if($subcat_r==0 && $subcat_w==0 && $subcat_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
		 * 
		 */
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "edit"){
		if($subcat_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$sub_category_id = track64_decode(inventory_get_get('sub_category_id'));
		$subcategory_name = "";
		$category = "";
		$is_active  = "";
		$category_array = array();
		$select_category_query = "SELECT `fld_ai_id`,`fld_category` FROM `tbl_category`";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$category_array[$row_data['fld_ai_id']] = $row_data['fld_category'];
			}
		}
		$select_subcategory_query = "SELECT `fld_category_id`,`fld_sub_category`,`fld_is_active` FROM `tbl_sub_category` WHERE `fld_ai_id` = '".$sub_category_id."';";
		$select_subcategory_query_result = inventory_query($select_subcategory_query); 
		if(inventory_num_rows($select_subcategory_query_result)>0){
			$row_data = inventory_fetch_assoc($select_subcategory_query_result);
			$subcategory_name = $row_data['fld_sub_category'];
			$category = $row_data['fld_category_id'];
			$is_active  = $row_data['fld_is_active'];
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		if($subcat_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$log_text = "";
		$update_text = "";
		$succee_msg = "";
		$error_msg = "";
		$category_array = array();
		$select_category_query = "SELECT `fld_ai_id`,`fld_category` FROM `tbl_category`";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$category_array[$row_data['fld_ai_id']] = $row_data['fld_category'];
			}
		}
		if(inventory_post_isset('edit_subcategory')){	
			$subcategory_name = inventory_get_post_escape('subcategory_name');
			//$category = inventory_get_post_escape('category');
			$sub_category_id = track64_decode(inventory_get_post_escape('sub_category_id'));
			if(inventory_post_isset('is_active')){
				$is_active = 1;
			}else{
				$is_active = 0;
			}
			$select_subcategory_query = "SELECT `fld_category_id`,`fld_sub_category`,`fld_is_active` FROM `tbl_sub_category` WHERE `fld_ai_id` = '".$sub_category_id."';";
			$select_subcategory_query_result = inventory_query($select_subcategory_query); 
			if(inventory_num_rows($select_subcategory_query_result)>0){
				$row_data = inventory_fetch_assoc($select_subcategory_query_result);
				$subcategory_name_db = $row_data['fld_sub_category'];
				$category = $row_data['fld_category_id'];
				$is_active_db  = $row_data['fld_is_active'];
				
				/*if(inventory_validation($category,true,40,1,false,false,false,false,"Name") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($category,true,40,1,false,false,false,false,"Name");
				}*/
				if(inventory_validation($subcategory_name,true,40,2,false,true,false,false,"Name") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($subcategory_name,true,40,2,false,true,false,false,"Name");
				}
				if($error_msg == ""){
					$check_duplicate_subcategory_query = "SELECT `fld_ai_id` FROM `tbl_sub_category` WHERE LOWER(`fld_sub_category`) = LOWER('".$subcategory_name."') AND `fld_ai_id` != '".$sub_category_id."'";
					$check_duplicate_subcategory_query_result = inventory_query($check_duplicate_subcategory_query); 
					if(!inventory_num_rows($check_duplicate_subcategory_query_result)){
						/*if($category != $category_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_category_id =>".$category_db;	
							$update_text .= "fld_category_id = '".$category."' ";
						}*/
						if($subcategory_name != $subcategory_name_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_sub_category =>".$subcategory_name_db;	
							$update_text .= "fld_sub_category = '".$subcategory_name."' ";
						}
						if($is_active != $is_active_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_is_active =>".$is_active_db;	
							$update_text .= "fld_is_active = '".$is_active."' ";
						}
						if($log_text != ""){
							inventory_commit_off();
							$update_department_query = "UPDATE `tbl_sub_category` SET ".$update_text." WHERE `fld_ai_id` = '".$sub_category_id."';";
							$update_department_query_result = inventory_query($update_department_query);
							if(inventory_affected_rows() >0){
								$insert_into_log_query = "INSERT INTO `tbi_edit_log`(`fld_id`,`fld_type`,`fld_log_text`,`fld_edited_by`) VALUES ('".$sub_category_id."','subcategory','".$log_text."','".$user_id."');";
								$insert_into_log_query_result = inventory_query($insert_into_log_query);
								if(inventory_affected_rows() >0){
									inventory_commit();
									$succee_msg = "Subcategory Successfully Updated";
									$case = "list";
								}else{
									$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
									inventory_rollback();
									$case = "edit";
								}
							}else{
								$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
								inventory_rollback();
								$case = "edit";
							}
							inventory_commit_on();
						}else{
							$succee_msg .= "Nothing to update";
							$case = "list";	
						}
					}else{
						$error_msg = "Duplicate Subcategory Name Found";
						$case = "edit";	
					}
				}
			}else{
				include("nopermission.php");
				exit();
			}
		}
	}
	if($case == "add"){
		if($subcat_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$subcategory_name = "";
		$category = "";
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";	
		$category_array = array();
		$select_category_query = "SELECT `fld_ai_id`,`fld_category` FROM `tbl_category` WHERE `fld_isactive` = '1'";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$category_array[$row_data['fld_ai_id']] = $row_data['fld_category'];
			}
		}
		if(inventory_post_isset('add_subcategory')){	
			$subcategory_name = inventory_get_post_escape('subcategory_name');
			$category = inventory_get_post_escape('category');
			if(inventory_validation($category,true,40,1,false,false,false,false,"Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($category,true,40,1,false,false,false,false,"Name");
			}
			if(inventory_validation($subcategory_name,true,40,2,false,true,false,false,"Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($subcategory_name,true,40,2,false,true,false,false,"Name");
			}
			if($error_msg == ""){
				$check_duplicate_subcategory_query = "SELECT `fld_ai_id` FROM `tbl_sub_category` WHERE LOWER(`fld_sub_category`) = LOWER('".$subcategory_name."')";
				$check_duplicate_subcategory_query_result = inventory_query($check_duplicate_subcategory_query); 
				if(!inventory_num_rows($check_duplicate_subcategory_query_result)){
					$insert_into_subcategory = "INSERT INTO`tbl_sub_category`(`fld_category_id`,`fld_sub_category`,`fld_is_active`) VALUES('".$category."','".$subcategory_name."','1');";
					$insert_into_subcategory_result = inventory_query($insert_into_subcategory); 
					if(inventory_affected_rows()>0){
						$succee_msg = "Subcategory Successfully Added";
						$case = "list";
					}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
					}
				}else{
					$error_msg = "Duplicate Subcategory Name Found";	
				}
			}
		}
	}
	if($case == "list"){
		if($subcat_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$list = "";
		$select_subcatagory_query = "SELECT `fld_sub_category`,`tbl_sub_category`.`fld_ai_id`,`tbl_sub_category`.`fld_is_active`,`tbl_category`.`fld_category` FROM `tbl_sub_category` LEFT JOIN `tbl_category` ON `tbl_sub_category`.`fld_category_id` = `tbl_category`.`fld_ai_id` ORDER BY `tbl_sub_category`.`fld_is_active` DESC,`tbl_sub_category`.`fld_sub_category` ASC,`tbl_category`.`fld_category` ASC;";
		$select_subcatagory_query_result = inventory_query($select_subcatagory_query); 
		if(inventory_num_rows($select_subcatagory_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_subcatagory_query_result)){
				$active_class = '';
				$icon_class = "";
				$status = "Active";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
					$status = "Inactive";
				}
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_sub_category'].'</td>
								<td>'.$row_data['fld_category'].'</td>';
				if($subcat_w==0){
					//include("nopermission.php");
					//exit();
					$list .= '<td></td>
							</tr>';
					
				}else{
					$list .= 	'<td><center><a href="'.ROOT_PATH.'/editsubcatagory/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></center></td>
							</tr>';
				}	
								
				
			}
		}
	}
?>