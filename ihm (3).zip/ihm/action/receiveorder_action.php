<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		$usertype=array("admin","hod","user");
		
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $por_r=$rst_rw['por_r'];
		 $por_w=$rst_rw['por_w'];
		 $por_d=$rst_rw['por_d'];
		
		if($por_r==0 && $por_w==0 && $por_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		
		/*if(!in_array($user_type, $usertype) ){
			include("nopermission.php");
			exit();
		}
		 * 
		 */
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "delete"){
		if($por_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_id = track64_decode(inventory_get_get('user_id'));
		
		 $select_department_query = "SELECT * FROM `tbl_user`  WHERE `fld_ai_id` = '".$user_id."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$sql="delete from `tbl_user`  WHERE `fld_ai_id` = '".$user_id."'";
			$qry = inventory_query($sql);
			$succee_msg = "Storekeeper Successfully Deleted";
			$case = "list";
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "edit"){
		if($por_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT  * from  fld_order_new WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$fld_order_id = $row_data['fld_order_id'];
			$no_of_student = $row_data['no_of_student'];
			$indent_create_on = $row_data['indent_create_on'];
			$material_req_on = $row_data['material_req_on'];
			$depid=$row_data['dep_id'];
			$for_class = $row_data['for_class'];
			$menu_name = $row_data['menu_name'];
			$fld_total_amount=$row_data['fld_total_amount'];
			$fld_gross_total=$row_data['fld_gross_total'];
			$fld_cgst = $row_data['fld_cgst'];
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		if($por_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(isset($_POST['add_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='0'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `status`='1'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
					//echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
																	 // echo $itemqryupdate;exit;
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
				$sql="insert into fld_order_new (`fld_order_id`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`) values('".$indentid."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     /*if(inventory_affected_rows()>0){
				$succee_msg = "Indent Final submit Made succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Final submit succesfully";
		    $case="list";
			
			
			
			
		}
		if(isset($_POST['draft_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='0'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				 $totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' 
											 
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
											// echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
							//echo $itemqryupdate;
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						 $itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				//exit;
				
				
				
					
				
			}else{
				$sql="insert into fld_order_new (`fld_order_id`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`) values('".$indentid."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					 	$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		    /* if(inventory_affected_rows()>0){
				$succee_msg = "Indent Draft Updated succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Draft succesfully";
				 $case="list";
			
			
			
			
		}
		if(isset($_POST['approve_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='1'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new  set
											 `approve_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											  status='2'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
											 //echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
														 //echo $itemqryupdate;exit;
					       $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						 $itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
				$sql="insert into fld_order_new (`fld_order_id`,`approve_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`) values('".$indentid."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','2')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			//$succee_msg = "Indent Final submit Made succesfully done";
		   //header('Location:'.inventory_display(ROOT_PATH).'/indent');
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     /*if(inventory_affected_rows()>0){
				$succee_msg = "Indent Aprroved succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Approve succesfully";
		    $case="list";
			
			
			
		}
		
		if(isset($_POST['disapprove_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='1'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				
				$sql="update  fld_order_new set status='3'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql);
				$succee_msg = "Indent Disapprove succesfully";
				 $case="list";
				/*
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new 
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' 
											  'status'='3'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` 
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				*/
					
				
			}
			/*else{
				$sql="insert into fld_order_new (`fld_order_id`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`) values('".$indentid."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','2')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			*/
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		    /* if(inventory_affected_rows()>0){
				$succee_msg = "Indent Disaprroved succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			
			
			
			
			
		}
			
		//$succee_msg = "Indent Final submit Made succesfully done";
	 // header('Location:'.inventory_display(ROOT_PATH).'/indent');
		
	}
if($case == "add"){
	if($por_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
	  if(isset($_POST['add_po_receive'])){
	  	
		$poid=$_POST['poid'];
		$indentid=$_POST['indentid'];
		$venid=$_POST['venid'];
		$reqon=$_POST['reqon'];
		$deepid=$_POST['deepid'];
		$receiveon=$_POST['receiveon'];
		$userid=inventory_get_session(VARIABLE_PREFIX."user_id");
		$totalrow=$_POST['totalrow'];
		$gross=$_POST['total'];
		$tax=$_POST['total_tax'];
		$totalamnt=$_POST['total_amount'];
		$sqlporeceive="INSERT INTO `tbl_receive_entry` (`poid`, `indentid`, `vendorid`, `receiveon`, `orderon`, `crtdby`,`depid`,`gross`,`tax`,`total`) 
						VALUES ('".$poid."', '".$indentid."', '".$venid."', '".$receiveon."', '".$reqon."', '".$userid."','".$deepid."','".$gross."','".$tax."','".$totalamnt."') ";
		inventory_query($sqlporeceive); 
		for($ij=1;$ij<$totalrow;$ij++){
							
				$itemid=$_POST["item_$ij"];	
			    $rqty=$_POST["rcvqty_$ij"];	
				$rcvqty=$_POST["qty_$ij"];
				$price=$_POST["price_$ij"];
				$gross=$_POST["gross_$ij"];
				$tax=$_POST["tax_$ij"];
				$totar=$_POST["totar_$ij"];
				$remarks=$_POST["remarks_$ij"];
				
				$getstock="select * from tbl_item where fld_ai_id='".$itemid."'";
				$resu=inventory_query($getstock);
				$qryfetch=inventory_fetch_assoc($resu);
				
				$cstock=$qryfetch['fld_stock'];
				$nstock=floatval($cstock)+floatval($rcvqty);
				
				$sqryupdt="update tbl_item set fld_stock='".$nstock."' where fld_ai_id='".$itemid."'";
				inventory_query($sqryupdt);
				
			   $sqlitemrec="INSERT INTO `tbl_receive_entry_item` ( `poid`, `itemid`, `reqqty`,`receiveqty`, `unitprice`, `gross`, `tax`, `total`, `depid`, `receiveon`, `crtdby`,`remarks`) 
			             VALUES ('".$poid."', '".$itemid."', '".$rqty."','".$rcvqty."', '".$price."', '".$gross."', '".$tax."', '".$totar."', '".$deepid."', '".$receiveon."', '".$userid."','".$remarks."')";
						 		
				inventory_query($sqlitemrec);
			
		}
		
		
		
		
		
	  	
		
			$succee_msg = "PO Receive entry done succesfully";
		    $case="list";
			
			
		}
		
		
	
	}
	if($case == "list"){
		if($por_r==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		
		

		  $select_po_query = "SELECT  * from `tbl_receive_entry` where status='1'  order by id desc";
			   $select_po_query_result = inventory_query($select_po_query); 
			   if(inventory_num_rows($select_po_query_result)>0){
		      while($row_d = inventory_fetch_assoc($select_po_query_result)){
				//echo 7;
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$row_d['depid']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 /*if($row_d['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  * */
				  
				  
				  $active_class = '';
				$icon_class = "";
				if($row_d['status'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				  
				  
				$list .= 	'<tr '.$active_class.'>
								<td>POID/'.$row_d['poid'].'</td>
								<td>'.$row_d['indentid'].'</td>
								<td>'.$row_d['vendorid'].'</td>
								<td>'.$row_d['receiveon'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_d['orderon'].'</td>';
				if($por_w==0 ){
					$list .=	'<td></td>
									</tr>';
				}else{
						$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/viewreceive/'.track64_encode($row_d['id']).'" '.$icon_class.'>View</a>
							&nbsp;<a target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printreceive/'.track64_encode($row_d['id']).'" '.$icon_class.'>Print</a></center></td>
									</tr>';
					
				}				
								
				
								
								
								
				}		

              }
			   	
	  //  }
	    
			  
		
		
		
	}



	if($case == "view"){
		if($por_r==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT  * from  `tbl_receive_entry` WHERE `id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data_po = inventory_fetch_assoc($select_user_details_query_result);
			//print_r($row_data_po);
			 $indent_id=$row_data_po['indentid'];
			 $poid=$row_data_po['poid'];
			 $require_on=$row_data_po['orderon'];
			 $receiveon=$row_data_po['receiveon'];
				$vendor_id=$row_data_po['vendorid'];
				$depid=$row_data_po['depid'];
				$uniqueid=$user_ai_id;
				
				$gross=$row_data_po['gross'];
				$tax=$row_data_po['tax'];
				$totalamnt=$row_data_po['total'];;
				
				
				//get vendor id
				$select_vendor_query = "select * from tbl_vendor where fld_vn_id='".$vendor_id."' and fld_is_active='1'";
				$select_vendor_result = inventory_query($select_vendor_query);
				$row_data_vendor = inventory_fetch_assoc($select_vendor_result);
			
				$vendorname=$row_data_vendor['fld_vn_id'];
				$vendorid=$row_data_vendor['fld_ai_id'];
				//$venid=
				//get departnema
				
				$select_department_query = "select * from tbl_department where fld_ai_id='".$depid."' and fld_is_active='1'";
				$select_department_result = inventory_query($select_department_query);
				$row_data_deep = inventory_fetch_assoc($select_department_result);
			
				$deepname=$row_data_deep['fld_department'];
				
				
			    /*$select_order_qry = "SELECT  * from `fld_order_new` where status='2'  and  fld_order_id ='".$indent_id."'";
				$select_order_result = inventory_query($select_order_qry); 
				$sqr_res=inventory_fetch_assoc($select_order_result);
				
				$menuname=$sqr_res['menu_name'];
				 * */

			/*$for_class = $row_data['for_class'];
			$menu_name = $row_data['menu_name'];
			$fld_total_amount=$row_data['fld_total_amount'];
			$fld_gross_total=$row_data['fld_gross_total'];
			$fld_cgst = $row_data['fld_cgst'];
			*/
			
		              	
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
?>
