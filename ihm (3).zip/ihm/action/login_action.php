<?php
$username = "";
$password = "";
if(inventory_post_isset('login'))
{
	$username= inventory_get_post_escape('username');
	$password = inventory_get_post_escape('password');
	$insert_query = "";
	$user_authentication_query = "SELECT `venid`,`deepuser_id`,`fld_ai_id`,`fld_name`,`fld_password`,`fld_user_type`,`fld_is_active` FROM `tbl_user` WHERE `fld_username` ='".$username."';";
	$user_authentication_query_result = inventory_query($user_authentication_query); 
	if(inventory_num_rows($user_authentication_query_result)>0){
		$row_data = inventory_fetch_assoc($user_authentication_query_result);
		$user_id = $row_data['fld_ai_id'];
		$name = $row_data['fld_name'];
		$user_type = $row_data['fld_user_type'];
		$db_password = $row_data['fld_password'];
		 $depid=$row_data['deepuser_id'];
		$venid=$row_data['venid'];
		if($depid==0){
			$depid="Not Available";
		}
		if($venid==""){
			$venid=0;
		}
		//exit;
		$is_active = $row_data['fld_is_active'];
		if(!empty($user_type)){
			if(($password) == $db_password){
				if($is_active == '1'){
					inventory_set_session(VARIABLE_PREFIX."name",$name);
					inventory_set_session(VARIABLE_PREFIX."user_id",$user_id);
					inventory_set_session(VARIABLE_PREFIX."venid",$venid);
					inventory_set_session(VARIABLE_PREFIX."dep_id",$depid);
					inventory_set_session(VARIABLE_PREFIX."user_type",$user_type);
					$insert_query = "INSERT INTO `tbl_login_success_log`(`fld_user_id`,`fld_browser`,`fld_ip`) VALUE ('".$user_id."','".inventory_get_user_browser()."','".inventory_get_ip()."');";
				}else{
					inventory_set_session(VARIABLE_PREFIX."login_err","User Inactive. Please Contact Admin for Support.");
				}	
			}else{
				inventory_set_session(VARIABLE_PREFIX."login_err","Invalid Password.");
			}
		}else{
			inventory_set_session(VARIABLE_PREFIX."login_err","Invalid Email or Password");
		}
	}else{
		inventory_set_session(VARIABLE_PREFIX."login_err","Invalid Employee ID.");
	}
	if($insert_query != ""){
		inventory_query($insert_query);
		if(inventory_session_isset(VARIABLE_PREFIX."redirect_url")){
			$url = inventory_get_session(VARIABLE_PREFIX."redirect_url");
			inventory_set_session(VARIABLE_PREFIX."redirect_url","");
			if($url !=""){
			 ?>
				<script type="text/javascript">
				  window.location.href='http://<?php echo $url; ?>';
				</script>
			<?php    }
		}
	}else{
		$insert_query = "INSERT INTO `tbl_login_fail_log`(`fld_user_name`,`fld_broser`,`fld_ip`,`fld_error_message`) VALUE ('".$username."','".inventory_get_user_browser()."','".inventory_get_ip()."','".inventory_get_session(VARIABLE_PREFIX."login_err")."');";
		inventory_query($insert_query);
	}
}
?>