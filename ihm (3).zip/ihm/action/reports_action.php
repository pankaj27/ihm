<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		$usertype=array("admin","hod","user");
		if(!in_array($user_type, $usertype) ){
			include("nopermission.php");
			exit();
		}
	}else{
		include("nopermission.php");
		exit();
	}
	
	if($case == "indentlist"){
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="hod"){
		 $getuserdepidqry="select * from tbl_hod where fld_hod_id='".inventory_get_session(VARIABLE_PREFIX."venid")."'";
		$getuserdepidqry_result = inventory_query($getuserdepidqry); 
        $row_getuserdepidqry = inventory_fetch_assoc($getuserdepidqry_result);
	    $depidhod=explode(",",$row_getuserdepidqry['dep_id']);
		}
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="hod"){
			
			
          $select_user_details_query = "SELECT  * from `fld_order_new` where status='4'  order by fld_ai_id desc";
		 $select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 if(in_array($row_data['dep_id'], $depidhod)){
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				 $select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				 $select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 
				  //gwt semester sectionnn
				  $semester=$row_data['semester'];
				   $select_semester_query  = "SELECT * FROM tbl_semester WHERE fld_ai_id ='".$semester."'";
				 $select_semester_query_result = inventory_query($select_semester_query); 
			     $row_data_semester = inventory_fetch_assoc($select_semester_query_result);
				 $semm_namee=$row_data_semester['fld_category'];
				 
				 
				 
				 
				  
				 
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				 if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  $list .= 	'<tr '.$active_class.'>
				                 <td>'.$row_data['fld_order_id'].'</td>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
							
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$section_namee.'</td>
								<td>'.$semm_namee.'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								/* if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}
								if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
										
								}
                                  */
								
					}			
			}
		}	
		
			
			
			   		
			   	
	    }
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="user"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where cretaed_by='".inventory_get_session(VARIABLE_PREFIX."user_id")."' and status='4'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 
				 
				 //gwt semester sectionnn
				  $semester=$row_data['semester'];
				   $select_semester_query  = "SELECT * FROM tbl_semester WHERE fld_ai_id ='".$semester."'";
				 $select_semester_query_result = inventory_query($select_semester_query); 
			     $row_data_semester = inventory_fetch_assoc($select_semester_query_result);
				 $semm_namee=$row_data_semester['fld_category'];
				 
				 
				 
				 
				  //gwt section nammm
				// echo "<br>";
				  $section=$row_data['section'];
				 $select_section_query = "SELECT * FROM tbl_section WHERE fld_ai_id ='".$section."'";
				 $select_section_query_result = inventory_query($select_section_query); 
			     $row_data_section = inventory_fetch_assoc($select_section_query_result);
				 $section_namee=$row_data_section['fld_category'];
				 
				 
				 
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				$list .= 	'<tr '.$active_class.'>
				                 <td>'.$row_data['fld_order_id'].'</td>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
								
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$section_namee.'</td>
								<td>'.$semm_namee.'</td>
								
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								/* if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}
								if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}
                             */
								
							
			}
		}	
			   	
	    }
	    if(inventory_get_session(VARIABLE_PREFIX."user_type")=="admin"){
			   		
			  
        $select_user_details_query = "SELECT  * from `fld_order_new` where status='4'   order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			    $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 
				 
				  //gwt semester sectionnn
				 $semester=$row_data['semester'];
				 $select_semester_query  = "SELECT * FROM tbl_semester WHERE fld_ai_id ='".$semester."'";
				 $select_semester_query_result = inventory_query($select_semester_query); 
			     $row_data_semester = inventory_fetch_assoc($select_semester_query_result);
				 $semm_namee=$row_data_semester['fld_category'];
				 
				 
				 
				 
				  //gwt section nammm
				// echo "<br>";
				 $section=$row_data['section'];
				 $select_section_query = "SELECT * FROM tbl_section WHERE fld_ai_id ='".$section."'";
				 $select_section_query_result = inventory_query($select_section_query); 
			     $row_data_section = inventory_fetch_assoc($select_section_query_result);
				 $section_namee=$row_data_section['fld_category'];
				 
				
				 
				 
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				$list .= 	'<tr '.$active_class.'>
				                <td>'.$row_data['fld_order_id'].'</td>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
							
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$section_namee.'</td>
								<td>'.$semm_namee.'</td>
								
								<td>'.$row_data['fld_total_amount'].'</td>';
								
								/* if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}else if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}else{
									$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>';
										if($row_data['status']==2){	
										$list .='&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									$list .=	'	</td>
											</tr>';
											
								}
							*/	
							
			}
		}	
			   	
	    }
			  
		
		
		
	}

if($case == "vendorlist"){
		// echo 1;
		$list = "";
		 $select_department_query = "SELECT * FROM `tbl_vendor`";
		$select_department_query_result = inventory_query($select_department_query); 
		if(inventory_num_rows($select_department_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_department_query_result)){
				$active_class = '';
				$icon_class = "";
				$status = "Active";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
					$status = "Inactive";
				}
				//$select_product = "SELECT * FROM `tbl_vendor`";
		       // $select_department_query_result = inventory_query($select_department_query);
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_vn_id'].'</td>
								<td>'.$row_data['fld_name'].'[Prop-'.$row_data['contact_person'].']'.'</td>
								<td>'.$row_data['fld_add'].'</td>
								
								<td>'.$row_data['fld_phn'].'</td>
								<td>'.$row_data['fld_product'].'</td>
								<td>'.$row_data['gstno'].'</td>
								<td>'.$status.'</td>
							</tr>';
			}
		}
	}


if($case == "polist"){
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="user"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where status='2' and cretaed_by='".inventory_get_session(VARIABLE_PREFIX."user_id")."'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		
		}
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="hod"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where status='2' and approve_by='".inventory_get_session(VARIABLE_PREFIX."user_id")."' order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		
		}
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="admin"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where status='2'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		
		}
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="store_keeper"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where status='2'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		
		}
		
		
		//echo 1;
		//$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 //echo 2;
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
						$fld_order_id = $row_data['fld_order_id'];
						//$fld_order_id = $row_data['fld_order_id'];
						$no_of_student = $row_data['no_of_student'];
						$indent_create_on = $row_data['indent_create_on'];
						$material_req_on = $row_data['material_req_on'];
						$fsubmit=$row_data['fld_timestamp'];
						$depid=$row_data['dep_id'];
						$for_class = $row_data['for_class'];
						$menu_name = explode(",",$row_data['menu_name']);
						$menunamecount=count($menu_name);
						$fld_total_amount=$row_data['fld_total_amount'];
						$fld_gross_total=$row_data['fld_gross_total'];
						$fld_cgst = $row_data['fld_cgst'];
						$crtdby=$row_data['cretaed_by'];
						$aprovby=$row_data['approve_by'];
						//get user and approver
						$select_userdeta = "SELECT * FROM  tbl_user WHERE fld_ai_id ='".$crtdby."'";
					    $select_user_result = inventory_query($select_userdeta); 
						$row_data_user = inventory_fetch_assoc($select_user_result);
			            $crtd_by=$row_data_user['fld_name'];
								
						
						// get department data 
						$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$depid."'";
					    $select_department_query_result = inventory_query($select_department_query); 
						$row_data_department = inventory_fetch_assoc($select_department_query_result);
			            $depnm=$row_data_department['fld_department'];



						
						$supplied_vendor=array();				
						  $query1 = "select * from tbl_order_item where order_id='".trim($fld_order_id)."'";
						$qryt=inventory_query($query1);
						while($result1 = inventory_fetch_assoc($qryt)){
							//echo 3;
							 $fld_item_id=$result1['fld_item_id'];
							//$userid=$result1['cretaed_by'];
													
							// get item table data 
							$queryunit1 = "select * from tbl_item where fld_ai_id='".trim($fld_item_id)."'";
						    $resultunit = inventory_query($queryunit1);
							$rowunit=inventory_fetch_assoc($resultunit);
							
							$unitname=$rowunit['fld_unit'];
							$itemname=$rowunit['fld_name'];
							$unitpr=$rowunit['fld_price'];
							$vendorsupl=$rowunit['supplied_vendor'];
							array_push($supplied_vendor,$vendorsupl);
						
						}


					$supplied_vendorunq=array_unique($supplied_vendor);
						//print_r($supplied_vendorunq);
					$supplied_vendorimp=implode(",", $supplied_vendorunq);
						
					$supplied_vendorimpexp=explode(",",$supplied_vendorimp);
						//$supplied_vendorimpexp1=implode(",", $supplied_vendorimpexp);
						//$supplied_vendorimpexp2=explode(",",$supplied_vendorimpexp1);
					$supplied_vendorimpexpun=array_unique($supplied_vendorimpexp);
					$supplied_vendorimpexpunim=implode(",",$supplied_vendorimpexpun);
					$supplied_vendorimpex2=explode(",",$supplied_vendorimpexpunim);

					foreach($supplied_vendorimpex2 as $val)	{
							
							//get latest poid
							//echo 4;
						     $qrylatspo="select * from `tbl_poorder` order by id desc limit 1";
							$qqqq=inventory_query($qrylatspo);
							$rowdat=inventory_fetch_assoc($qqqq);
							//$rowdat="";
							//print_r($rowdat);
							if(isset($rowdat) && !empty($rowdat)){
								$poid=$rowdat['poid'];
								$newpoid=intval($poid)+1;
							}else{
								$newpoid=1;
							}
							
							///check poid already generated
							
							
							 $sqlpoidgenrt="select * from tbl_poorder where indent_id='".$fld_order_id."' and vendor_id='".$val."' ";
							$qtyopp=inventory_query($sqlpoidgenrt);
							//exit;
							//$rowdattt=inventory_fetch_assoc($qtyopp);
							if($qtyopp==true){
								//$rowdattt=inventory_fetch_assoc($qtyopp);
								//echo 5;
								if(inventory_num_rows($qtyopp)>0){
									
								}else{
								$poid=$newpoid;
								$indent_id=$fld_order_id;
								$require_on=$material_req_on;
								//$gross_total=
								$vendor_id=$val;
								$submit_on=$fsubmit;
								$depid=$depid;
								$userid=$crtdby;
								$sql_insertpo="INSERT INTO `tbl_poorder` (`poid`,`indent_id`,`require_on`,`vendor_id`,`submit_on`,`depid`,`userid`) 
											VALUES ('".$poid."','".$indent_id."','".$require_on."','".$vendor_id."','".$submit_on."','".$depid."','".$userid."');";
											inventory_fetch_assoc(inventory_query($sql_insertpo));
							   //exit;
								}
								//}
							}
							
							
							//exit;
							
						}

						
               
				/*
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				 if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				 $list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
								<td>'.$row_data['no_of_student'].'</td>
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$supplied_vendorimpex2.'</td>';
				$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
								
					*/			
								
							
			}
		}



		  $select_po_query = "SELECT  * from `tbl_poorder` where status='1'  order by id desc";
			   $select_po_query_result = inventory_query($select_po_query); 
			   if(inventory_num_rows($select_po_query_result)>0){
		      while($row_d = inventory_fetch_assoc($select_po_query_result)){
				  $active_class = '';
				$icon_class = "";
				if($row_d['status'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				$indennn=$row_d['indent_id'];
				
				$select_indent_qry = "SELECT  * from `fld_order_new` where fld_ai_id='".$indennn."'";
				$select_indent_result = inventory_query($select_indent_qry); 
		        $row_data_indent = inventory_fetch_assoc($select_indent_result);
				
				 //gwt semester sectionnn
				 $semester=$row_data_indent['semester'];
				 $select_semester_query  = "SELECT * FROM tbl_semester WHERE fld_ai_id ='".$semester."'";
				 $select_semester_query_result = inventory_query($select_semester_query); 
			     $row_data_semester = inventory_fetch_assoc($select_semester_query_result);
				 $semm_namee=$row_data_semester['fld_category'];
				 
				 
				 
				 
				  //gwt section nammm
				// echo "<br>";
				 $section=$row_data_indent['section'];
				 $select_section_query = "SELECT * FROM tbl_section WHERE fld_ai_id ='".$section."'";
				 $select_section_query_result = inventory_query($select_section_query); 
			     $row_data_section = inventory_fetch_assoc($select_section_query_result);
				 $section_namee=$row_data_section['fld_category'];
				 
				
				
				//echo 7;
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$row_d['depid']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 /*if($row_d['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  * */
				  
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_d['poid_prex'].'/'.$row_d['poid'].'</td>
								<td>'.$row_d['indent_id'].'</td>
								<td>'.$row_d['vendor_id'].'</td>
								<td>'.$row_d['submit_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$section_namee.'</td>
								<td>'.$semm_namee.'</td>
								<td>'.$row_d['require_on'].'</td>';
								
								
				$list .=	'</tr>';
								
								
				}		

              }
			   	
	  //  }
	    
			  
		
		
		
	}


if($case == "receivelist"){
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		
		

		  $select_po_query = "SELECT  * from `tbl_receive_entry` where status='1'  order by id desc";
			   $select_po_query_result = inventory_query($select_po_query); 
			   if(inventory_num_rows($select_po_query_result)>0){
		      while($row_d = inventory_fetch_assoc($select_po_query_result)){
				//echo 7;
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$row_d['depid']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 /*if($row_d['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  * */
				  
				  
				  $active_class = '';
				$icon_class = "";
				if($row_d['status'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				  
				  
				$indennn=$row_d['indentid'];
				
				$select_indent_qry = "SELECT  * from `fld_order_new` where fld_ai_id='".$indennn."'";
				$select_indent_result = inventory_query($select_indent_qry); 
		        $row_data_indent = inventory_fetch_assoc($select_indent_result);
				
				 //gwt semester sectionnn
				 $semester=$row_data_indent['semester'];
				 $select_semester_query  = "SELECT * FROM tbl_semester WHERE fld_ai_id ='".$semester."'";
				 $select_semester_query_result = inventory_query($select_semester_query); 
			     $row_data_semester = inventory_fetch_assoc($select_semester_query_result);
				 $semm_namee=$row_data_semester['fld_category'];
				 
				 
				 
				 
				  //gwt section nammm
				// echo "<br>";
				 $section=$row_data_indent['section'];
				 $select_section_query = "SELECT * FROM tbl_section WHERE fld_ai_id ='".$section."'";
				 $select_section_query_result = inventory_query($select_section_query); 
			     $row_data_section = inventory_fetch_assoc($select_section_query_result);
				 $section_namee=$row_data_section['fld_category'];
				 
				
				  
				  
				  
				  
				  
				$list .= 	'<tr '.$active_class.'>
								<td>POID/'.$row_d['poid'].'</td>
								<td>'.$row_d['indentid'].'</td>
								<td>'.$row_d['vendorid'].'</td>
								<td>'.$row_d['receiveon'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$section_namee.'</td>
								<td>'.$semm_namee.'</td>
								
								<td>'.$row_d['orderon'].'</td>';
								
								
				$list .=	'</tr>';
								
								
								
				}		

              }
			   	
	  //  }
	    
			  
		
		
		
	}
	
	 if($case == "itemlist"){
	 	
			$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		
		

		     $select_item_qry = "SELECT  * from `tbl_item` where fld_is_active='1'";
			   $select_item_qry_result = inventory_query($select_item_qry); 
			   if(inventory_num_rows($select_item_qry_result)>0){
			   	$sl=1;
		      while($row_d = inventory_fetch_assoc($select_item_qry_result)){
				  
				  $active_class = '';
				$icon_class = "";
				if($row_d['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				 
				 $catg=$row_d['fld_category_id'];
				 //get category name 
				 $qrycate="SELECT  * from `tbl_category` where fld_isactive='1' and fld_ai_id='".$catg."'";
				 $qrycatrslt=inventory_query($qrycate); 
				 $catrr=inventory_fetch_assoc($qrycatrslt);
				 $category=$catrr['fld_category'];
				 
				 $subcat=$row_d['fld_sub_category_id'];
				 
				 $qrysubcate="SELECT  * from `tbl_sub_category` where fld_is_active='1' and fld_ai_id='".$subcat."'";
				 $qrysubcatrslt=inventory_query($qrysubcate); 
				 $subcatrr=inventory_fetch_assoc($qrysubcatrslt);
				 $suvcategory=$subcatrr['fld_sub_category'];
				 
				  
				  
				$list .= 	'<tr '.$active_class.'>
								<td>'.$sl.'</td>
								<td>'.$category.'</td>
								<td>'.$suvcategory.'</td>
								<td>'.$row_d['fld_name'].'</td>
								<td>'.$row_d['stock_qty'].'</td>
								<td>'.$row_d['fld_unit'].'</td>';
								
								
				$list .=	'</tr>';
								
					$sl++;			
								
				}		

              }
			   	
	  //  }
	    
		
		
	 } 




	
?>
