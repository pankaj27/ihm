<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $indent_r=$rst_rw['indent_r'];
		 $indent_w=$rst_rw['indent_w'];
		 $indent_d=$rst_rw['indent_d'];
		
		if($indent_r==0 && $indent_w==0 && $indent_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "delete"){
		if($indent_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_id = track64_decode(inventory_get_get('user_id'));
		
		 $select_department_query = "SELECT * FROM `tbl_user`  WHERE `fld_ai_id` = '".$user_id."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$sql="delete from `tbl_user`  WHERE `fld_ai_id` = '".$user_id."'";
			$qry = inventory_query($sql);
			$succee_msg = "Storekeeper Successfully Deleted";
			$case = "list";
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "edit"){
		if($indent_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT  * from  fld_order_new WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$fld_order_id = $row_data['fld_order_id'];
			$no_of_student = $row_data['no_of_student'];
			$indent_create_on = $row_data['indent_create_on'];
			$material_req_on = $row_data['material_req_on'];
			$depid=$row_data['dep_id'];
			$for_class = $row_data['for_class'];
			$menu_name = $row_data['menu_name'];
			$fld_total_amount=$row_data['fld_total_amount'];
			$fld_gross_total=$row_data['fld_gross_total'];
			$fld_cgst = $row_data['fld_cgst'];
			 $semester= $row_data['semester'];
			 $section= $row_data['section'];
			 $prepairedby=$row_data['prepairedby'];
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		if($indent_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(isset($_POST['add_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='0'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				
				$prepareon=inventory_get_post_escape('prepareon');
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				
				
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `semester`='".$semester."',
											 `section`='".$section."',
											 `status`='1'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
					//echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
																	 // echo $itemqryupdate;exit;
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				
				$prepareon=inventory_get_post_escape('prepareon');
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				
				
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
					
					
				
						
					
					
				
				
				$sql="insert into fld_order_new (`fld_order_id`,`semester`,`section`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`) values('".$indentid."','".$semester."','".$section."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     /*if(inventory_affected_rows()>0){
				$succee_msg = "Indent Final submit Made succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Final submit succesfully";
		    $case="list";
			
			
			
			
		}
		if(isset($_POST['draft_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='0'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				$prepareon=inventory_get_post_escape('prepareon');
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				
				
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				
				echo $totalrow=inventory_get_post_escape('totalrow'); 
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `semester`='".$semester."',
											 `section`='".$section."'
											 
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
											// echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
			       $itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					//echo "<br>";
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					  $sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					$row_data = inventory_fetch_assoc($searchresultitem);
					if(isset($row_data) && !empty($row_data)){
						//echo "<br>";
						//echo 11;
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
							//echo $itemqryupdate;
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
					  $itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
						//echo 12;
					}
					
					
				}
				
			}
				
				
				//exit;
				
				
				
					
				
			}else{
			   $menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				$prepareon=inventory_get_post_escape('prepareon');
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				
				
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
					
				
				$sql="insert into fld_order_new (`fld_order_id`,`semester`,`section`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`) values('".$indentid."','".$semester."','".$section."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					 	$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		    /* if(inventory_affected_rows()>0){
				$succee_msg = "Indent Draft Updated succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Draft succesfully";
				 $case="list";
			
			
			
			
		}
		if(isset($_POST['approve_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='1'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				$prepareon=inventory_get_post_escape('prepareon');
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new  set
											 `approve_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `semester`='".$semester."',
											 `section`='".$section."',
											  status='2'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
											 //echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
														 //echo $itemqryupdate;exit;
					       $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						 $itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
						
					
				
				$sql="insert into fld_order_new (`fld_order_id`,`semester`,`section`,`approve_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`) values('".$indentid."','".$semester."','".$section."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','2')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			//$succee_msg = "Indent Final submit Made succesfully done";
		   //header('Location:'.inventory_display(ROOT_PATH).'/indent');
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     /*if(inventory_affected_rows()>0){
				$succee_msg = "Indent Aprroved succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Approve succesfully";
		    $case="list";
			
			
			
		}
		
		if(isset($_POST['finalapprove_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='2'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$rmrk=inventory_get_post_escape('remarks');
				$sql="update  fld_order_new  set
											 `approve_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `remarks`='".$rmrk."',
											  `semester`='".$semester."',
											 `section`='".$section."',
											  status='4'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
											 //echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
														 //echo $itemqryupdate;exit;
					       $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						 $itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$rmrk=inventory_get_post_escape('remarks');		
					
				
				$sql="insert into fld_order_new (`fld_order_id`,`semester`,`section`,`approve_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`,`remarks`) values('".$indentid."','".$semester."','".$section."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','4','".$rmrk."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
			
			
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		
		
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="admin" || inventory_get_session(VARIABLE_PREFIX."user_type")=="store_keeper"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where status='4' and fld_order_id='".$indentid."'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		
		}
		/*if(inventory_get_session(VARIABLE_PREFIX."user_type")=="store_keeper"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where status='2'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		
		}
		*/
		
		//echo 1;
		//$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 //echo 2;
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
						$fld_order_id = $row_data['fld_order_id'];
						//$fld_order_id = $row_data['fld_order_id'];
						$no_of_student = $row_data['no_of_student'];
						$indent_create_on = $row_data['indent_create_on'];
						$material_req_on = $row_data['material_req_on'];
						$fsubmit=$row_data['fld_timestamp'];
						$depid=$row_data['dep_id'];
						$for_class = $row_data['for_class'];
						$menu_name = explode(",",$row_data['menu_name']);
						$menunamecount=count($menu_name);
						$fld_total_amount=$row_data['fld_total_amount'];
						$fld_gross_total=$row_data['fld_gross_total'];
						$fld_cgst = $row_data['fld_cgst'];
						$crtdby=$row_data['cretaed_by'];
						$aprovby=$row_data['approve_by'];
						//get user and approver
						$select_userdeta = "SELECT * FROM  tbl_user WHERE fld_ai_id ='".$crtdby."'";
					    $select_user_result = inventory_query($select_userdeta); 
						$row_data_user = inventory_fetch_assoc($select_user_result);
			            $crtd_by=$row_data_user['fld_name'];
								
						
						// get department data 
						$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$depid."'";
					    $select_department_query_result = inventory_query($select_department_query); 
						$row_data_department = inventory_fetch_assoc($select_department_query_result);
			            $depnm=$row_data_department['fld_department'];



						
						$supplied_vendor=array();				
						  $query1 = "select * from tbl_order_item where order_id='".trim($fld_order_id)."'";
						$qryt=inventory_query($query1);
						while($result1 = inventory_fetch_assoc($qryt)){
							//echo 3;
							 $fld_item_id=$result1['fld_item_id'];
							//$userid=$result1['cretaed_by'];
													
							// get item table data 
							$queryunit1 = "select * from tbl_item where fld_ai_id='".trim($fld_item_id)."'";
						    $resultunit = inventory_query($queryunit1);
							$rowunit=inventory_fetch_assoc($resultunit);
							
							$unitname=$rowunit['fld_unit'];
							$itemname=$rowunit['fld_name'];
							$unitpr=$rowunit['fld_price'];
							$vendorsupl=$rowunit['supplied_vendor'];
							array_push($supplied_vendor,$vendorsupl);
						
						}


					$supplied_vendorunq=array_unique($supplied_vendor);
						//print_r($supplied_vendorunq);
					$supplied_vendorimp=implode(",", $supplied_vendorunq);
						
					$supplied_vendorimpexp=explode(",",$supplied_vendorimp);
						//$supplied_vendorimpexp1=implode(",", $supplied_vendorimpexp);
						//$supplied_vendorimpexp2=explode(",",$supplied_vendorimpexp1);
					$supplied_vendorimpexpun=array_unique($supplied_vendorimpexp);
					$supplied_vendorimpexpunim=implode(",",$supplied_vendorimpexpun);
					$supplied_vendorimpex2=explode(",",$supplied_vendorimpexpunim);

					foreach($supplied_vendorimpex2 as $val)	{
							
							//get latest poid
							//echo 4;
						     $qrylatspo="select * from `tbl_poorder` order by id desc limit 1";
							$qqqq=inventory_query($qrylatspo);
							$rowdat=inventory_fetch_assoc($qqqq);
							//$rowdat="";
							//print_r($rowdat);
							if(isset($rowdat) && !empty($rowdat)){
								$poid=$rowdat['poid'];
								$newpoid=intval($poid)+1;
							}else{
								$newpoid=1;
							}
							
							///check poid already generated
							
							
							 $sqlpoidgenrt="select * from tbl_poorder where indent_id='".$fld_order_id."' and vendor_id='".$val."' ";
							$qtyopp=inventory_query($sqlpoidgenrt);
							//exit;
							//$rowdattt=inventory_fetch_assoc($qtyopp);
							if($qtyopp==true){
								//$rowdattt=inventory_fetch_assoc($qtyopp);
								//echo 5;
								if(inventory_num_rows($qtyopp)>0){
									
								}else{
								$poid=$newpoid;
								$indent_id=$fld_order_id;
								$require_on=$material_req_on;
								//$gross_total=
								$vendor_id=$val;
								$submit_on=$fsubmit;
								$depid=$depid;
								$userid=$crtdby;
								$sql_insertpo="INSERT INTO `tbl_poorder` (`poid`,`indent_id`,`require_on`,`vendor_id`,`submit_on`,`depid`,`userid`) 
											VALUES ('".$poid."','".$indent_id."','".$require_on."','".$vendor_id."','".$submit_on."','".$depid."','".$userid."');";
											inventory_fetch_assoc(inventory_query($sql_insertpo));
							   //exit;
								}
								//}
							}
							
							
							//exit;
							
						}

						
               
				/*
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				 if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				 $list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
								<td>'.$row_data['no_of_student'].'</td>
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$supplied_vendorimpex2.'</td>';
				$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
								
					*/			
								
							
			}
		}
			
			
			
			
										
			
			
			
			//$succee_msg = "Indent Final submit Made succesfully done";
		   //header('Location:'.inventory_display(ROOT_PATH).'/indent');
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     /*if(inventory_affected_rows()>0){
				$succee_msg = "Indent Aprroved succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Final Approve PO Generate succesfully";
		    $case="list";
			
			
			
		}







		
		if(isset($_POST['disapprove_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='1'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				
				$sql="update  fld_order_new set status='3'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql);
				$succee_msg = "Indent Disapprove succesfully";
				 $case="list";
				/*
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new 
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' 
											  'status'='3'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` 
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				*/
					
				
			}
			/*else{
				$sql="insert into fld_order_new (`fld_order_id`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`) values('".$indentid."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','2')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			*/
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		    /* if(inventory_affected_rows()>0){
				$succee_msg = "Indent Disaprroved succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			
			
			
			
			
		}
			
		//$succee_msg = "Indent Final submit Made succesfully done";
	 // header('Location:'.inventory_display(ROOT_PATH).'/indent');
		
	}
if($case == "add"){
	  	if($indent_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
	  
	
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
	
	//echo 1; exit;
	       //$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
				
			//check if indent already created or not
		if(isset($_POST['add_indent'])){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_order_new where fld_order_id='".$indentid."' and status='0'  ";
		      $qryrslt=inventory_query($serachindentno);
			$searchresult1 = inventory_fetch_assoc($qryrslt);
			if(isset($searchresult1) && !empty($searchresult1)){
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				
				$prepareon=inventory_get_post_escape('prepareon');
				$preby=inventory_get_post_escape('preby');
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				
				
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_order_new set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `semester`='".$semester."',
											 `section`='".$section."',
											 `prepairedby`='".$preby."'
											 `status`='1'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_order_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_order_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
			    $menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				$preby=inventory_get_post_escape('preby');
				//$prepareon2ex=explode("/",$prepareon2);
				//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				//$reqon2ex=explode("/",$reqon2);
				//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
			   	$sql="insert into fld_order_new (`fld_order_id`,`semester`,`section`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`,`prepairedby`) values('".$indentid."','".$semester."','".$section."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','1','".$preby."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					 	$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     if(inventory_affected_rows()>0){
				$succee_msg = "Indent Final submit succesfully";
				 $case="list";
				//$succee_msg = "Indent Final submit Made succesfully done";
		       //header('Location:'.inventory_display(ROOT_PATH).'/indent');
			//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			
			
			
			
			
		}
	
   if(isset($_POST['draft_indent'])){
			//$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
			$menu = inventory_get_post_escape('menu');
			$indentid=inventory_get_post_escape('indent');
			$nostu=inventory_get_post_escape('nostu');
			$class=inventory_get_post_escape('class');
			$semester=inventory_get_post_escape('semester');
			$section=inventory_get_post_escape('section');
				
			$preby=inventory_get_post_escape('preby');
				
			$prepareon=inventory_get_post_escape('prepareon');
			//$prepareon2ex=explode("/",$prepareon2);
			//$prepareon=$prepareon2ex[2]."-".$prepareon2ex[0]."-".$prepareon2ex[1];
			
			$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
			
			$reqon=inventory_get_post_escape('reqon');
			//$reqon2ex=explode("/",$reqon2);
			//$reqon=$reqon2ex[2]."-".$reqon2ex[0]."-".$reqon2ex[1];
			
			$totalrow=inventory_get_post_escape('totalrow');
			$total=inventory_get_post_escape('total');
			$total_amount=inventory_get_post_escape('total_amount');
			$tax=inventory_get_post_escape('total_tax');
			$sql="insert into fld_order_new (`fld_order_id`,`semester`,`section`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`prepairedby`) values('".$indentid."','".$semester."','".$section."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','".$preby."')";
			$select_user_details_query_result = inventory_query($sql); 
			for($ik=1;$ik<=$totalrow;$ik++){
				$itemnam=$_POST["item_$ik"];
				$catid=$_POST["category_$ik"];
				$subcatid=$_POST["subcategory_$ik"];
				$qty=$_POST["qty_$ik"];
				$price=$_POST["price_$ik"];
				$gross=$_POST["gross_$ik"];
				$tax=$_POST["tax_$ik"];
				$totar=$_POST["totar_$ik"];
				$taxval=(floatval($gross)*floatval($tax))*2/100;
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$itemqry="INSERT INTO `tbl_order_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					$select_user_details_query_result = inventory_query($itemqry); 
				}
				
			}
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     if(inventory_affected_rows()>0){
				//$succee_msg = "Indent Successfully Added to draft";
				//header(inventory_display(ROOT_PATH).'/indent');
				$succee_msg = "Indent Final submit Made succesfully done";
				$case="list";
		      //  header('Location:'.inventory_display(ROOT_PATH).'/indent');
			
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			
			
			
			
		
	}
	}
	if($case == "list"){
		if($indent_r==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="hod"){
		 $getuserdepidqry="select * from tbl_hod where fld_hod_id='".inventory_get_session(VARIABLE_PREFIX."venid")."'";
		$getuserdepidqry_result = inventory_query($getuserdepidqry); 
        $row_getuserdepidqry = inventory_fetch_assoc($getuserdepidqry_result);
	    $depidhod=explode(",",$row_getuserdepidqry['dep_id']);
		}
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="hod"){
			
			
         $select_user_details_query = "SELECT  * from `fld_order_new`  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 if(in_array($row_data['dep_id'], $depidhod)){
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  if($row_data['status']==4){$st="<button class='btn btn-success btn-xs'>Complete</button>"; }
				$list .= 	'<tr '.$active_class.'>
				                 <td>'.$row_data['fld_order_id'].'</td>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
							
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2 || $row_data['status']==4){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}else if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2 || $row_data['status']==4){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}else{
									$list .=	'<td><center>&nbsp;';
										if($row_data['status']==2 || $row_data['status']==4){	
										$list .='
										<a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
											
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									if($row_data['status']==4){	
										$list .='
										<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									
									$list .=	'	</td>
											</tr>';
											
								}
								
					}			
			}
		}	
		
			
			
			   		
			   	
	    }
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="user"){
        $select_user_details_query = "SELECT  * from `fld_order_new` where cretaed_by='".inventory_get_session(VARIABLE_PREFIX."user_id")."'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  if($row_data['status']==4){$st="<button class='btn btn-success btn-xs'>Complete</button>"; }
				 
				$list .= 	'<tr '.$active_class.'>
				                 <td>'.$row_data['fld_order_id'].'</td>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
								
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2 || $row_data['status']==4){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}else if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2 || $row_data['status']==4){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}else{
									$list .=	'<td><center>&nbsp;';
										if($row_data['status']==2 || $row_data['status']==4){	
										$list .='
										<a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
											
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									if($row_data['status']==4){	
										$list .='
										<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									
									$list .=	'	</td>
											</tr>';
											
								}
								
							
			}
		}	
			   	
	    }
	    if(inventory_get_session(VARIABLE_PREFIX."user_type")=="admin" || inventory_get_session(VARIABLE_PREFIX."user_type")=="store_keeper"){
			   		
			  
        $select_user_details_query = "SELECT  * from `fld_order_new`   order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved & Send to Store Keeper</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  if($row_data['status']==4){$st="<button class='btn btn-success btn-xs'>Complete</button>"; }
				 
				  $list .= 	'<tr '.$active_class.'>
				                <td>'.$row_data['fld_order_id'].'</td>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
							
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2 || $row_data['status']==4){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}else if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2 || $row_data['status']==4){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}else{
									$list .=	'<td><center>&nbsp;';
										if($row_data['status']==2){	
										$list .='
										<a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
											
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									if($row_data['status']==4){	
										$list .='
										<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									
									$list .=	'	</td>
											</tr>';
											
								}
								
							
			}
		}	
			   	
	    }
			  
		
		
		
	}



	if($case == "view"){
		if($indent_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT  * from  fld_order_new WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$fld_order_id = $row_data['fld_order_id'];
			$no_of_student = $row_data['no_of_student'];
			$indent_create_on = $row_data['indent_create_on'];
			$material_req_on = $row_data['material_req_on'];
			$depid=$row_data['dep_id'];
			$for_class = $row_data['for_class'];
			$menu_name = $row_data['menu_name'];
			$fld_total_amount=$row_data['fld_total_amount'];
			$fld_gross_total=$row_data['fld_gross_total'];
			$fld_cgst = $row_data['fld_cgst'];
			 $semester= $row_data['semester'];
			 $section= $row_data['section'];
			
			
			
		              	
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
?>
