<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $item_r=$rst_rw['item_r'];
		 $item_w=$rst_rw['item_w'];
		 $item_d=$rst_rw['item_d'];
		
		if($item_r==0 && $item_w==0 && $item_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}*/
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "getsubcategory"){
		$option_list = "";
		if(inventory_post_isset('category')){
			$category = inventory_get_post_escape('category');	
			$select_subcategory_query = "SELECT `fld_sub_category`,`fld_ai_id` FROM `tbl_sub_category` WHERE `fld_is_active` = '1' AND `fld_category_id` = '".$category."';";
			$select_subcategory_query_result = inventory_query($select_subcategory_query); 
			if(inventory_num_rows($select_subcategory_query_result)>0){
				while($row_data = inventory_fetch_assoc($select_subcategory_query_result)){
					$option_list .= '<option value="'.$row_data['fld_ai_id'].'">'.$row_data['fld_sub_category'].'</option>';
				}
			}
			echo '<label class="col-lg-3 control-label text-lg-right pt-2" for="service">Subcategory<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "subcategory">
                            <option value="">Select</option>
                            '.$option_list.'
                        </select>
                    </div>';
		}
	}
	if($case == "edit"){
		if($item_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$item_id = track64_decode(inventory_get_get('item_id'));
		$category_array = array();
		$sub_category_array = array();
		$unit_array = array();
		$tax_array = array();
		$category = "";
		$subcategory = "";
		$item_name = "";
		$item_unit = "";
		$price = "";
		$stock  = "";
		$alert_quantity = "";
		$is_stockable = "0";
		$tax = "";
		$succee_msg = "";
		$error_msg = "";
		$select_category_query = "SELECT `fld_ai_id`,`fld_category` FROM `tbl_category` WHERE `fld_isactive` = '1'";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$category_array[$row_data['fld_ai_id']] = $row_data['fld_category'];
			}
		}
		$select_unit_query = "SELECT `fld_unit` FROM `tbl_unit` WHERE `fld_is_active` = '1'";
		$select_unit_query_result = inventory_query($select_unit_query); 
		if(inventory_num_rows($select_unit_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_unit_query_result)){
				$unit_array[$row_data['fld_unit']] = $row_data['fld_unit'];
			}
		}
		$select_tax_query = "SELECT `fld_ai_id`,`fld_sgst`,`fld_cgst`,`fld_is_active` FROM `tbl_tax`  WHERE `fld_is_active` = '1'";
		$select_tax_query_result = inventory_query($select_tax_query); 
		if(inventory_num_rows($select_tax_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_tax_query_result)){
				$tax_array[$row_data['fld_ai_id']] = "CGST: ".$row_data['fld_cgst']."%, SGST: ".$row_data['fld_sgst']."%";
			}
		}
		
		//get vendor id
		
		$select_vendor_query = "SELECT * FROM `tbl_vendor`  WHERE `fld_is_active` = '1'";
		$select_vendor_query_result = inventory_query($select_vendor_query); 
		if(inventory_num_rows($select_vendor_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_vendor_query_result)){
				$vendor_array[$row_data['fld_ai_id']] = $row_data['fld_name'];
			}
		}
		$select_subcategory_query = "SELECT `fld_sub_category`,`fld_ai_id` FROM `tbl_sub_category` WHERE `fld_is_active` = '1'";
			$select_subcategory_query_result = inventory_query($select_subcategory_query); 
			if(inventory_num_rows($select_subcategory_query_result)>0){
				while($row_data = inventory_fetch_assoc($select_subcategory_query_result)){
					$sub_category_array[$row_data['fld_ai_id']] = $row_data['fld_sub_category'];
				}
			}
		$select_item_details_query = "SELECT * FROM `tbl_item` WHERE `fld_ai_id` = '".$item_id."';";
		$select_item_details_query_result = inventory_query($select_item_details_query); 
		if(inventory_num_rows($select_item_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_item_details_query_result);
			$category = $row_data['fld_category_id'];
			 $subcategory = $row_data['fld_sub_category_id'];
			$item_name = $row_data['fld_name'];
			$item_unit = $row_data['fld_unit'];
			$price = $row_data['fld_price'];
			$stock  = $row_data['fld_stock'];
			$alert_quantity = $row_data['fld_alert_stock'];
			$is_stockable = $row_data['fld_is_stockable'];
			$tax = $row_data['fld_category_id'];
			$vendoredit=$row_data['supplied_vendor'];
			$is_active = $row_data['fld_is_active'];
		}else{
			include("nopermission.php");
			exit();
		}
	}
    if($case == "update"){
		if($item_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$category_array = array();
		$sub_category_array = array();
		$unit_array = array();
		$tax_array = array();
		$vendor_array=array();
		$category = "";
		$subcategory = "";
		$item_name = "";
		$item_unit = "";
		$price = "";
		$stock  = "";
		$alert_quantity = "";
		$is_stockable = "0";
		$tax = "";
		$vendor="";
		$succee_msg = "";
		$error_msg = "";
		$select_category_query = "SELECT `fld_ai_id`,`fld_category` FROM `tbl_category` WHERE `fld_isactive` = '1'";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$category_array[$row_data['fld_ai_id']] = $row_data['fld_category'];
			}
		}
		$select_unit_query = "SELECT `fld_unit` FROM `tbl_unit` WHERE `fld_is_active` = '1'";
		$select_unit_query_result = inventory_query($select_unit_query); 
		if(inventory_num_rows($select_unit_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_unit_query_result)){
				$unit_array[$row_data['fld_unit']] = $row_data['fld_unit'];
			}
		}
		$select_tax_query = "SELECT `fld_ai_id`,`fld_sgst`,`fld_cgst`,`fld_is_active` FROM `tbl_tax`  WHERE `fld_is_active` = '1'";
		$select_tax_query_result = inventory_query($select_tax_query); 
		if(inventory_num_rows($select_tax_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_tax_query_result)){
				$tax_array[$row_data['fld_ai_id']] = "CGST: ".$row_data['fld_cgst']."%, SGST: ".$row_data['fld_sgst']."%";
			}
		}
		//get vendor id
		
		$select_vendor_query = "SELECT * FROM `tbl_vendor`  WHERE `fld_is_active` = '1'";
		$select_vendor_query_result = inventory_query($select_vendor_query); 
		if(inventory_num_rows($select_vendor_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_vendor_query_result)){
				$vendor_array[$row_data['fld_ai_id']] = $row_data['fld_name'];
			}
		}
		if(inventory_post_isset('add_item')){
			$item_name =inventory_get_post_escape('item_name');
			$category = inventory_get_post_escape('category');
			$subcategory = inventory_get_post_escape('subcategory');
			$item_unit = inventory_get_post_escape('item_unit');
			$price = inventory_get_post_escape('price');
			$tax = inventory_get_post_escape('tax');
		    $vendor=implode(",",$_POST['vendors']);
			$itemid=$_POST['itemid'];
			if(inventory_post_isset('is_stockable')){
				$is_stockable = "1";
			}else{
				$is_stockable = "0";
			}
			if(inventory_post_isset('stock')){
				$stock  = inventory_get_post_escape('stock');
			}else{
				$stock = "0";
			}
			if(inventory_post_isset('alert_quantity')){
				$alert_quantity  = inventory_get_post_escape('alert_quantity');
			}else{
				$alert_quantity = "0";
			}
			if(inventory_validation($item_name,true,40,2,false,true,false,false,"Item Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($item_name,true,40,2,false,true,false,false,"Item Name");
			}
			if(inventory_validation($category,true,40,1,false,true,false,false,"Category") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($category,true,40,1,false,true,false,false,"Category");
			}
			if(inventory_validation($subcategory,true,40,1,false,true,false,false,"Subcategory") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($subcategory,true,40,1,false,true,false,false,"Subcategory");
			}
			if(inventory_validation($item_unit,true,40,1,false,true,false,false,"Unit") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($item_unit,true,40,1,false,true,false,false,"Unit");
			}
			if(inventory_validation($price,true,40,1,false,true,false,true,"Price") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($price,true,40,1,false,true,false,true,"Price");
			}
			if($is_stockable == "1"){
				if(inventory_validation($stock,true,40,1,false,true,false,true,"Stock") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($stock,true,40,1,false,true,false,true,"Stock");
				}
				if(inventory_validation($alert_quantity,true,40,1,false,true,false,true,"Alert Quantity") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($alert_quantity,true,40,1,false,true,false,true,"Alert Quantity");
				}
			}else{
				$stock = "0";
				$alert_quantity = "0";	
			}
			if(inventory_validation($tax,true,40,1,false,true,false,false,"Tax") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($tax,true,40,1,false,true,false,false,"Tax");
			}
			
			if(inventory_validation($vendor,true,40,1,false,true,false,false,"Vendor") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($tax,true,40,1,false,true,false,false,"Vendor");
			}
			
			
			
			
			$select_subcategory_query = "SELECT `fld_sub_category`,`fld_ai_id` FROM `tbl_sub_category` WHERE `fld_is_active` = '1' AND `fld_category_id` = '".$category."';";
			$select_subcategory_query_result = inventory_query($select_subcategory_query); 
			if(inventory_num_rows($select_subcategory_query_result)>0){
				while($row_data = inventory_fetch_assoc($select_subcategory_query_result)){
					$sub_category_array[$row_data['fld_ai_id']] = $row_data['fld_sub_category'];
				}
			}
			if($error_msg == ""){
				$check_duplicate_item_query = "SELECT * from tbl_item where fld_ai_id='".$itemid."'  ";
				$check_duplicate_item_query_result = inventory_query($check_duplicate_item_query);
				$inventory_rst=inventory_fetch_assoc($check_duplicate_item_query_result); 
				if(isset($inventory_rst) && !empty($inventory_rst)){
					$insert_into_item = "update `tbl_item` set `fld_category_id`='".$category."',
																`fld_sub_category_id`='".$subcategory."',
																`fld_name`='".$item_name."',
																`supplied_vendor`='".$vendor."',
																`fld_unit`='".$item_unit."',
																`fld_price`='".$price."',
																`fld_is_stockable`='".$is_stockable."',
																`fld_stock`='".$stock."',
																`fld_alert_stock`='".$alert_quantity."',
																`fld_is_active`='1',
																`tbl_tax`='".$tax."' where fld_ai_id='".$itemid."'";
					$insert_into_item_result = inventory_query($insert_into_item); 
					if(inventory_affected_rows()>0){
						$succee_msg = "Item Successfully Updated";
						$case = "list";
					}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
					}
				}else{
					$error_msg = "Duplicate Item Name Found";	
				}
			}
		}
	}



	if($case == "add"){
		if($item_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$category_array = array();
		$sub_category_array = array();
		$unit_array = array();
		$tax_array = array();
		$vendor_array=array();
		$category = "";
		$subcategory = "";
		$item_name = "";
		$item_unit = "";
		$price = "";
		$stock  = "";
		$alert_quantity = "";
		$is_stockable = "0";
		$tax = "";
		$vendor="";
		$succee_msg = "";
		$error_msg = "";
		$select_category_query = "SELECT `fld_ai_id`,`fld_category` FROM `tbl_category` WHERE `fld_isactive` = '1'";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$category_array[$row_data['fld_ai_id']] = $row_data['fld_category'];
			}
		}
		$select_unit_query = "SELECT `fld_unit` FROM `tbl_unit` WHERE `fld_is_active` = '1'";
		$select_unit_query_result = inventory_query($select_unit_query); 
		if(inventory_num_rows($select_unit_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_unit_query_result)){
				$unit_array[$row_data['fld_unit']] = $row_data['fld_unit'];
			}
		}
		$select_tax_query = "SELECT `fld_ai_id`,`fld_sgst`,`fld_cgst`,`fld_is_active` FROM `tbl_tax`  WHERE `fld_is_active` = '1'";
		$select_tax_query_result = inventory_query($select_tax_query); 
		if(inventory_num_rows($select_tax_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_tax_query_result)){
				$tax_array[$row_data['fld_ai_id']] = "CGST: ".$row_data['fld_cgst']."%, SGST: ".$row_data['fld_sgst']."%";
			}
		}
		//get vendor id
		
		$select_vendor_query = "SELECT * FROM `tbl_vendor`  WHERE `fld_is_active` = '1'";
		$select_vendor_query_result = inventory_query($select_vendor_query); 
		if(inventory_num_rows($select_vendor_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_vendor_query_result)){
				$vendor_array[$row_data['fld_ai_id']] = $row_data['fld_name'];
			}
		}
		if(inventory_post_isset('add_item')){
			$item_name =inventory_get_post_escape('item_name');
			$category = inventory_get_post_escape('category');
			$subcategory = inventory_get_post_escape('subcategory');
			$item_unit = inventory_get_post_escape('item_unit');
			$price = inventory_get_post_escape('price');
			$tax = inventory_get_post_escape('tax');
		    $vendor=implode(",",$_POST['vendors']);
			if(inventory_post_isset('is_stockable')){
				$is_stockable = "1";
			}else{
				$is_stockable = "0";
			}
			if(inventory_post_isset('stock')){
				$stock  = inventory_get_post_escape('stock');
			}else{
				$stock = "0";
			}
			if(inventory_post_isset('alert_quantity')){
				$alert_quantity  = inventory_get_post_escape('alert_quantity');
			}else{
				$alert_quantity = "0";
			}
			if(inventory_validation($item_name,true,40,2,false,true,false,false,"Item Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($item_name,true,40,2,false,true,false,false,"Item Name");
			}
			if(inventory_validation($category,true,40,1,false,true,false,false,"Category") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($category,true,40,1,false,true,false,false,"Category");
			}
			if(inventory_validation($subcategory,true,40,1,false,true,false,false,"Subcategory") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($subcategory,true,40,1,false,true,false,false,"Subcategory");
			}
			if(inventory_validation($item_unit,true,40,1,false,true,false,false,"Unit") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($item_unit,true,40,1,false,true,false,false,"Unit");
			}
			if(inventory_validation($price,true,40,1,false,true,false,true,"Price") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($price,true,40,1,false,true,false,true,"Price");
			}
			if($is_stockable == "1"){
				if(inventory_validation($stock,true,40,1,false,true,false,true,"Stock") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($stock,true,40,1,false,true,false,true,"Stock");
				}
				if(inventory_validation($alert_quantity,true,40,1,false,true,false,true,"Alert Quantity") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($alert_quantity,true,40,1,false,true,false,true,"Alert Quantity");
				}
			}else{
				$stock = "0";
				$alert_quantity = "0";	
			}
			if(inventory_validation($tax,true,40,1,false,true,false,false,"Tax") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($tax,true,40,1,false,true,false,false,"Tax");
			}
			
			if(inventory_validation($vendor,true,40,1,false,true,false,false,"Vendor") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($tax,true,40,1,false,true,false,false,"Vendor");
			}
			
			
			
			
			$select_subcategory_query = "SELECT `fld_sub_category`,`fld_ai_id` FROM `tbl_sub_category` WHERE `fld_is_active` = '1' AND `fld_category_id` = '".$category."';";
			$select_subcategory_query_result = inventory_query($select_subcategory_query); 
			if(inventory_num_rows($select_subcategory_query_result)>0){
				while($row_data = inventory_fetch_assoc($select_subcategory_query_result)){
					$sub_category_array[$row_data['fld_ai_id']] = $row_data['fld_sub_category'];
				}
			}
			if($error_msg == ""){
				$check_duplicate_item_query = "SELECT `fld_ai_id` FROM `tbl_item` WHERE LOWER(`fld_name`) = LOWER('".$item_name."')";
				$check_duplicate_item_query_result = inventory_query($check_duplicate_item_query); 
				if(!inventory_num_rows($check_duplicate_item_query_result)){
					$insert_into_item = "INSERT INTO `tbl_item`(`fld_category_id`,`fld_sub_category_id`,`fld_name`,`supplied_vendor`,`fld_unit`,`fld_price`,`fld_is_stockable`,`fld_stock`,`fld_alert_stock`,`fld_is_active`,`tbl_tax`) VALUES ('".$category."','".$subcategory."','".$item_name."','".$vendor."','".$item_unit."','".$price."','".$is_stockable."','".$stock."','".$alert_quantity."','1','".$tax."')";
					$insert_into_item_result = inventory_query($insert_into_item); 
					if(inventory_affected_rows()>0){
						$succee_msg = "Item Successfully Added";
						$case = "list";
					}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
					}
				}else{
					$error_msg = "Duplicate Item Name Found";	
				}
			}
		}
	}
	if($case == "list"){
		if($item_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$list = "";	
		$select_item_details_query = "SELECT 
									  `tbl_item`.`fld_ai_id`,
									  `fld_name`,
									  `fld_unit`,
									  `fld_price`,
									  `tbl_item`.`supplied_vendor`,
									  `tbl_item`.`fld_is_active`,
									  `tbl_category`.`fld_category`,
									  `tbl_sub_category`.`fld_sub_category` 
									FROM
									  `tbl_item` 
									  LEFT JOIN `tbl_category` 
										ON `tbl_item`.`fld_category_id` = `tbl_category`.`fld_ai_id` 
									  LEFT JOIN `tbl_sub_category` 
										ON `tbl_item`.`fld_sub_category_id` = `tbl_sub_category`.`fld_ai_id` 
									ORDER BY `tbl_item`.`fld_is_active` DESC,
									  `tbl_item`.`fld_name` ASC ";
		$select_item_details_query_result = inventory_query($select_item_details_query); 
		if(inventory_num_rows($select_item_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_item_details_query_result)){
				$active_class = '';
				$icon_class = "";
				$status = "Active";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
					$status = "Inactive";
				}
				
				$vendor=$row_data['supplied_vendor'];
				$getvendorid_qry="select * from tbl_vendor where fld_ai_id='".$vendor."'";
				$qryrs=inventory_query($getvendorid_qry); 
				$row_data2 = inventory_fetch_assoc($qryrs);
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_name'].'</td>
								<td>'.$row_data['fld_unit'].'</td>
								<td><i class="fa fa-inr" aria-hidden="true"></i> '.$row_data['fld_price'].'</td>
								<td>'.$row_data['fld_category'].'</td>
								<td>'.$row_data['fld_sub_category'].'</td>
								<td>'.$row_data2['fld_vn_id'].'</td>';
							    if($item_w==0 ){
									$list .='<td></td>
													</tr>';
									
								}else{
									$list .='<td><center><a href="'.ROOT_PATH.'/edititem/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></center></td>
													</tr>';
								}
								
			}
		}
	}
?>