<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		$usertype=array("admin","hod","user");
		
		 $sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $cashp_r=$rst_rw['cashp_r'];
		 $cashp_w=$rst_rw['cashp_w'];
		 $cashp_d=$rst_rw['cashp_d'];
		
		if($cashp_r==0 && $cashp_w==0 && $cashp_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		
		/*if(!in_array($user_type, $usertype) ){
			include("nopermission.php");
			exit();
		}
		 * */
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "delete"){
		if($cashp_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_id = track64_decode(inventory_get_get('user_id'));
		
		 $select_department_query = "SELECT * FROM `tbl_user`  WHERE `fld_ai_id` = '".$user_id."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$sql="delete from `tbl_user`  WHERE `fld_ai_id` = '".$user_id."'";
			$qry = inventory_query($sql);
			$succee_msg = "Storekeeper Successfully Deleted";
			$case = "list";
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "edit"){
		if($cashp_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT  * from  fld_cash_purchase WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$fld_order_id = $row_data['fld_order_id'];
			//$no_of_student = $row_data['no_of_student'];
			$indent_create_on = $row_data['indent_create_on'];
			$material_req_on = $row_data['material_req_on'];
			$depid=$row_data['dep_id'];
			$for_class = $row_data['for_class'];
			//$menu_name = $row_data['menu_name'];
			$fld_total_amount=$row_data['fld_total_amount'];
			$fld_gross_total=$row_data['fld_gross_total'];
			$fld_cgst = $row_data['fld_cgst'];
			$semester=$row_data['semester'];
			$section=$row_data['section'];
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		if($cashp_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(isset($_POST['add_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_cash_purchase where fld_order_id='".$indentid."' and status='0'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				//$menu = inventory_get_post_escape('menu');
				//$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_cash_purchase set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `status`='1'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
					//echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_cashpurchase_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_cashpurchase_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
																	 // echo $itemqryupdate;exit;
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						$itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
				$sql="insert into fld_cash_purchase (`fld_order_id`,`cretaed_by`,`dep_id`,`indent_create_on`,`material_req_on`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`) values('".$indentid."','".$crtd."','".$class."','".$prepareon."','".$reqon."','".$total."','".$tax."','".$total_amount."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     /*if(inventory_affected_rows()>0){
				$succee_msg = "Indent Final submit Made succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Cash Purchase Final submit succesfully";
		    $case="list";
			
			
			
			
		}
		if(isset($_POST['draft_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_cash_purchase where fld_order_id='".$indentid."' and status='0'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				//$menu = inventory_get_post_escape('menu');
				//$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_cash_purchase set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' 
											 
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
											// echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_cashpurchase_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_cashpurchase_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
							//echo $itemqryupdate;
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						 $itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				//exit;
				
				
				
					
				
			}else{
				
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
					
				
				$sql="insert into fld_cash_purchase (`fld_order_id`,`cretaed_by`,`dep_id`,`indent_create_on`,`material_req_on`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`) values('".$indentid."','".$crtd."','".$class."','".$prepareon."','".$reqon."','".$total."','".$tax."','".$total_amount."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					 	$itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		    /* if(inventory_affected_rows()>0){
				$succee_msg = "Indent Draft Updated succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Cash Purchase Draft succesfully";
				 $case="list";
			
			
			
			
		}
		if(isset($_POST['approve_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_cash_purchase where fld_order_id='".$indentid."' and status='1'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				//$menu = inventory_get_post_escape('menu');
				//$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_cash_purchase  set
											 `approve_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											  status='2'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
											 //echo $sql;
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_cashpurchase_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_cashpurchase_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
														 //echo $itemqryupdate;exit;
					       $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						 $itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
						
					
				
				$sql="insert into fld_cash_purchase (`fld_order_id`,`approve_by`,`dep_id`,`indent_create_on`,`material_req_on`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`) values('".$indentid."','".$crtd."','".$class."','".$prepareon."','".$reqon."','".$total."','".$tax."','".$total_amount."','2')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			//$succee_msg = "Indent Final submit Made succesfully done";
		   //header('Location:'.inventory_display(ROOT_PATH).'/indent');
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     /*if(inventory_affected_rows()>0){
				$succee_msg = "Indent Aprroved succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			$succee_msg = "Indent Approve succesfully";
		    $case="list";
			
			
			
		}
		
		if(isset($_POST['disapprove_indent']) ){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_cash_purchase where fld_order_id='".$indentid."' and status='1'  ";
			$searchresult1 = inventory_query($serachindentno);
			if(isset($searchresult1) && !empty($searchresult1)){
				
				$sql="update  fld_cash_purchase set status='3'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql);
				$succee_msg = "Cash Purchase Disapprove succesfully";
				 $case="list";
				/*
				$menu = inventory_get_post_escape('menu');
				$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$sql="update  fld_cash_purchase 
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 `no_of_student`='".$nostu."',
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `menu_name`	 ='".$menu."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' 
											  'status'='3'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_cashpurchase_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					if(isset($searchresultitem) && !empty($searchresultitem)){
							$itemqryupdate="update  `tbl_cashpurchase_item` 
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						$itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				*/
					
				
			}
			/*else{
				$sql="insert into fld_cash_purchase (`fld_order_id`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`) values('".$indentid."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','2')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						$itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			*/
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		    /* if(inventory_affected_rows()>0){
				$succee_msg = "Indent Disaprroved succesfully done";
				 header(inventory_display(ROOT_PATH).'/indent');
				//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}*/
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			
			
			
			
			
		}
			
		//$succee_msg = "Indent Final submit Made succesfully done";
	 // header('Location:'.inventory_display(ROOT_PATH).'/indent');
		
	}
if($case == "add"){
	if($cashp_w==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
	
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
	
	//echo 1; exit;
	       //$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
				
			//check if indent already created or not
		if(isset($_POST['add_indent'])){ 
			$indentid=inventory_get_post_escape('indent');
			$serachindentno="select * from fld_cash_purchase where fld_order_id='".$indentid."' and status='0'  ";
			$searchresult1 = inventory_query($serachindentno);
			$srech=inventory_fetch_assoc($searchresult1);
			if(isset($srech) && !empty($srech)){
				//$menu = inventory_get_post_escape('menu');
				//$nostu=inventory_get_post_escape('nostu');
				$class=inventory_get_post_escape('class');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				 $sql="update  fld_cash_purchase set
											 `cretaed_by`	='".$crtd."',
											 `dep_id`		='".$class."',
											 
											 `indent_create_on`='".$prepareon."',
											 `material_req_on`='".$reqon."',
											 `semester`='".$semester."',
											 `section`='".$section."',
											 `fld_gross_total`='".$total."',
											 `fld_cgst`= '".$tax."',
											 `fld_total_amount`='".$total_amount."' ,
											 `status`='1'
											 where
											 	`fld_order_id`	='".$indentid."'
											 ";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					//search order item exist or not
					
					
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$sqlsearcorderitem="select * from tbl_cashpurchase_item where order_id='".$indentid."' and fld_item_id='".$itemnam."'";
					$searchresultitem = inventory_query($sqlsearcorderitem);
					$srchrst=inventory_fetch_assoc($searchresultitem);
					if(isset($srchrst) && !empty($srchrst)){
							 $itemqryupdate="update  `tbl_cashpurchase_item` set
																`fld_itm_cat`='".$catid."',
																`fld_item_subcat`='".$subcatid."',
																
																`fld_quantity`='".$qty."',
																`fld_amount`='".$price."', 
																`item_gross`='".$gross."',
																`item_tax`='".$tax."',
																`item_tax_amount`='".$taxval."',
																`item_total`='".$totar."'
																 where 
																 	`order_id`='".$indentid."' and
																 	`fld_item_id`='".$itemnam."'
																	  
																	  
																	  ";
					        $select_user_details_query_result = inventory_query($itemqryupdate); 	
							
						
						
					}else{
						
						 $itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
					    $select_user_details_query_result = inventory_query($itemqry); 
					}
					
					
				}
				
			}
				
				
				
				
				
				
					
				
			}else{
					
				
				
				$class=inventory_get_post_escape('class');
				$prepareon=inventory_get_post_escape('prepareon');
				$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
				$reqon=inventory_get_post_escape('reqon');
				$totalrow=inventory_get_post_escape('totalrow');
				$total=inventory_get_post_escape('total');
				$total_amount=inventory_get_post_escape('total_amount');
				$tax=inventory_get_post_escape('total_tax');
				$semester=inventory_get_post_escape('semester');
				$section=inventory_get_post_escape('section');
					
				
				
				 $sql="insert into fld_cash_purchase (`fld_order_id`,`cretaed_by`,`dep_id`,`indent_create_on`,`material_req_on`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`,`semester`,`section`) values('".$indentid."','".$crtd."','".$class."','".$prepareon."','".$reqon."','".$total."','".$tax."','".$total_amount."','1','".$semester."','".$section."')";
				$select_user_details_query_result = inventory_query($sql); 
				for($ik=1;$ik<=$totalrow;$ik++){
					$itemnam=$_POST["item_$ik"];
					$catid=$_POST["category_$ik"];
					$subcatid=$_POST["subcategory_$ik"];
					$qty=$_POST["qty_$ik"];
					$price=$_POST["price_$ik"];
					$gross=$_POST["gross_$ik"];
					$tax=$_POST["tax_$ik"];
					$totar=$_POST["totar_$ik"];
					$taxval=(floatval($gross)*floatval($tax))*2/100;
					
					if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
						 $itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."')";
						$select_user_details_query_result = inventory_query($itemqry); 
					}
					
				}
				
				
				
			}
										
			
			
			
			
			
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     if(inventory_affected_rows()>0){
				$succee_msg = "Cash Purchase submit succesfully";
				 $case="list";
				//$succee_msg = "Indent Final submit Made succesfully done";
		       //header('Location:'.inventory_display(ROOT_PATH).'/indent');
			//$case = "list";
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			
			
			
			
			
		}
	
   if(isset($_POST['draft_indent'])){
			//$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
			//$menu = inventory_get_post_escape('menu');
			$indentid=inventory_get_post_escape('indent');
			//$nostu=inventory_get_post_escape('nostu');
			$class=inventory_get_post_escape('class');
			$semester=inventory_get_post_escape('semester');
			$section=inventory_get_post_escape('section');
			$prepareon=inventory_get_post_escape('prepareon');
			$crtd=inventory_get_session(VARIABLE_PREFIX."user_id");
			$reqon=inventory_get_post_escape('reqon');
			$totalrow=inventory_get_post_escape('totalrow');
			$total=inventory_get_post_escape('total');
			$total_amount=inventory_get_post_escape('total_amount');
			$tax=inventory_get_post_escape('total_tax');
			$sql="insert into fld_cash_purchase (`fld_order_id`,`cretaed_by`,`dep_id`,`no_of_student`,`indent_create_on`,`material_req_on`,`menu_name`,`fld_gross_total`,`fld_cgst`,`fld_total_amount`,`status`) values('".$indentid."','".$crtd."','".$class."','".$nostu."','".$prepareon."','".$reqon."','".$menu."','".$total."','".$tax."','".$total_amount."','1')";
			$select_user_details_query_result = inventory_query($sql); 
			for($ik=1;$ik<=$totalrow;$ik++){
				$itemnam=$_POST["item_$ik"];
				$catid=$_POST["category_$ik"];
				$subcatid=$_POST["subcategory_$ik"];
				$qty=$_POST["qty_$ik"];
				$price=$_POST["price_$ik"];
				$gross=$_POST["gross_$ik"];
				$tax=$_POST["tax_$ik"];
				$totar=$_POST["totar_$ik"];
				$taxval=(floatval($gross)*floatval($tax))*2/100;
				
				if(isset($qty)&& !empty($qty) && isset($itemnam) && !empty($itemnam) && isset($totar) && !empty($totar)){
					$itemqry="INSERT INTO `tbl_cashpurchase_item` ( `order_id`,`fld_itm_cat`,`fld_item_subcat`,`fld_item_id`, `fld_quantity`, `fld_amount`, `item_gross`, `item_tax`, `item_tax_amount`, `item_total`,`semester`,`section`) VALUES ('".$indentid."','".$catid."','".$subcatid."', '".$itemnam."', '".$qty."', '".$price."', '".$gross."', '".$tax."', '".$taxval."', '".$totar."','".$semester."','".$section."')";
					$select_user_details_query_result = inventory_query($itemqry); 
				}
				
			}
			
			//$insert_into_category_result = inventory_query($insert_into_category); 
		     if(inventory_affected_rows()>0){
				//$succee_msg = "Indent Successfully Added to draft";
				//header(inventory_display(ROOT_PATH).'/indent');
				$succee_msg = "Cash Purchase submit Made succesfully done";
				$case="list";
		      //  header('Location:'.inventory_display(ROOT_PATH).'/indent');
			
			}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
			}
			//echo $sql;
			//echo $sql;
			//$select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."' or fld_email='".trim($email)."' or fld_mobile_number='".trim($mobile_number)."'  ";
			
			
			
			
			
		
	}
	}
	if($case == "list"){
		if($cashp_r==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="hod"){
		 $getuserdepidqry="select * from tbl_hod where fld_hod_id='".inventory_get_session(VARIABLE_PREFIX."venid")."'";
		$getuserdepidqry_result = inventory_query($getuserdepidqry); 
        $row_getuserdepidqry = inventory_fetch_assoc($getuserdepidqry_result);
	    $depidhod=explode(",",$row_getuserdepidqry['dep_id']);
		}
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="hod"){
			
			
         $select_user_details_query = "SELECT  * from `fld_cash_purchase`  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 if(in_array($row_data['dep_id'], $depidhod)){
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['fld_order_id'].'</td>
								
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}
								if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}
								
					}			
			}
		}	
		
			
			
			   		
			   	
	    }
		if(inventory_get_session(VARIABLE_PREFIX."user_type")=="user"){
        $select_user_details_query = "SELECT  * from `fld_cash_purchase` where cretaed_by='".inventory_get_session(VARIABLE_PREFIX."user_id")."'  order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['fld_order_id'].'</td>
								
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}
								if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/vieviewcashpurchasewindent/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}
								
							
			}
		}	
			   	
	    }
	    if(inventory_get_session(VARIABLE_PREFIX."user_type")=="admin"){
			   		
			  
        $select_user_details_query = "SELECT  * from `fld_cash_purchase`   order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				 
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['fld_order_id'].'</td>
								
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>';
								if($user_type=="user"){
											
										if($row_data['status']==0){
											$list .=	'<td><center><a  readonly class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==1){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-info btn-xs" href="'.ROOT_PATH.'/printcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3){
											$list .=	'<td><center>
										&nbsp;<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
											</tr>';
										}
									
									
								}else if($user_type=="hod"){
									 if($row_data['status']==0){
											$list .=	'<td></td></tr>';
										}
										if($row_data['status']==2){
											$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>
										&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center></td>
											</tr>';
										}
										if($row_data['status']==3 || $row_data['status']==1 ){
											$list .=	'<td><center><a class="btn btn-success btn-xs" href="'.ROOT_PATH.'/editcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Edit</a>
										&nbsp;<a class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a></center></td>
									</tr>';
										}
									
											
								}else{
									$list .=	'<td><center>
											<a readonly class="btn btn-info btn-xs" href="'.ROOT_PATH.'/viewcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>View</a>';
										if($row_data['status']==2){	
										$list .='&nbsp;<a readonly target="_blank" class="btn btn-success btn-xs" href="'.ROOT_PATH.'/printcashpurchase/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'>Print</a></center>';
								      }
									$list .=	'	</td>
											</tr>';
											
								}
								
							
			}
		}	
			   	
	    }
			  
		
		
		
	}



	if($case == "view"){
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT  * from  fld_cash_purchase WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$fld_order_id = $row_data['fld_order_id'];
			//$no_of_student = $row_data['no_of_student'];
			$indent_create_on = $row_data['indent_create_on'];
			$material_req_on = $row_data['material_req_on'];
			$depid=$row_data['dep_id'];
			$for_class = $row_data['for_class'];
			//$menu_name = $row_data['menu_name'];
			$fld_total_amount=$row_data['fld_total_amount'];
			$fld_gross_total=$row_data['fld_gross_total'];
			$fld_cgst = $row_data['fld_cgst'];
			
			
		              	
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
?>
