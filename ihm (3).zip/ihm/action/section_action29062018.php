<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		
		//get all category related data
		
		$sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		 $section_r=$rst_rw['section_r'];
		 $section_w=$rst_rw['section_w'];
		 $section_d=$rst_rw['section_d'];
		
		if($section_r==0 && $section_r==0 && $section_d==0 ){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		
		
		/*if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}*/
	}else{
		//echo 2;
		include("nopermission.php");
		exit();
	}
	if($case == "edit"){
		if($section_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$category_name = "";
		$is_active  = "";
		$category_id = track64_decode(inventory_get_get('category_id'));
		
		$select_category_query = "SELECT * FROM `tbl_section` WHERE `fld_ai_id` = '".$category_id."';";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			$row_data = inventory_fetch_assoc($select_category_query_result);
			$category_name = $row_data['fld_category'];
			$semester= $row_data['semester'];
			$is_active  = $row_data['fld_isactive'];
			
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		$log_text = "";
		$update_text = "";
		$succee_msg = "";
		$error_msg = "";
		if(inventory_post_isset('edit_category')){	
			$category_name = inventory_get_post_escape('category_name');
			$semestername=implode(",",$_POST['semestername']);
			if(inventory_post_isset('is_active')){
				$is_active = 1;
			}else{
				$is_active = 0;
			}
			$category_id = track64_decode(inventory_get_post_escape('category_id'));
			$select_category_query = "SELECT `fld_category`,`fld_isactive` FROM `tbl_section` WHERE `fld_ai_id` = '".$category_id."';";
			$select_category_query_result = inventory_query($select_category_query); 
			if(inventory_num_rows($select_category_query_result)>0){
				$row_data = inventory_fetch_assoc($select_category_query_result);
				$category_name_db = $row_data['fld_category'];
				$is_active_db  = $row_data['fld_isactive'];
				if(inventory_validation($category_name,true,40,2,false,true,false,false,"Name") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($category_name,true,40,2,false,true,false,false,"Name");
				}
				if($error_msg == ""){
					$check_duplicate_category_query = "SELECT `fld_ai_id` FROM `tbl_section` WHERE LOWER(`fld_category`) = LOWER('".$category_name."') AND `fld_ai_id` != '".$category_id."';";
					$check_duplicate_category_query_result = inventory_query($check_duplicate_category_query); 
					if(!inventory_num_rows($check_duplicate_category_query_result)){
						if($category_name != $category_name_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_category =>".$category_name_db;	
							$update_text .= "fld_category = '".$category_name."' ";
						}
						if($is_active != $is_active_db){
							if($log_text != ""){
								$log_text .= ",";	
								$update_text .= ",";	
							}
							$log_text .= "fld_isactive =>".$is_active_db;	
							$update_text .= "fld_isactive = '".$is_active."' ";
						}
						//if($update_text != ""){
							inventory_commit_off();
							$update_department_query = "UPDATE `tbl_section` SET `semester`='".$semestername."' ".$update_text." WHERE `fld_ai_id` = '".$category_id."';";
							$update_department_query_result = inventory_query($update_department_query);
							if(inventory_affected_rows() >0){
								$insert_into_log_query = "INSERT INTO `tbi_edit_log`(`fld_id`,`fld_type`,`fld_log_text`,`fld_edited_by`) VALUES ('".$category_id."','category','".$log_text."','".$user_id."');";
								$insert_into_log_query_result = inventory_query($insert_into_log_query);
								if(inventory_affected_rows() >0){
									inventory_commit();
									$succee_msg = "Section Successfully Updated";
									$case = "list";
								}else{
									$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
									inventory_rollback();
									$case = "edit";
								}
							}else{
								$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
								inventory_rollback();
								$case = "edit";
							}
							inventory_commit_on();
						//}else{
						//	$succee_msg = "Nothing To Update";
						//	$case = "list";	
						//}
					}else{
						$error_msg = "Duplicate Section Name Found";
						$case = "edit";	
					}
				}else{
					$case = "edit";	
				}
			}else{
				include("nopermission.php");
				exit();
			}
			
		}
	}
	if($case == "add"){
		if($section_w==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$category_name = "";
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('add_category')){	
			$category_name = inventory_get_post_escape('category_name');
			$semestername=implode(",",$_POST['semestername']);
			if(inventory_validation($category_name,true,40,2,false,true,false,false,"Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($category_name,true,40,2,false,true,false,false,"Name");
			}
			if($error_msg == ""){
				$check_duplicate_category_query = "SELECT `fld_ai_id` FROM `tbl_section` WHERE LOWER(`fld_category`) = LOWER('".$category_name."');";
				$check_duplicate_category_query_result = inventory_query($check_duplicate_category_query); 
				if(!inventory_num_rows($check_duplicate_category_query_result)){
					$insert_into_category = "INSERT INTO `tbl_section`(`fld_category`,`fld_isactive`,`semester`) VALUES ('".$category_name."','1','".$semestername."');";
					$insert_into_category_result = inventory_query($insert_into_category); 
					if(inventory_affected_rows()>0){
						$succee_msg = "Section Successfully Added";
						$case = "list";
					}else{
						$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
					}
				}else{
					$error_msg = "Duplicate Section Name Found";	
				}
			}
		}
	}
	if($case == "list"){
		if($section_r==0){
			//echo 1;
			include("nopermission.php");
			exit();
			
		}
		$category_array = array();
		$list = "";	
		$category_or_clause = "";
		
		$select_category_query = "SELECT `fld_ai_id`,`fld_category`,`fld_isactive` FROM `tbl_section` ORDER BY `fld_isactive`DESC,`fld_category` ASC;";
		$select_category_query_result = inventory_query($select_category_query); 
		if(inventory_num_rows($select_category_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_category_query_result)){
				$row_data['sub_category'] = 0;
				$category_array[$row_data['fld_ai_id']] = $row_data;
				
				if($category_or_clause != ""){
					$category_or_clause .= ' OR ';	
				}
				$category_or_clause .= "`fld_category_id` = '".$row_data['fld_ai_id']."'";
			}
			/*$sub_category_count_query = "SELECT COUNT(`fld_ai_id`) AS `count`,`fld_category_id` FROM `tbl_section` WHERE ".$category_or_clause." GROUP BY `fld_category_id`;";
			$sub_category_count_query_result = inventory_query($sub_category_count_query); 
			if(inventory_num_rows($sub_category_count_query_result)>0){
				while($row_data = inventory_fetch_assoc($sub_category_count_query_result)){
					$category_array[$row_data['fld_category_id']]['sub_category'] = $row_data['count'];
				}
			}*/
			foreach($category_array as $key=>$value){
				$active_class = '';
				$icon_class = "";
				if($value['fld_isactive'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				$list .= 	'<tr '.$active_class.'>
								<td>'.$value['fld_category'].'</td>';
				if($section_w==0){
					//include("nopermission.php");
					//exit();
					$list .= '<td></td>
							</tr>';
					
				}else{
					$list .= '<td><center><a href="'.ROOT_PATH.'/editsection/'.track64_encode($key).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></center></td>
							</tr>';
				}				
								
							
			}
		}
	}
?>