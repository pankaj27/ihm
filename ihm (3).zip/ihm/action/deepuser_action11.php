<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
	}else{
		include("nopermission.php");
		exit();
	}
	if($case == "delete"){
		$user_id = track64_decode(inventory_get_get('user_id'));
		
		 $select_department_query = "SELECT * FROM `tbl_user`  WHERE `fld_ai_id` = '".$user_id."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$sql="delete from `tbl_user`  WHERE `fld_ai_id` = '".$user_id."'";
			$qry = inventory_query($sql);
			$succee_msg = "User Successfully Deleted";
			$case = "list";
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "edit"){
		$user_ai_id = track64_decode(inventory_get_get('user_id'));
		$select_user_details_query = "SELECT * FROM `tbl_user` WHERE `fld_ai_id` = '".$user_ai_id."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$name = $row_data['fld_name'];
			$mobile_number = $row_data['fld_mobile_number'];
		//	$email = $row_data['fld_email'];
		//	$city = $row_data['fld_city'];
		//	$address = $row_data['fld_address'];
		//	$pin = $row_data['fld_pin'];
			$username=$row_data['fld_username'];
			$deepid=$row_data['deepuser_id'];
			$paewd=$row_data['fld_password'];
			$user_type = $row_data['fld_user_type'];
			$userdep=$row_data['deepuser_id'];
			$is_active = $row_data['fld_is_active'];
		}else{
			include("nopermission.php");
			exit();
		}
	}
	if($case == "update"){
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('edit_user')){
			$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
			//$city = inventory_get_post_escape('city');
			//$address = inventory_get_post_escape('address');
			//$pin = inventory_get_post_escape('pin');
			$password = inventory_get_post_escape('password');
			$username=inventory_get_post_escape('username');
			$name=inventory_get_post_escape('name');
			 $mobile_number=inventory_get_post_escape('mobile_number');
		    $utype=inventory_get_post_escape('user_type');
		     $user_dep=inventory_get_post_escape('user_dep');
			 
			 //acount permission
			 
			 $category_r=$_POST['category_r'];if(isset($category_r) && !empty($category_r)){ $category_r=$_POST['category_r']; }else{ $category_r=0; }
			 $category_w=$_POST['category_w'];if(isset($category_w) && !empty($category_w)){ $category_w=$_POST['category_w']; }else{ $category_w=0; }
			 $category_d=$_POST['category_d'];if(isset($category_d) && !empty($category_d)){ $category_d=$_POST['category_d']; }else{ $category_d=0; }
			 
			 
			 $subcat_r=$_POST['subcat_r'];if(isset($subcat_r) && !empty($subcat_r)){ $subcat_r=$_POST['subcat_r']; }else{ $subcat_r=0; }
			 $subcat_w=$_POST['subcat_w'];if(isset($subcat_w) && !empty($subcat_w)){ $subcat_w=$_POST['subcat_w']; }else{ $subcat_w=0; }
			 $subcat_d=$_POST['subcat_d'];if(isset($subcat_d) && !empty($subcat_d)){ $subcat_d=$_POST['subcat_d']; }else{ $subcat_d=0; }
			 
			 
			 $deep_r=$_POST['deep_r'];if(isset($deep_r) && !empty($deep_r)){ $deep_r=$_POST['deep_r']; }else{ $deep_r=0; }
			 $deep_w=$_POST['deep_w'];if(isset($deep_w) && !empty($deep_w)){ $deep_w=$_POST['deep_w']; }else{ $deep_w=0; }
			 $deep_d=$_POST['deep_d'];if(isset($deep_d) && !empty($deep_d)){ $deep_d=$_POST['deep_d']; }else{ $deep_d=0; }
			 
			 $tax_r=$_POST['tax_r'];if(isset($tax_r) && !empty($tax_r)){ $tax_r=$_POST['tax_r']; }else{ $tax_r=0; }
			 $tax_w=$_POST['tax_w'];if(isset($tax_w) && !empty($tax_w)){ $tax_w=$_POST['tax_d']; }else{ $tax_w=0; }
			 $tax_d=$_POST['tax_d'];if(isset($tax_d) && !empty($tax_d)){ $tax_d=$_POST['tax_d']; }else{ $tax_d=0; }
			 
			 
			 $item_r=$_POST['item_r'];if(isset($item_r) && !empty($item_r)){ $item_r=$_POST['item_r']; }else{ $item_r=0; }
			 $item_w=$_POST['item_w'];if(isset($item_w) && !empty($item_w)){ $item_w=$_POST['item_w']; }else{ $item_w=0; }
			 $item_d=$_POST['item_d'];if(isset($item_d) && !empty($item_d)){ $item_d=$_POST['item_d']; }else{ $item_d=0; }
			
			 $indent_r=$_POST['indent_r'];if(isset($indent_r) && !empty($indent_r)){ $indent_r=$_POST['indent_r']; }else{ $indent_r=0; }
			 $indent_w=$_POST['indent_w'];if(isset($indent_w) && !empty($indent_w)){ $indent_w=$_POST['indent_w']; }else{ $indent_w=0; }
			 $indent_d=$_POST['indent_d'];if(isset($indent_d) && !empty($indent_d)){ $indent_d=$_POST['indent_d']; }else{ $indent_d=0; }
			 
			 $po_r=$_POST['po_r'];if(isset($po_r) && !empty($po_r)){ $po_r=$_POST['po_r']; }else{ $po_r=0; }
			 $po_w=$_POST['po_w'];if(isset($po_w) && !empty($po_w)){ $po_w=$_POST['po_w']; }else{ $po_w=0; }
			 $po_d=$_POST['po_d'];if(isset($po_d) && !empty($po_d)){ $po_d=$_POST['po_d']; }else{ $po_d=0; }
			 
			 $cashp_r=$_POST['cashp_r'];if(isset($cashp_r) && !empty($cashp_r)){ $cashp_r=$_POST['cashp_r']; }else{ $cashp_r=0; }
			 $cashp_w=$_POST['cashp_w'];if(isset($cashp_w) && !empty($cashp_w)){ $cashp_w=$_POST['cashp_w']; }else{ $cashp_w=0; }
			 $cashp_d=$_POST['cashp_d'];if(isset($cashp_d) && !empty($cashp_d)){ $cashp_d=$_POST['cashp_d']; }else{ $cashp_d=0; }
			 
			 
			  $por_r=$_POST['por_r'];if(isset($por_r) && !empty($por_r)){ $por_r=$_POST['por_r']; }else{ $por_r=0; }
			  $por_w=$_POST['por_w'];if(isset($por_w) && !empty($por_w)){ $por_w=$_POST['por_w']; }else{ $por_w=0; }
			  $por_d=$_POST['por_d'];if(isset($por_d) && !empty($por_d)){ $por_d=$_POST['por_d']; }else{ $por_d=0; }
			 
			 
			  $indent_r=$_POST['indent_r'];if(isset($indent_r) && !empty($indent_r)){ $indent_r=$_POST['indent_r']; }else{ $indent_r=0; }
			  $indent_w=$_POST['indent_w'];if(isset($indent_w) && !empty($indent_w)){ $indent_w=$_POST['indent_w']; }else{ $indent_w=0; }
			  $indent_d=$_POST['indent_d'];if(isset($indent_d) && !empty($indent_d)){ $indent_d=$_POST['indent_d']; }else{ $indent_d=0; }
			 
			 $vendorr_r=$_POST['vendorr_r'];if(isset($vendorr_r) && !empty($vendorr_r)){ $vendorr_r=$_POST['vendorr_r']; }else{ $vendorr_r=0; }
			 $vendorr_w=$_POST['vendorr_w'];if(isset($indent_w) && !empty($indent_w)){ $indent_w=$_POST['vendorr_w']; }else{ $indent_w=0; }
			 $indent_d=$_POST['vendorr_d'];if(isset($indent_d) && !empty($indent_d)){ $indent_d=$_POST['vendorr_d']; }else{ $indent_d=0; }
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
		//	 $email=inventory_get_post_escape('email');
			//exit;
			if(inventory_post_isset('is_active')){
				$is_active = 1;	
			}else{
				$is_active = 0;	
			}
			$select_user_details_query = "SELECT * FROM `tbl_user` where fld_ai_id='".$user_ai_id."'  ";
			$select_user_details_query_result = inventory_query($select_user_details_query); 
			if(!empty(inventory_num_rows($select_user_details_query_result)) ){
				
				
				//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
				
			
				/*if(inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code");
				}
				*/
				if($error_msg == ""){
					
					
						 $inset_into_department_query="update tbl_user set 
						 									fld_name='".$name."',
						 									fld_username='".$username."',
						 									fld_mobile_number='".$mobile_number."',
						 									fld_password='".$password."',
						 								    fld_user_type='".$utype."',
						 									fld_is_active='".$is_active."',
						 									deepuser_id='".$user_dep."'
						 								where 
						 									fld_ai_id='".$user_ai_id."'
						 								";
						                                      	//echo $qry2;
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if(inventory_affected_rows()>0){
							$succee_msg = "User Successfully Updated";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					
					
				}
				
				
				
			}else{
				$error_msg = "Duplicate Username or Email or Mobile No Found";	
				//exit();
			}
		}
	}
if($case == "add"){
	       //$user_ai_id = "";
			$name="";
		//	$email="";
		//	$city = "";
		//	$address = "";
		//	$pin ="";
			$password = "";
			$mobile_number="";
			$username="";
		//	$password="";
			$user_dep="";
			$is_active=1;
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('add_user')){
			//$user_ai_id = track64_decode(inventory_get_post_escape('user_ai_id'));
		//	$city = inventory_get_post_escape('city');
		//	$address = inventory_get_post_escape('address');
		//	$pin = inventory_get_post_escape('pin');
			$password = inventory_get_post_escape('password');
			$username=inventory_get_post_escape('username');
			$name=inventory_get_post_escape('name');
			$mobile_number=inventory_get_post_escape('mobile_number');
			$utype=inventory_get_post_escape('user_type');
			$user_dep=inventory_get_post_escape('user_dep');
		//	$email=inventory_get_post_escape('email');
			if(inventory_post_isset('is_active')){
				$is_active = 1;	
			}else{
				$is_active = 0;	
			}
			 $select_user_details_query = "SELECT * FROM `tbl_user` where fld_username='".trim($username)."'  or fld_mobile_number='".trim($mobile_number)."'  ";
			$select_user_details_query_result = inventory_query($select_user_details_query); 
			if(empty(inventory_num_rows($select_user_details_query_result)) ){
				
				
				//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
				
				/*if(inventory_validation($city,true,40,4,false,false,false,false,"City") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($city,true,40,4,false,false,false,false,"City");
				}*/
				/*if(inventory_validation($address,true,40,4,false,false,false,false,"Address") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($address,true,40,4,false,false,false,false,"Address");
				}*/
				/*if(inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code") != ""){
					if($error_msg != ""){
						$error_msg .= "<br>";	
					}
					$error_msg .= inventory_validation($pin,true,6,6,true,true,false,trur,"Pin Code");
				}
				*/
				if($error_msg == ""){
					
					/*$inset_into_department_query = "INSERT INTO `tbl_vendor`
					                                            (`fld_name`,
					                                             `fld_username`,
					                                             `fld_mobile_number`,
					                                             `fld_email`,
					                                             `fld_password`,
					                                             `fld_city`,`
					                                             fld_address`,
					                                             `fld_pin`,
					                                             `fld_is_active`
					                                             
					                                             )
						                                      VALUES(
						                                      	'".$name."',
						                                      	'".$username."',
						                                      	'".$mobile_number."',
						                                      	'".$email."',
						                                      	'".$password."',
						                                      	'".$city."',
						                                      	'".$address."',
						                                      	'".$pin."',
						                                      	'".$is_active."'
						                                      	)";
						                       */               	
						                             $inset_into_department_query="INSERT INTO `tbl_user` (`fld_name`, `fld_username`, `fld_mobile_number`,  `fld_password`,  `fld_user_type`, `fld_is_active`,`deepuser_id`)
													  VALUES ( '".$name."',
						                                      	'".$username."',
						                                      	'".$mobile_number."',
						                                      	'".$password."',
						                                      	'".$utype."',
						                                      	'".$is_active."',
						                                      	'".$user_dep."'
						                                      	
						                                      	);";
						                                      	//echo $qry2;
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if(inventory_affected_rows()>0){
							$succee_msg = "User Successfully Added";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					
					
				}
				
				
				
			}else{
				$error_msg = "Duplicate Username  or Mobile No Found";	
				//exit();
			}
		}
	}
	if($case == "list"){
		$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		$select_user_details_query = "SELECT * FROM `tbl_user` WHERE `fld_user_type` = 'user' ORDER BY `fld_is_active` DESC ,`fld_name` ASC";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
			    
			    $select_department_query2 = "SELECT * FROM tbl_department WHERE fld_is_active ='1' and fld_ai_id='".$row_data['deepuser_id']."'";
			   $select_department_query_result2 = inventory_query($select_department_query2); 
			   $res=inventory_fetch_assoc($select_department_query_result2);
			     // array_push($depar,$res['fld_department']);
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_name'].'</td>
								<td>'.$row_data['fld_mobile_number'].'</td>
								<td>'.usertype($row_data['fld_user_type']).'</td>
								<td>'.$res['fld_department'].'</td>
								<td>'.$status_array[$row_data['fld_is_active']].'</td>
								<td><center><a href="'.ROOT_PATH.'/editduser/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
								&nbsp;<a href="'.ROOT_PATH.'/deleteduser/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-trash-o" aria-hidden="true"></i></a></center></td>
							</tr>';
			}
		}
	}
?>