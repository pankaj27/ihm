<?php
	if(inventory_session_isset(VARIABLE_PREFIX."user_id")){
		$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
		 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
		if($user_type != 'admin'){
			include("nopermission.php");
			exit();
		}
		 
		 
		
		 
		 
	}else{
		//echo 2;
		include("nopermission.php");
		exit();
	}
	
	if($case == "delete"){
		$ven_id = track64_decode(inventory_get_get('ven_id'));
		
		 $select_department_query = "SELECT * FROM `tbl_vendor`  WHERE `fld_ai_id` = '".$ven_id."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$sql="delete from `tbl_vendor`  WHERE `fld_ai_id` = '".$ven_id."'";
			$qry = inventory_query($sql);
			$succee_msg = "Vendor Successfully Deleted";
			$case = "list";
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	
	if($case == "edit"){
		$ven_id = track64_decode(inventory_get_get('ven_id'));
		
		 $select_department_query = "SELECT * FROM `tbl_vendor`  WHERE `fld_ai_id` = '".$ven_id."';";
		$select_department_query_result = inventory_query($select_department_query);
		//print_r($select_department_query_result); exit;
		if(inventory_num_rows($select_department_query_result)>0){
			$row_data = inventory_fetch_assoc($select_department_query_result);
			//$hodid = $row_data['fld_department_id'];
			//$dept_name = $row_data['fld_department'];
			$vdd=$row_data['fld_ai_id'];
			  $ven_id =$row_data['fld_vn_id'];
				$ven_name = $row_data['fld_name'];
				$ven_address =$row_data['fld_add'] ;
				//$ven_pin = $row_data['fld_pin'] ;
				$products =$row_data['fld_product'];
				$ven_phone=$row_data['fld_phn'];
				$ven_person=$row_data['contact_person'];
				$ven_gst=$row_data['gstno'];
			
		}else{
			include("nopermission.php");
			exit();
		}
		
	}
	if($case == "update"){
		$ven_id = "";
		$ven_name = "";
		$ven_address = "";
		$ven_pin = "";
		$products = "";
		$ven_phone="";
		/*$hod_name = "";
		$hod_user="";
		$hod_pass="";*/
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(inventory_post_isset('update_ven')){	
			    $ven_id =inventory_get_post_escape('ven_id');
				$ven_name = inventory_get_post_escape('ven_name');
				$ven_address = inventory_get_post_escape('ven_address');
			//	$ven_pin = inventory_get_post_escape('ven_pin');
				$products = implode(",",$_POST['products']);
				$ven_phone=inventory_get_post_escape('ven_phone');
				$vdd=inventory_get_post_escape('venidd');
				$ven_person=inventory_get_post_escape('ven_person');
				$ven_gst=inventory_get_post_escape('ven_gst');
			 
			 
			//exit;
			//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
			
			
			if(inventory_validation($ven_name,true,40,2,false,true,false,false,"Vendor Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($ven_name,true,40,2,false,true,false,false,"Vendor Name");
			}
		
			
			if(inventory_validation($ven_phone,true,11,10,false,true,false,false,"Phone ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($ven_phone,true,40,2,false,true,false,false,"Phone");
			}
			
			if($error_msg == ""){
				$ckeck_duplicate_department_id = "SELECT `fld_vn_id` FROM `tbl_vendor` WHERE LOWER(`fld_vn_id`) = LOWER('".$ven_id."');";
				$ckeck_duplicate_department_id_result = inventory_query($ckeck_duplicate_department_id); 
				if(inventory_num_rows($ckeck_duplicate_department_id_result)){
					/*$ckeck_duplicate_department_name = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department`) = LOWER('".$dept_name."');";
					$ckeck_duplicate_department_name_result = inventory_query($ckeck_duplicate_department_name); 
					if(!inventory_num_rows($ckeck_duplicate_department_name_result)){*/
						$inset_into_department_query = "update `tbl_vendor` set
																	fld_name='".$ven_name."',
																	fld_add='".$ven_address."',
																	fld_phn='".$ven_phone."',
																	fld_product='".$products."',
																	contact_person='".$ven_person."',
																	gstno='".$ven_gst."'
																	
																where
																	fld_ai_id='".$vdd."'
																
																
						                                          ";
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if(inventory_affected_rows()>0){
							$succee_msg = "Vendor Successfully Updated";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					/*}else{
						$error_msg = "Duplicate Department Name Found";	
					}*/
				}else{
					$error_msg = "Duplicate Vendor Id Found";	
				}
			}
		
		}
	}
	if($case == "add"){
		//echo 1;exit;
		$ven_id = "";
		$ven_name = "";
		$ven_address = "";
		$ven_pin = "";
		$products = "";
		$ven_phone="";
		$ven_person="";
		$ven_gst="";
		/*$hod_name = "";
		$hod_user="";
		$hod_pass="";*/
		$succee_msg = "";
		$error_msg = "";
		$update_text = "";
		$log_text = "";
		if(isset($_POST['add_ven'])){	
			    $ven_id =inventory_get_post_escape('ven_id');
				$ven_name = inventory_get_post_escape('ven_name');
				$ven_address = inventory_get_post_escape('ven_address');
				//$ven_pin = inventory_get_post_escape('ven_pin');
				//$products = implode(",",$_POST['products']);
				$ven_phone=inventory_get_post_escape('ven_phone');
				$ven_person=inventory_get_post_escape('ven_person');
				$ven_gst=inventory_get_post_escape('ven_gst');
			 
			//exit;
			//service_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name)
			if(inventory_validation($ven_id,true,40,2,true,true,false,false,"Vendor Id") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($ven_id,true,40,2,true,true,false,false,"Vendor Id");
			}
			
			if(inventory_validation($ven_name,true,40,2,false,true,false,false,"Vendor Name") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($ven_name,true,40,2,false,true,false,false,"Vendor Name");
			}
			
			
			if(inventory_validation($ven_phone,true,11,10,false,true,false,false,"Phone ") != ""){
				if($error_msg != ""){
					$error_msg .= "<br>";	
				}
				$error_msg .= inventory_validation($ven_phone,true,40,2,false,true,false,false,"Phone");
			}
			
			if($error_msg == ""){
				$ckeck_duplicate_department_id = "SELECT `fld_vn_id` FROM `tbl_vendor` WHERE LOWER(`fld_vn_id`) = LOWER('".$ven_id."');";
				$ckeck_duplicate_department_id_result = inventory_query($ckeck_duplicate_department_id); 
				if(!inventory_num_rows($ckeck_duplicate_department_id_result)){
					/*$ckeck_duplicate_department_name = "SELECT `fld_ai_id` FROM `tbl_department` WHERE LOWER(`fld_department`) = LOWER('".$dept_name."');";
					$ckeck_duplicate_department_name_result = inventory_query($ckeck_duplicate_department_name); 
					if(!inventory_num_rows($ckeck_duplicate_department_name_result)){*/
						 $inset_into_department_query = "INSERT INTO `tbl_vendor`
						                                          (`fld_vn_id`,`contact_person`,`gstno`,`fld_name`,`fld_add`,`fld_pin`,`fld_phn`,`fld_is_active`)
						                                VALUES('".$ven_id."','".$ven_person."','".$ven_gst."','".$ven_name."','".$ven_address."','".$ven_pin."','".$ven_phone."','1')";
						$inset_into_department_query_result = inventory_query($inset_into_department_query); 
						if(inventory_affected_rows()>0){
							$succee_msg = "Vendor Successfully Added";
							$case = "list";
						}else{
							$error_msg = "Database Connectivity Error. Please Contact Admin For Support";
						}
					/*}else{
						$error_msg = "Duplicate Department Name Found";	
					}*/
				}else{
					$error_msg = "Duplicate Vendor Id Found";	
				}
			}
		}
	}
	if($case == "list"){
		// echo 1;
		$list = "";
		 $select_department_query = "SELECT * FROM `tbl_vendor`";
		$select_department_query_result = inventory_query($select_department_query); 
		if(inventory_num_rows($select_department_query_result)>0){
			while($row_data = inventory_fetch_assoc($select_department_query_result)){
				$active_class = '';
				$icon_class = "";
				$status = "Active";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
					$status = "Inactive";
				}
				//$select_product = "SELECT * FROM `tbl_vendor`";
		       // $select_department_query_result = inventory_query($select_department_query);
				$list .= 	'<tr '.$active_class.'>
								<td>'.$row_data['fld_vn_id'].'</td>
								<td>'.$row_data['fld_name'].'[Prop-'.$row_data['contact_person'].']'.'</td>
								<td>'.$row_data['fld_add'].'</td>
								
								<td>'.$row_data['fld_phn'].'</td>
								<td>'.$row_data['fld_product'].'</td>
								<td>'.$row_data['gstno'].'</td>
								<td>'.$status.'</td>
								<td><center><a href="'.ROOT_PATH.'/editvendor/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
								&nbsp;<a href="'.ROOT_PATH.'/deletevendor/'.track64_encode($row_data['fld_ai_id']).'" '.$icon_class.'><i class="fa fa-trash" aria-hidden="true"></i></a></center></td>
							</tr>';
			}
		}
	}
	
?>