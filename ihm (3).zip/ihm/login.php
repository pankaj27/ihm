<!doctype html>
<html class="fixed">
<head>

		<!-- Basic -->
		<meta charset="UTF-8">
		<title>Sign In</title>
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/animate/animate.css">

		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />

		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/css/theme.css" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/css/custom.css">

		<!-- Head Libs -->
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/modernizr/modernizr.js"></script>	
	</head>
	<body>
		<!-- start: page -->
		<section class="body-sign">
			<div class="center-sign">
				<a href="<?php inventory_display(ROOT_PATH)?>" class="logo float-left">
					<img src="<?php inventory_display(ROOT_PATH)?>/img/logo.png" height="54" alt="Porto Admin" />
				</a>

				<div class="panel card-sign">
					<div class="card-title-sign mt-3 text-right">
						<h2 class="title text-uppercase font-weight-bold m-0"><i class="fa fa-user mr-1"></i> Sign In</h2>
					</div>
					<div class="card-body">
						<form action="" method="post" id="log_in_form">
							 <?php  if(inventory_session_isset(VARIABLE_PREFIX."login_err")) {?>
							  <div class="alert alert-danger">
									<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
									<?php inventory_display(inventory_get_session(VARIABLE_PREFIX."login_err"));?>
								</div>
                        	
                            <?php inventory_unset_session(VARIABLE_PREFIX."login_err");} ?>
							<div class="form-group mb-3">
								<label>Username</label>
								<div class="input-group input-group-icon">
									<input name="username" type="text" class="form-control form-control-lg" value="<?php if(isset($username)){inventory_display($username);}?>"/>
									<span class="input-group-addon">
										<span class="icon icon-lg">
											<i class="fa fa-user"></i>
										</span>
									</span>
								</div>
							</div>

							<div class="form-group mb-3">
								<div class="clearfix">
									<label class="float-left">Password</label>
								</div>
								<div class="input-group input-group-icon">
									<input name="password" type="password" class="form-control form-control-lg" />
									<span class="input-group-addon">
										<span class="icon icon-lg">
											<i class="fa fa-lock"></i>
										</span>
									</span>
								</div>
							</div>

							<div class="row">
								<div class="col-sm-8">
									
								</div>
								<div class="col-sm-4 text-right">
									<button type="submit" class="btn btn-primary mt-2" name="login">Sign In</button>
								</div>
							</div>
						</form>
					</div>
				</div>

				<p class="text-center text-muted mt-3 mb-3">&copy; Copyright <?php inventory_display(date('Y'))?>. All Rights Reserved.</p>
			</div>
		</section>
		<!-- end: page -->

		<!-- Vendor -->
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery/jquery.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-cookie/jquery-cookie.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/master/style-switcher/style.switcher.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/popper/umd/popper.min.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap/js/bootstrap.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/common/common.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/nanoscroller/nanoscroller.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/magnific-popup/jquery.magnific-popup.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-placeholder/jquery-placeholder.js"></script>
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-validation/jquery.validate.js"></script>
		<!-- Theme Base, Components and Settings -->
		<script src="<?php inventory_display(ROOT_PATH)?>/js/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="<?php inventory_display(ROOT_PATH)?>/js/custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="<?php inventory_display(ROOT_PATH)?>/js/theme.init.js"></script>
	</body>
</html>