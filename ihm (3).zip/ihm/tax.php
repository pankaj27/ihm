<?php include('action/tax_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php if($case == "list"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		<?php 	if($tax_w==0 ){ }else{ ?>
				<a class="btn custom_border" href="<?php inventory_display(ROOT_PATH)?>/addtax"><i class="fa fa-plus" aria-hidden="true"></i> Add Tax</a>
			   <?php } ?>
				
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Tax List</h2>
        </header>
        <div class="card-body">
        	 <table class="table table-bordered table-striped mb-0" id="datatable_with_search">
                <thead>
                    <tr>
                        <th>SGST</th>
                        <th>CGST</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "add"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> Add Tax</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="add_tax_form" action = "<?php inventory_display(ROOT_PATH)?>/addtax" >
            	 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">SGST<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="sgst" name = "sgst" value="<?php inventory_display($sgst)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">CGST<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="cgst" name = "cgst" value="<?php inventory_display($cgst)?>">
                    </div>
                </div>
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_tax">Add Tax</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>
<?php if($case == "edit"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Tax</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="edit_tax_form" action = "<?php inventory_display(ROOT_PATH)?>/updatetax" >
            	 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">SGST<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="sgst" name = "sgst" value="<?php inventory_display($sgst)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">CGST<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="cgst" name = "cgst" value="<?php inventory_display($cgst)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service_name">Isactive<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <div class="switch switch-sm switch-primary">
                            <input type="checkbox" name="is_active" data-plugin-ios-switch <?php if($is_active == '1'){?>  checked="checked" <?php }?> />
                        </div>
                    </div>
                </div>
                <input type="hidden" name="tax_id" value="<?php inventory_display(track64_encode($tax_id))?>">
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="edit_tax">Edit Tax</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>