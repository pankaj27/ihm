<?php include('action/itemtagging_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php if($case == "update"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        	</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i>Item Tagging with Vendors</h2>
        </header>
        <div class="card-body">
        	<form  method="post"  action = "<?php inventory_display(ROOT_PATH)?>updateitemtagging" >
        	 <div class="form-group row">
        	 	
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Category<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "category" id ="item_category">
                            <option value="">Select</option>
                            <?php foreach($category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $category){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row" id="sub_category_div">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Subcategory<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "subcategory" id="item_subcatgory">
                            <option value="">Select</option>
                            <?php foreach($sub_category_array as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" <?php if($key == $subcategory){?> selected<?php } ?>><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row" id="item_div">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Items<span class="required">*</span></label>
                    <div class="col-lg-6" id="itemmm_new">
                        
                    </div>
                </div>
                
                <div class="form-group row" id="sub_category_div">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="service">Vendors<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <select data-plugin-selectTwo class="form-control populate" name = "vendors" id="item_vendors">
                            <option value="">Select</option>
                            <?php foreach($vendors as $key=>$value){?>
                                <option value="<?php inventory_display($key)?>" ><?php inventory_display($value)?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_item">Update </button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
	//alert('hello');
	
	
});
$("#item_subcatgory").change(function(){
	//alert('hello');
	
});
	
	function getsubcate(){
		var cat=$("#item_category2").val();
		//alert('gggg');
		$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getsubcat.php",
  			data :{'cat':cat},
  			success : function(data){
  				console.log(data);
  				$("#subcate").html(data);
  				 
  				}
  			
          }); 
		
	}
	function get_itemdetailss(){
		//alert('hello');
		var cat=$("#item_category").val();
		var subcat=$("#item_subcatgory").val();
		//alert('gggg');
		$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getitemsss.php",
  			data :{'cat':cat,'subcat':subcat},
  			success : function(data){
  				//console.log(data);
  				$("#itemmm_new").html(data);
  				 
  				}
  			
          }); 
	}
	</script>
