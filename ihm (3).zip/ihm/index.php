<?php
	session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('include/config.php');
	include_once('include/inventory_function.php');
	include_once('include/db.php');
	include_once('include/message.php');
	
	$mydate=getdate(date("U"));
	
		
	$page = "";
	$androidapi = "";

	
	if(isset($_REQUEST['page']))
	{
		$page=$_REQUEST['page'];
		
	}
		
	if(isset($_REQUEST['androidapi']))
		$androidapi=$_REQUEST['androidapi'];	
	
	$case= "";
	if(inventory_request_isset('case')){
		$case= inventory_get_request('case');
	}
	$ajax =  "";
	
	
	
	if(inventory_request_isset('ajax'))
	$ajax= inventory_get_request('ajax');	

	if($page == "logout")
	{
		session_unset();
		session_destroy();
		header('Location: '.ROOT_PATH);
		exit;
	}
	
	
	if($androidapi!= 1)
	{
		inventory_include('action/login_action.php');	
	
		if(inventory_session_isset(VARIABLE_PREFIX."user_id"))
		{
			if($page == "")
			{
				//$page = "employee"; 
				$page = "dashboard";
				$case = "list";
			}
			if($ajax !=1)
			{
				if(inventory_session_isset(VARIABLE_PREFIX."empid")){
					//$staff_level =inventory_get_session(VARIABLE_PREFIX."level");
					
				}
				if($page=="indentprintpdf" || $page=="printorder" || $page=="printreceive" || $page=="cashpurchaseprint" ){
					
				}else{
				include_once('include/pagevars.php');
				include_once('include/header.php');
				include_once('include/leftmenu.php');
				}
			}
			
			if(inventory_session_isset(VARIABLE_PREFIX."level") && inventory_get_session(VARIABLE_PREFIX."level") == "3")
			{
				
				include_once("cc.php");
			}else{
				if(inventory_session_isset(VARIABLE_PREFIX."dealer_id"))
				{
					include_once("dealer_page.php");
					
				}else{
					
					include_once($page.".php");
				}	
			}
		
			if($ajax !=1)
			{
				if($page=="indentprintpdf"){
					
				}else{
					include_once("include/footer.php"); 
				}
				
			}
		}
		else
		{
			if($page == "privacy_policy"){
				inventory_include("privacy_policy.php");
			}else{
				inventory_set_session(VARIABLE_PREFIX."redirect_url",$_SERVER['HTTP_HOST'].$_SERVER["REQUEST_URI"]);
				inventory_include("login.php");
			}
			
		}
	}else{
		include_once("api.php");
	}
    ?>
    