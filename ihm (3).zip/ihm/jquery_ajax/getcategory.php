<?php
  session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	$result=array();
	$res='';
	$res2='';
   //$category=$_POST['product_item'];
	 $select_category_query = "select * from tbl_category where fld_isactive='1'";
	$select_sub_category_query_result = inventory_query($select_category_query);
	if(inventory_num_rows($select_sub_category_query_result)>0){
			$res .='<option value="">--select--</option>';
		while($row_data_subcategory = inventory_fetch_assoc($select_sub_category_query_result))	{
			$res .='<option value="'.$row_data_subcategory['fld_ai_id'].'">'.$row_data_subcategory['fld_category'].'</option>';
		}									
	}else{
		$res .='<option value="">--select--</option>';
	}
	
	
	$select_category_query2 = "select * from  tbl_tax where fld_is_active='1'";
	$select_sub_category_query_result2 = inventory_query($select_category_query2);
	if(inventory_num_rows($select_sub_category_query_result2)>0){
		$res2 .='<option value="">--select--</option>';
		while($row_data_subcategory2 = inventory_fetch_assoc($select_sub_category_query_result2)){
			
			$res2 .='<option value="'.$row_data_subcategory2['fld_sgst'].'">'.$row_data_subcategory2['fld_sgst']."+".$row_data_subcategory2['fld_cgst'].'</option>';
	
			
			
		}
		
	}else{
		$res2 .='<option value="">--select--</option>';
	}
	
	
	$result=array("reslt"=>"$res","res2"=>"$res2");
	echo json_encode($result);
?>