<?php
  session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	
	
	
	$dep_id=$_POST['depmnt'];
	$semester=$_POST['semester'];
	$section=$_POST['section'];
	//get
	
	$result=array();
	
	$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
	$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
	if($user_type=="admin" || $user_type=="store_keeper"){
		
		//get today data
		/*---------- New Indent No ----------*/
		
		$neindntqry="select count(*) as noindent from fld_order_new where dep_id='".trim($dep_id)."' and (status='1' or status='2')";
		$neindntqry_rslt=inventory_query($neindntqry);
		$neindntqry_rslt_rw=inventory_fetch_assoc($neindntqry_rslt);
		$today_indent=$neindntqry_rslt_rw['noindent'];
		if($today_indent>0){
			$today_indent=$neindntqry_rslt_rw['noindent'];
		}else{
			$today_indent=0;
		}
		
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqry="select count(*) as appindent from fld_order_new where dep_id='".trim($dep_id)."' and status='2'";
		$apprindntqry_rslt=inventory_query($apprindntqry);
		$apprindntqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
		$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
		if($today_apprindntqry>0){
			$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
		}else{
			$today_apprindntqry=0;
		}
		
		
		/*---------- order value ----------*/
		
		$totoal_qry="select sum(fld_total_amount) as totalv from fld_order_new where dep_id='".trim($dep_id)."' and status='2'";
		$totoal_qry_rslt=inventory_query($totoal_qry);
		$totoal_qry_rslt_rw=inventory_fetch_assoc($totoal_qry_rslt);
		$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
		if($totoal_qry_rslt_no>0){
			$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
		}else{
			$totoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$total_receive_qry="select sum(total) as total from tbl_receive_entry where depid='".trim($dep_id)."' and status='1'";
		$total_receive_rslt=inventory_query($total_receive_qry);
		$total_receive_rw=inventory_fetch_assoc($total_receive_rslt);
		$total_receive_no=$total_receive_rw['total'];
		if($total_receive_no>0){
			$total_receive_no=$total_receive_rw['total'];
		}else{
			$total_receive_no=0;
		}
		
		$result=array("noindent"=>"$today_indent","appindent"=>"$today_apprindntqry","indentval"=>"$totoal_qry_rslt_no","receiveval"=>"$total_receive_no");
		
	}
	if($user_type=="hod"){
		
		//get today data
		/*---------- New Indent No ----------*/
		
		$neindntqry="select count(*) as noindent from fld_order_new where dep_id='".trim($dep_id)."' and (status='1' or status='2')";
		$neindntqry_rslt=inventory_query($neindntqry);
		$neindntqry_rslt_rw=inventory_fetch_assoc($neindntqry_rslt);
		$today_indent=$neindntqry_rslt_rw['noindent'];
		if($today_indent>0){
			$today_indent=$neindntqry_rslt_rw['noindent'];
		}else{
			$today_indent=0;
		}
		
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqry="select count(*) as appindent from fld_order_new where dep_id='".trim($dep_id)."' and status='2'";
		$apprindntqry_rslt=inventory_query($apprindntqry);
		$apprindntqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
		$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
		if($today_apprindntqry>0){
			$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
		}else{
			$today_apprindntqry=0;
		}
		
		
		/*---------- order value ----------*/
		
		$totoal_qry="select sum(fld_total_amount) as totalv from fld_order_new where dep_id='".trim($dep_id)."' and status='2'";
		$totoal_qry_rslt=inventory_query($totoal_qry);
		$totoal_qry_rslt_rw=inventory_fetch_assoc($totoal_qry_rslt);
		$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
		if($totoal_qry_rslt_no>0){
			$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
		}else{
			$totoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$total_receive_qry="select sum(total) as total from tbl_receive_entry where depid='".trim($dep_id)."' and status='1'";
		$total_receive_rslt=inventory_query($total_receive_qry);
		$total_receive_rw=inventory_fetch_assoc($total_receive_rslt);
		$total_receive_no=$total_receive_rw['total'];
		if($total_receive_no>0){
			$total_receive_no=$total_receive_rw['total'];
		}else{
			$total_receive_no=0;
		}
		
		$result=array("noindent"=>"$today_indent","appindent"=>"$today_apprindntqry","indentval"=>"$totoal_qry_rslt_no","receiveval"=>"$total_receive_no");
		
	}
	
	
	
	
	
	echo json_encode($result);
	
?>