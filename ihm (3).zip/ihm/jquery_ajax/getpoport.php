<?php
  session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	
	$startdt=$_POST['startdt'];
	$enddte=$_POST['enddte'];
	
  	$name_search = "";
		$list = "";	
		$status_array = array("0"=>"Inactive","1"=>"Active");
		
		

		     $select_po_query = "SELECT  * from `tbl_poorder` where require_on between '".$startdt."' and '".$enddte."' and status='1'  order by id desc";
			   $select_po_query_result = inventory_query($select_po_query); 
			   if(inventory_num_rows($select_po_query_result)>0){
		      while($row_d = inventory_fetch_assoc($select_po_query_result)){
				//echo 7;
				$active_class = '';
				$icon_class = "";
				if($row_d['status'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$row_d['depid']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 /*if($row_d['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				  * */
				  
				echo 	'<tr '.$active_class.'>
								<td>'.$row_d['poid_prex'].'/'.$row_d['poid'].'</td>
								<td>'.$row_d['indent_id'].'</td>
								<td>'.$row_d['vendor_id'].'</td>
								<td>'.$row_d['submit_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_d['require_on'].'</td></tr>';
								
								
				
								
								
				}		

              }
			   	
	  //  }
	    
		
?>