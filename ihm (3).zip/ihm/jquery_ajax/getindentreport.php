<?php
    session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	
	$startdt=$_POST['startdt'];
	$enddte=$_POST['enddte'];
	
    $name_search = "";
	$list = "";	
	
		
          $select_user_details_query = "SELECT  * from `fld_order_new` where material_req_on between '".$startdt."' and '".$enddte."' and   status='2'   order by fld_ai_id desc";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		if(inventory_num_rows($select_user_details_query_result)>0){
			
						
			
			while($row_data = inventory_fetch_assoc($select_user_details_query_result)){
				
				$active_class = '';
				$icon_class = "";
				if($row_data['fld_is_active'] == '0'){
					$active_class = 'class = "inactive_class"';
					$icon_class = 'class = "icon_white"';
				}

               /// get hod depi id
               
				
				$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$row_data['dep_id']."'";
				$select_department_query_result = inventory_query($select_department_query); 
			     $row_data22 = inventory_fetch_assoc($select_department_query_result);
				 $user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
				 if($row_data['status']==0){$st="<button class='btn btn-info btn-xs'>Save as Draft</button>"; }
				 if($row_data['status']==1){$st="<button class='btn btn-warning btn-xs'>Pending for Approval</button>"; }
				 if($row_data['status']==2){$st="<button class='btn btn-success btn-xs'>Approved</button>"; }
				  if($row_data['status']==3){$st="<button class='btn btn-danger btn-xs'>Approved</button>"; }
				echo '<tr '.$active_class.'>
				                 <td>'.$row_data['fld_order_id'].'</td>
								<td>'.$row_data['material_req_on'].'</td>
								<td>'.$row_data['menu_name'].'</td>
							
								<td>'.$row_data['indent_create_on'].'</td>
								<td>'.$row_data22['fld_department'].'</td>
								<td>'.$row_data['fld_total_amount'].'</td>
								<td>'.$st.'</td>
								
								</tr>';
								
								
					}			
			}
			
		
	                 
	            
			
			
		
		
			  
		
?>