<?php
  session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	$result=array();
	$res='';
	//$res2='';
   //$category=$_POST['product_item'];
   $item_code=$_POST['itemcode'];
	 $select_category_query = "select * from tbl_item where fld_is_active='1' and fld_ai_id='".$item_code."'";
	$select_sub_category_query_result = inventory_query($select_category_query);
	if(inventory_num_rows($select_sub_category_query_result)>0){
			//$res .='<option value="">--select--</option>';
		$row_data_subcategory = inventory_fetch_assoc($select_sub_category_query_result);
		
		$fld_unit=$row_data_subcategory['fld_unit'];
		$fld_price=$row_data_subcategory['fld_price'];
		$fld_tax=$row_data_subcategory['tbl_tax'];
		
		
		$select_unir = "select * from tbl_unit where fld_is_active='1' and fld_ai_id='".$fld_unit."'";
		$select_unitresult = inventory_query($select_unir);
		$row_unit = inventory_fetch_assoc($select_unitresult);
		$fld_unit1=$row_unit['fld_unit'];
		//if(isset($row_tax) && !empty($row_tax)){
		//	$taxvalll=$row_tax['fld_sgst'];
		//}else{
		//	$taxvalll=0;
		//}
		
		
		//get tax value from tax table
		
		$select_tax_query = "select * from tbl_tax where fld_is_active='1' and fld_ai_id='".$fld_tax."'";
		$select_tax_result = inventory_query($select_tax_query);
		$row_tax = inventory_fetch_assoc($select_tax_result);
		if(isset($row_tax) && !empty($row_tax)){
			$taxvalll=$row_tax['fld_sgst'];
		}else{
			$taxvalll=0;
		}
		
			//$res .='<option value="'.$row_data_subcategory['fld_ai_id'].'">'.$row_data_subcategory['fld_category'].'</option>';
		$result=array("fld_unit"=>"$fld_unit1","fld_price"=>"$fld_price","fld_tax"=>"$taxvalll");									
	}
	
	
	
	
	
	echo json_encode($result);
?>