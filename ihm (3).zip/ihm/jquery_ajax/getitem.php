<?php
  session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	
   $categ=$_POST['categ'];
   $subcateg=$_POST['subcateg'];
	 $select_category_query = "select * from tbl_item where fld_is_active='1' and fld_category_id='".$categ."' and fld_sub_category_id='".$subcateg."'";
	$select_sub_category_query_result = inventory_query($select_category_query);
	if(inventory_num_rows($select_sub_category_query_result)>0){
			echo '<option value="">--select--</option>';
		while($row_data_subcategory = inventory_fetch_assoc($select_sub_category_query_result))	{
			echo '<option value="'.$row_data_subcategory['fld_ai_id'].'">'.$row_data_subcategory['fld_name'].'</option>';
		}									
	}else{
		echo '<option value="">--select--</option>';
	}
?>