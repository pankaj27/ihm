<?php
  session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	$result=array();
	$res='';
	//$res2='';
   //$category=$_POST['product_item'];
   $poid=$_POST['poid'];
   $result=array();
   $tblrw="";
   //get query related data
     $select_poid_query = "select * from fld_cash_purchase where fld_order_id='".$poid."' and status='2'";
	$select_poid_query_result = inventory_query($select_poid_query);
	if(inventory_num_rows($select_poid_query_result)>0){
		$row_data_po = inventory_fetch_assoc($select_poid_query_result);
		
		$indent_id=$row_data_po['fld_order_id'];
		$require_on=$row_data_po['material_req_on'];
		//$vendor_id=$row_data_po['vendor_id'];
		$depid=$row_data_po['dep_id'];
		
		//get vendor id
		/* $select_vendor_query = "select * from tbl_vendor where fld_ai_id='".$vendor_id."' and fld_is_active='1'";
		$select_vendor_result = inventory_query($select_vendor_query);
		$row_data_vendor = inventory_fetch_assoc($select_vendor_result);
	
		$vendorname=$row_data_vendor['fld_vn_id'];
		*/
		//get departnema
		
	    $select_department_query = "select * from tbl_department where fld_ai_id='".$depid."' and fld_is_active='1'";
		$select_department_result = inventory_query($select_department_query);
		$row_data_deep = inventory_fetch_assoc($select_department_result);
	
		$deepname=$row_data_deep['fld_department'];
		
		
		####################################################################
			 $query1 = "select * from tbl_cashpurchase_item inner join tbl_item on tbl_item.fld_ai_id= tbl_cashpurchase_item.fld_item_id  where tbl_cashpurchase_item.order_id='".trim($indent_id)."'";
			$result1 = inventory_query($query1);
			if(inventory_num_rows($result1)>0){
					$sln=1;
				    //$sln=1;
			        $fld_gross_total=0;
			        $fld_cgst=0;
			        $fld_total_amount=0;
					while($row1=inventory_fetch_assoc($result1)){
						$fld_item_id=$row1['fld_item_id'];
						$fld_cat_id=$row1['fld_itm_cat'];
						$fls_subcat_id=$row1['fld_item_subcat'];
						$fld_quantity=$row1['fld_quantity'];
						$fld_amount=$row1['fld_amount'];
						$item_gross=$row1['item_gross'];
						$fld_gross_total =$fld_gross_total+$item_gross;
						$item_tax=$row1['item_tax'];

						$item_tax_amount=$row1['item_tax_amount'];

						$fld_cgst=$fld_cgst+$item_tax_amount;
						$item_total=$row1['item_total'];
												///get item unit
						$queryunit1 = "select * from tbl_item where fld_ai_id='".trim($fld_item_id). "'";
						$resultunit = inventory_query($queryunit1);
						$rowunit=inventory_fetch_assoc($resultunit);
						$unitname=$rowunit['fld_unit'];

						$fld_total_amount=$fld_total_amount+$item_total;
						
						
						
						$tblrw .='<tr><td>';
									
									$select_category_query = "select * from tbl_category where fld_isactive='1'";
									$select_sub_category_query_result = inventory_query($select_category_query);
									if(inventory_num_rows($select_sub_category_query_result)>0){
										$tblrw .='<select class="form-control" id="category_'.$sln.'" name="category_'.$sln.'" onchange="getsubcategory(this.id);">
												<option value="">--select--</option>';
												
										while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										  if($row_data_category['fld_ai_id']==$fld_cat_id){  $slt='selected'; }else{ $slt=''; }
											$tblrw .='<option value="'.$row_data_category['fld_ai_id'].'" '.$slt.'>'. $row_data_category['fld_category'].'</option>';
										
												
													
												}
									
											$tblrw .='</select>';		
												
										
									}
						
						      $tblrw .='</td>
			                			<td>';
										
										
										
										
										$select_subcat_query = "select * from tbl_sub_category where fld_is_active='1'";
									    $select_subcat_result = inventory_query($select_subcat_query);
									   if(inventory_num_rows($select_subcat_result)>0){
									   	$tblrw .='<select   class="form-control" id="subcategory_'.$sln.'" name="subcategory_'.$sln.'" onchange="getitem(this.id);">
												<option value="">--select--</option>';
												
												
										while($row_subcategory = inventory_fetch_assoc($select_subcat_result)){
											 if($row_subcategory['fld_ai_id']==$fls_subcat_id){  $slt2='selected'; }else{ $slt2=''; }
												$tblrw .='<option value="'.$row_subcategory['fld_ai_id'].'" '.$slt2.'>'. $row_subcategory['fld_sub_category'].'</option>';
										
											
												}
										
											$tblrw .='</select>';
												
											} 		
												
										
									   //}
											
										$tblrw .='</td><td>';	
										
										
										
										$select_item = "select * from tbl_item where fld_is_active='1'";
										$select_item_result = inventory_query($select_item);
										if(inventory_num_rows($select_item_result)>0){
									
											$tblrw .='<select class="form-control" id="item_'.$sln.'" name="item_'.$sln.'" onchange="getitemdetailsinfo(this.id)">	<option value="">--select--</option>';
												
									
												while($row_item = inventory_fetch_assoc($select_item_result)){
													 if($row_item['fld_ai_id']==$fld_item_id){  $slt3='selected'; }else{ $slt3=''; }
										
												$tblrw .='<option value="'.$row_item['fld_ai_id'].'" '.$slt3.' >'. $row_item['fld_name'].'</option>';
										
													
													
												}
									
											$tblrw .='</select>';
											
												
											} 
									   	
								
								$tblrw .='</td>
			                		<td><input readonly value="'.$fld_quantity.'" style="width:50px;" type="text" class="form-control" name="rcvqty_'.$sln.'" id="rcvqty_'.$sln.'" style="width:80px"  ></td>
			                		<td><div id="divqty_'.$sln.'" style="width:40px;">'. $unitname.'</div></td>
			                		<td><input value="'.$fld_quantity.'" style="width:50px;" type="text" class="form-control" name="qty_'.$sln.'" id="qty_'.$sln.'" style="width:80px" onblur="gettotalvalproduct(this.id);" ></td>';
			                	$tblrw .='<td><button type="button" class="btn btn-link" data-toggle="modal" data-target="#myModal_'.$sln.'">Click here</button>
			                			 <div class="modal fade" id="myModal_'.$sln.'" role="dialog">
										    <div class="modal-dialog modal-sm">
										      <div class="modal-content">
										        <div class="modal-header">
										          
										          <h4 class="modal-title">Remarks</h4>
										        </div>
										        <div class="modal-body">
										          <textarea name="remarks_'.$sln.'" class="form-control"></textarea>
										        </div>
										        <div class="modal-footer">
										          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										        </div>
										      </div>
										    </div>
										  </div>
								</td>
			                	';	
			                	$tblrw .='	<td><input value="'. $fld_amount.'" style="width:80px;" type="text" readonly class="form-control" name="price_'.$sln.'" id="price_'.$sln.'" style="width:100px" ></td>
			                		<td><input value="'. $item_gross.'" style="width:80px;" type="text" readonly class="form-control" name="gross_'.$sln.'" id="gross_'.$sln.'" style="width:100px" ></td>
			                		';
								
							  $tblrw .='<td>
							  			<input  value="'. $item_tax.'" style="width:80px;" type="text" readonly class="form-control" name="tax_'.$sln.'" id="tax_'.$sln.'" style="width:100px" >
							  			</td>';
										
								$tblrw .='</td>
					                		<td><input value="'.$item_total.'" style="width:80px;" type="text" readonly class="form-control" name="totar_'.$sln.'" id="totar_'.$sln.'" style="width:100px;text-align: right;" ></td>
					                	</tr>';		
										
						
						
						$sln++;
		
					}
			}
		
		
		$result=array("status"=>"1","totrow"=>"$sln","indentid"=>"$indent_id","deepn"=>"$deepname","reqon"=>"$require_on","department"=>"$depid","tbldt"=>"$tblrw","gross_total"=>number_format((float)($fld_gross_total), 2, '.', ''),"tax"=>number_format((float)($fld_cgst), 2, '.', ''),"total"=>number_format((float)($fld_total_amount), 2, '.', ''));
		
		
	}else{
		$result=array("status"=>"0","totrow"=>"0","indentid"=>"","deepn"=>"","reqon"=>"","department"=>"","tbldt"=>"","gross_total"=>"","tax"=>"","total"=>"");
	}
	
	
	
	
	
	echo json_encode($result);
?>