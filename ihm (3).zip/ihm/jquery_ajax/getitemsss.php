<?php
    session_start();
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL); 
	include_once('../include/config.php');
	include_once('../include/inventory_function.php');
	include_once('../include/db.php');
	include_once('../include/message.php');
	
   $categ=$_POST['cat'];
   $subcateg=$_POST['subcat'];
	 $select_category_query = "select * from tbl_item where fld_is_active='1' and fld_category_id='".$categ."' and fld_sub_category_id='".$subcateg."'";
	$select_sub_category_query_result = inventory_query($select_category_query);
	if(inventory_num_rows($select_sub_category_query_result)>0){
		echo"<table class='table'>"	;
		echo '<tr><td>Items</td><td>Vendors</td></tr>';
		
		while($row_data_subcategory = inventory_fetch_assoc($select_sub_category_query_result))	{ 
		       $vendid=$row_data_subcategory['supplied_vendor'];
			   $select_vendor_query = "select * from  tbl_vendor where fld_ai_id='".$vendid."'";
	           $select_vendors_query_result = inventory_query($select_vendor_query);
			   $row_data_vendors = inventory_fetch_assoc($select_vendors_query_result);
			   $vennamee=$row_data_vendors['fld_name'];
	
			//echo '<option value="'.$row_data_subcategory['fld_ai_id'].'">'.$row_data_subcategory['fld_name'].'</option>';
			echo '<tr><td><input type="checkbox" name="items[]" value="'.$row_data_subcategory['fld_ai_id'].'"  />'.$row_data_subcategory['fld_name'].'</td><td>'.$vennamee.'</td></tr>';
		
			//echo '<input type="checkbox" name="items[]" value="'.$row_data_subcategory['fld_ai_id'].'"  />'.$row_data_subcategory['fld_name']."&nbsp;";
		}	
			echo '</table>';
	}else{
		
	}
?>