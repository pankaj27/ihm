<?php include('action/dashboard_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php
$user_type = inventory_get_session(VARIABLE_PREFIX."user_type");
$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
if($user_type=="admin" || $user_type=="store_keeper"){
	
	//get today data
		/*---------- New Indent No ----------*/
		
	$neindntqry="select count(*) as noindent from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='1'";
	$neindntqry_rslt=inventory_query($neindntqry);
	$neindntqry_rslt_rw=inventory_fetch_assoc($neindntqry_rslt);
	$today_indent=$neindntqry_rslt_rw['noindent'];
	if($today_indent>0){
		$today_indent=$neindntqry_rslt_rw['noindent'];
	}else{
		$today_indent=0;
	}
	
	/*---------- New Indent No App ----------*/
		
	$apprindntqry="select count(*) as appindent from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='2'";
	$apprindntqry_rslt=inventory_query($apprindntqry);
	$apprindntqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
	$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
	if($today_apprindntqry>0){
		$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
	}else{
		$today_apprindntqry=0;
	}
	
	
	/*---------- Receive item ----------*/
		
	$receiveitemqry="select count(*) as recepo from tbl_receive_entry where receiveon='".trim(date('Y-m-d'))."' and status='1'";
	$receiveitemqry_rslt=inventory_query($receiveitemqry);
	$receiveitemqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
	$today_receiveitemqry=$receiveitemqry_rslt_rw['recepo'];
	if($today_receiveitemqry>0){
		$today_receiveitemqry=$receiveitemqry_rslt_rw['recepo'];
	}else{
		$today_receiveitemqry=0;
	}
	
	/*---------- order value ----------*/
		
	$totoal_qry="select sum(fld_total_amount) as totalv from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='2'";
	$totoal_qry_rslt=inventory_query($totoal_qry);
	$totoal_qry_rslt_rw=inventory_fetch_assoc($totoal_qry_rslt);
	$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
	if($totoal_qry_rslt_no>0){
		$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
	}else{
		$totoal_qry_rslt_no=0;
	}
	/*---------- Receive order value ----------*/
	$total_receive_qry="select sum(total) as total from tbl_receive_entry where receiveon='".trim(date('Y-m-d'))."' and status='1'";
	$total_receive_rslt=inventory_query($total_receive_qry);
	$total_receive_rw=inventory_fetch_assoc($total_receive_rslt);
	$total_receive_no=$total_receive_rw['total'];
	if($total_receive_no>0){
		$total_receive_no=$total_receive_rw['total'];
	}else{
		$total_receive_no=0;
	}
	
	
	//get week data    
	
		/*--------------- get week no from particular date -----------------*/
		$ddate = date('Y-m-d');
		$date = new DateTime($ddate);
		$week = $date->format("W");
	   // "Weeknummer: $week";
		$year=date('Y');
		
		$dateTime = new DateTime();
	    $dateTime->setISODate($year, $week);
         $startdate = $dateTime->format('Y-m-d');
		//echo "<br>";
	    $dateTime->modify('+6 days');
	    $enddate = $dateTime->format('Y-m-d');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_wk="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1'";
		$neindntqrywk_rslt=inventory_query($neindntqry_wk);
		$neindntqrywk_rslt_rw=inventory_fetch_assoc($neindntqrywk_rslt);
		$wk_indent=$neindntqrywk_rslt_rw['noindent'];
		if($wk_indent>0){
			$wk_indent=$neindntqrywk_rslt_rw['noindent'];
		}else{
			$wk_indent=0;
		}
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqrywk="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='2'";
		$apprindntqrywk_rslt=inventory_query($apprindntqrywk);
		$apprindntqrywk_rslt_rw=inventory_fetch_assoc($apprindntqrywk_rslt);
		$wk_apprindntqry=$apprindntqrywk_rslt_rw['appindent'];
		if($wk_apprindntqry>0){
			$wk_apprindntqry=$apprindntqrywk_rslt_rw['appindent'];
		}else{
			$wk_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqrywk="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1'";
		$receiveitemqrywk_rslt=inventory_query($receiveitemqrywk);
		$receiveitemqrywk_rslt_rw=inventory_fetch_assoc($receiveitemqrywk_rslt);
		$wk_receiveitemqry=$receiveitemqrywk_rslt_rw['recepo'];
		if($wk_receiveitemqry>0){
			$wk_receiveitemqry=$receiveitemqrywk_rslt_rw['recepo'];
		}else{
			$wk_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalwk_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='2'";
		$totoalwk_qry_rslt=inventory_query($totoalwk_qry);
		$totoalwk_qry_rslt_rw=inventory_fetch_assoc($totoalwk_qry_rslt);
		$wktotoal_qry_rslt_no=$totoalwk_qry_rslt_rw['totalv'];
		if($wktotoal_qry_rslt_no>0){
			$wktotoal_qry_rslt_no=$totoalwk_qry_rslt_rw['totalv'];
		}else{
			$wktotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalwk_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1'";
		$totalwk_receive_rslt=inventory_query($totalwk_receive_qry);
		$totalwk_receive_rw=inventory_fetch_assoc($totalwk_receive_rslt);
		$totalwk_receive_no=$totalwk_receive_rw['total'];
		if($totalwk_receive_no>0){
			$totalwk_receive_no=$totalwk_receive_rw['total'];
		}else{
			$totalwk_receive_no=0;
		}
	
	
	
	
	 	
		//get month data    
	
		/*--------------- get week no from particular date -----------------*/
		 $first_day = date('Y-m-01'); 
		 $last_day = date('Y-m-t');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_mnth="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1'";
		$neindntqrymnth_rslt=inventory_query($neindntqry_mnth);
		$neindntqrymnth_rslt_rw=inventory_fetch_assoc($neindntqrymnth_rslt);
		$mnth_indent=$neindntqrymnth_rslt_rw['noindent'];
		if($mnth_indent>0){
			$mnth_indent=$neindntqrymnth_rslt_rw['noindent'];
		}else{
			$mnth_indent=0;
		}
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqrymnth="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='2'";
		$apprindntqrymnth_rslt=inventory_query($apprindntqrymnth);
		$apprindntqrymnth_rslt_rw=inventory_fetch_assoc($apprindntqrymnth_rslt);
		$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		if($mnth_apprindntqry>0){
			$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		}else{
			$mnth_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqrymnth="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1'";
		$receiveitemqrymnth_rslt=inventory_query($receiveitemqrymnth);
		$receiveitemqrymnth_rslt_rw=inventory_fetch_assoc($receiveitemqrymnth_rslt);
		$mnth_receiveitemqry=$receiveitemqrymnth_rslt_rw['recepo'];
		if($mnth_receiveitemqry>0){
			$mnth_receiveitemqry=$receiveitemqrymnth_rslt_rw['recepo'];
		}else{
			$mnth_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalmnth_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='2'";
		$totoalmnh_qry_rslt=inventory_query($totoalmnth_qry);
		$totoalmnth_qry_rslt_rw=inventory_fetch_assoc($totoalmnh_qry_rslt);
		$mnthtotoal_qry_rslt_no=$totoalmnth_qry_rslt_rw['totalv'];
		if($mnthtotoal_qry_rslt_no>0){
			$mnthtotoal_qry_rslt_no=$totoalmnth_qry_rslt_rw['totalv'];
		}else{
			$mnthtotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalmnth_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1'";
		$totalmnth_receive_rslt=inventory_query($totalmnth_receive_qry);
		$totalmnth_receive_rw=inventory_fetch_assoc($totalmnth_receive_rslt);
		$totalmnth_receive_no=$totalmnth_receive_rw['total'];
		if($totalmnth_receive_no>0){
			$totalmnth_receive_no=$totalmnth_receive_rw['total'];
		}else{
			$totalmnth_receive_no=0;
		}
	
	
	 
	
	//get Year  data    
	
		/*--------------- get week no from particular date -----------------*/
		 $first_day_year = date('Y-01-01'); 
		 $last_day_year = date('Y-12-31');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_yr="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1'";
		 $neindntqryyr_rslt=inventory_query($neindntqry_yr);
		 $neindntqryyr_rslt_rw=inventory_fetch_assoc($neindntqryyr_rslt);
		 $yr_indent=$neindntqryyr_rslt_rw['noindent'];
		 if($yr_indent>0){
				$yr_indent=$neindntqryyr_rslt_rw['noindent'];
		}else{
				$yr_indent=0;
		 }
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqryyr="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='2'";
		$apprindntqryyr_rslt=inventory_query($apprindntqryyr);
		$apprindntqryyr_rslt_rw=inventory_fetch_assoc($apprindntqryyr_rslt);
		$yr_apprindntqry=$apprindntqryyr_rslt_rw['appindent'];
		if($yr_apprindntqry>0){
			$yr_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		}else{
			$yr_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqryyr="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1'";
		$receiveitemqryyr_rslt=inventory_query($receiveitemqryyr);
		$receiveitemqryyr_rslt_rw=inventory_fetch_assoc($receiveitemqryyr_rslt);
		$yr_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		if($yr_receiveitemqry>0){
			$yr_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		}else{
			$yr_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalyr_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='2'";
		$totoalyr_qry_rslt=inventory_query($totoalyr_qry);
		$totoalyr_qry_rslt_rw=inventory_fetch_assoc($totoalyr_qry_rslt);
		$yrtotoal_qry_rslt_no=$totoalyr_qry_rslt_rw['totalv'];
		if($yrtotoal_qry_rslt_no>0){
			$yrtotoal_qry_rslt_no=$totoalyr_qry_rslt_rw['totalv'];
		}else{
			$yrtotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalyr_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1'";
		$totalyr_receive_rslt=inventory_query($totalyr_receive_qry);
		$totalyr_receive_rw=inventory_fetch_assoc($totalyr_receive_rslt);
		$totalyr_receive_no=$totalyr_receive_rw['total'];
		if($totalyr_receive_no>0){
			$totalyr_receive_no=$totalyr_receive_rw['total'];
		}else{
			$totalyr_receive_no=0;
		}
		
		
		
		 //All time   data    
	
		/*--------------- get week no from particular date -----------------*/
		// $first_day_year = date('Y-01-01'); 
		// $last_day_year = date('Y-12-31');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_all="select count(*) as noindent from fld_order_new  where  status='1'";
		 $neindntqryall_rslt=inventory_query($neindntqry_all);
		 $neindntqryall_rslt_rw=inventory_fetch_assoc($neindntqryall_rslt);
		 $all_indent=$neindntqryall_rslt_rw['noindent'];
		 if($all_indent>0){
				$all_indent=$neindntqryall_rslt_rw['noindent'];
		}else{
				$all_indent=0;
		 }
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqryall="select count(*) as appindent from fld_order_new where  status='2'";
		$apprindntqryall_rslt=inventory_query($apprindntqryall);
		$apprindntqryall_rslt_rw=inventory_fetch_assoc($apprindntqryall_rslt);
		$all_apprindntqry=$apprindntqryall_rslt_rw['appindent'];
		if($all_apprindntqry>0){
			$all_apprindntqry=$apprindntqryall_rslt_rw['appindent'];
		}else{
			$all_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqryall="select count(*) as recepo from tbl_receive_entry where  status='1'";
		$receiveitemqryall_rslt=inventory_query($receiveitemqryall);
		$receiveitemqryall_rslt_rw=inventory_fetch_assoc($receiveitemqryall_rslt);
		$all_receiveitemqry=$receiveitemqryall_rslt_rw['recepo'];
		if($all_receiveitemqry>0){
			$all_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		}else{
			$all_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalall_qry="select sum(fld_total_amount) as totalv from fld_order_new where  status='2'";
		 $totoalall_qry_rslt=inventory_query($totoalall_qry);
		 $totoalall_qry_rslt_rw=inventory_fetch_assoc($totoalall_qry_rslt);
		 $alltotoal_qry_rslt_no=$totoalall_qry_rslt_rw['totalv'];
		 if($alltotoal_qry_rslt_no>0){
			$alltotoal_qry_rslt_no=$totoalall_qry_rslt_rw['totalv'];
		 }else{
			$alltotoal_qry_rslt_no=0;
		 }
		
		
		/*---------- Receive order value ----------*/
		$totalall_receive_qry="select sum(total) as total from tbl_receive_entry where  status='1'";
		$totalall_receive_rslt=inventory_query($totalall_receive_qry);
		$totalall_receive_rw=inventory_fetch_assoc($totalall_receive_rslt);
		$totalall_receive_no=$totalall_receive_rw['total'];
		if($totalall_receive_no>0){
			$totalall_receive_no=$totalall_receive_rw['total'];
		}else{
			$totalall_receive_no=0;
		}
		
		
		
		
		
		
	  /*----------------------  GET ALL DEPARTMENTS ---------------------------------------*/
	  $qry_departmnt="select * from tbl_department where fld_is_active='1' ";
	  $qry_department_rslt=inventory_query($qry_departmnt);
	
	
	
	
	
	

}


if($user_type=="hod"){
	
	//get today data
		/*---------- New Indent No ----------*/
		
	$neindntqry="select count(*) as noindent from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='1' and approve_by='".$user_id."'";
	$neindntqry_rslt=inventory_query($neindntqry);
	$neindntqry_rslt_rw=inventory_fetch_assoc($neindntqry_rslt);
	$today_indent=$neindntqry_rslt_rw['noindent'];
	if($today_indent>0){
		$today_indent=$neindntqry_rslt_rw['noindent'];
	}else{
		$today_indent=0;
	}
	
	/*---------- New Indent No App ----------*/
		
	$apprindntqry="select count(*) as appindent from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='2' and approve_by='".$user_id."'";
	$apprindntqry_rslt=inventory_query($apprindntqry);
	$apprindntqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
	$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
	if($today_apprindntqry>0){
		$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
	}else{
		$today_apprindntqry=0;
	}
	
	
	/*---------- Receive item ----------*/
		
	$receiveitemqry="select count(*) as recepo from tbl_receive_entry where receiveon='".trim(date('Y-m-d'))."' and status='1' and crtdby='".$user_id."'";
	$receiveitemqry_rslt=inventory_query($receiveitemqry);
	$receiveitemqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
	$today_receiveitemqry=$receiveitemqry_rslt_rw['recepo'];
	if($today_receiveitemqry>0){
		$today_receiveitemqry=$receiveitemqry_rslt_rw['recepo'];
	}else{
		$today_receiveitemqry=0;
	}
	
	/*---------- order value ----------*/
		
	$totoal_qry="select sum(fld_total_amount) as totalv from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='2' and approve_by='".$user_id."'";
	$totoal_qry_rslt=inventory_query($totoal_qry);
	$totoal_qry_rslt_rw=inventory_fetch_assoc($totoal_qry_rslt);
	$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
	if($totoal_qry_rslt_no>0){
		$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
	}else{
		$totoal_qry_rslt_no=0;
	}
	/*---------- Receive order value ----------*/
	$total_receive_qry="select sum(total) as total from tbl_receive_entry where receiveon='".trim(date('Y-m-d'))."' and status='1' and crtdby='".$user_id."' ";
	$total_receive_rslt=inventory_query($total_receive_qry);
	$total_receive_rw=inventory_fetch_assoc($total_receive_rslt);
	$total_receive_no=$total_receive_rw['total'];
	if($total_receive_no>0){
		$total_receive_no=$total_receive_rw['total'];
	}else{
		$total_receive_no=0;
	}
	
	
	//get week data    
	
		/*--------------- get week no from particular date -----------------*/
		$ddate = date('Y-m-d');
		$date = new DateTime($ddate);
		$week = $date->format("W");
	   // "Weeknummer: $week";
		$year=date('Y');
		
		$dateTime = new DateTime();
	    $dateTime->setISODate($year, $week);
         $startdate = $dateTime->format('Y-m-d');
		//echo "<br>";
	    $dateTime->modify('+6 days');
	    $enddate = $dateTime->format('Y-m-d');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_wk="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1' and approve_by='".$user_id."'";
		$neindntqrywk_rslt=inventory_query($neindntqry_wk);
		$neindntqrywk_rslt_rw=inventory_fetch_assoc($neindntqrywk_rslt);
		$wk_indent=$neindntqrywk_rslt_rw['noindent'];
		if($wk_indent>0){
			$wk_indent=$neindntqrywk_rslt_rw['noindent'];
		}else{
			$wk_indent=0;
		}
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqrywk="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='2' and approve_by='".$user_id."'";
		$apprindntqrywk_rslt=inventory_query($apprindntqrywk);
		$apprindntqrywk_rslt_rw=inventory_fetch_assoc($apprindntqrywk_rslt);
		$wk_apprindntqry=$apprindntqrywk_rslt_rw['appindent'];
		if($wk_apprindntqry>0){
			$wk_apprindntqry=$apprindntqrywk_rslt_rw['appindent'];
		}else{
			$wk_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqrywk="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1' and crtdby='".$user_id."'";
		$receiveitemqrywk_rslt=inventory_query($receiveitemqrywk);
		$receiveitemqrywk_rslt_rw=inventory_fetch_assoc($receiveitemqrywk_rslt);
		$wk_receiveitemqry=$receiveitemqrywk_rslt_rw['recepo'];
		if($wk_receiveitemqry>0){
			$wk_receiveitemqry=$receiveitemqrywk_rslt_rw['recepo'];
		}else{
			$wk_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalwk_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='2' and approve_by='".$user_id."'";
		$totoalwk_qry_rslt=inventory_query($totoalwk_qry);
		$totoalwk_qry_rslt_rw=inventory_fetch_assoc($totoalwk_qry_rslt);
		$wktotoal_qry_rslt_no=$totoalwk_qry_rslt_rw['totalv'];
		if($wktotoal_qry_rslt_no>0){
			$wktotoal_qry_rslt_no=$totoalwk_qry_rslt_rw['totalv'];
		}else{
			$wktotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalwk_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1' and crtdby='".$user_id."'";
		$totalwk_receive_rslt=inventory_query($totalwk_receive_qry);
		$totalwk_receive_rw=inventory_fetch_assoc($totalwk_receive_rslt);
		$totalwk_receive_no=$totalwk_receive_rw['total'];
		if($totalwk_receive_no>0){
			$totalwk_receive_no=$totalwk_receive_rw['total'];
		}else{
			$totalwk_receive_no=0;
		}
	
	
	
	
	 	
		//get month data    
	
		/*--------------- get week no from particular date -----------------*/
		 $first_day = date('Y-m-01'); 
		 $last_day = date('Y-m-t');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_mnth="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1' and approve_by='".$user_id."'";
		$neindntqrymnth_rslt=inventory_query($neindntqry_mnth);
		$neindntqrymnth_rslt_rw=inventory_fetch_assoc($neindntqrymnth_rslt);
		$mnth_indent=$neindntqrymnth_rslt_rw['noindent'];
		if($mnth_indent>0){
			$mnth_indent=$neindntqrymnth_rslt_rw['noindent'];
		}else{
			$mnth_indent=0;
		}
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqrymnth="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='2' and approve_by='".$user_id."'";
		$apprindntqrymnth_rslt=inventory_query($apprindntqrymnth);
		$apprindntqrymnth_rslt_rw=inventory_fetch_assoc($apprindntqrymnth_rslt);
		$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		if($mnth_apprindntqry>0){
			$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		}else{
			$mnth_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqrymnth="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1' and crtdby='".$user_id."'";
		$receiveitemqrymnth_rslt=inventory_query($receiveitemqrymnth);
		$receiveitemqrymnth_rslt_rw=inventory_fetch_assoc($receiveitemqrymnth_rslt);
		$mnth_receiveitemqry=$receiveitemqrymnth_rslt_rw['recepo'];
		if($mnth_receiveitemqry>0){
			$mnth_receiveitemqry=$receiveitemqrymnth_rslt_rw['recepo'];
		}else{
			$mnth_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalmnth_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='2' and approve_by='".$user_id."'";
		$totoalmnh_qry_rslt=inventory_query($totoalmnth_qry);
		$totoalmnth_qry_rslt_rw=inventory_fetch_assoc($totoalmnh_qry_rslt);
		$mnthtotoal_qry_rslt_no=$totoalmnth_qry_rslt_rw['totalv'];
		if($mnthtotoal_qry_rslt_no>0){
			$mnthtotoal_qry_rslt_no=$totoalmnth_qry_rslt_rw['totalv'];
		}else{
			$mnthtotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalmnth_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1' and crtdby='".$user_id."'";
		$totalmnth_receive_rslt=inventory_query($totalmnth_receive_qry);
		$totalmnth_receive_rw=inventory_fetch_assoc($totalmnth_receive_rslt);
		$totalmnth_receive_no=$totalmnth_receive_rw['total'];
		if($totalmnth_receive_no>0){
			$totalmnth_receive_no=$totalmnth_receive_rw['total'];
		}else{
			$totalmnth_receive_no=0;
		}
	
	
	 
	
	//get Year  data    
	
		/*--------------- get week no from particular date -----------------*/
		 $first_day_year = date('Y-01-01'); 
		 $last_day_year = date('Y-12-31');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_yr="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1' and approve_by='".$user_id."'";
		 $neindntqryyr_rslt=inventory_query($neindntqry_yr);
		 $neindntqryyr_rslt_rw=inventory_fetch_assoc($neindntqryyr_rslt);
		 $yr_indent=$neindntqryyr_rslt_rw['noindent'];
		 if($yr_indent>0){
				$yr_indent=$neindntqryyr_rslt_rw['noindent'];
		}else{
				$yr_indent=0;
		 }
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqryyr="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='2' and approve_by='".$user_id."'";
		$apprindntqryyr_rslt=inventory_query($apprindntqryyr);
		$apprindntqryyr_rslt_rw=inventory_fetch_assoc($apprindntqryyr_rslt);
		$yr_apprindntqry=$apprindntqryyr_rslt_rw['appindent'];
		if($yr_apprindntqry>0){
			$yr_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		}else{
			$yr_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqryyr="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1' and crtdby='".$user_id."'";
		$receiveitemqryyr_rslt=inventory_query($receiveitemqryyr);
		$receiveitemqryyr_rslt_rw=inventory_fetch_assoc($receiveitemqryyr_rslt);
		$yr_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		if($yr_receiveitemqry>0){
			$yr_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		}else{
			$yr_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalyr_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='2' and approve_by='".$user_id."'";
		$totoalyr_qry_rslt=inventory_query($totoalyr_qry);
		$totoalyr_qry_rslt_rw=inventory_fetch_assoc($totoalyr_qry_rslt);
		$yrtotoal_qry_rslt_no=$totoalyr_qry_rslt_rw['totalv'];
		if($yrtotoal_qry_rslt_no>0){
			$yrtotoal_qry_rslt_no=$totoalyr_qry_rslt_rw['totalv'];
		}else{
			$yrtotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalyr_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1' and crtdby='".$user_id."'";
		$totalyr_receive_rslt=inventory_query($totalyr_receive_qry);
		$totalyr_receive_rw=inventory_fetch_assoc($totalyr_receive_rslt);
		$totalyr_receive_no=$totalyr_receive_rw['total'];
		if($totalyr_receive_no>0){
			$totalyr_receive_no=$totalyr_receive_rw['total'];
		}else{
			$totalyr_receive_no=0;
		}
		
		
		
		 //All time   data    
	
		/*--------------- get week no from particular date -----------------*/
		// $first_day_year = date('Y-01-01'); 
		// $last_day_year = date('Y-12-31');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_all="select count(*) as noindent from fld_order_new  where  status='1' and approve_by='".$user_id."'";
		 $neindntqryall_rslt=inventory_query($neindntqry_all);
		 $neindntqryall_rslt_rw=inventory_fetch_assoc($neindntqryall_rslt);
		 $all_indent=$neindntqryall_rslt_rw['noindent'];
		 if($all_indent>0){
				$all_indent=$neindntqryall_rslt_rw['noindent'];
		}else{
				$all_indent=0;
		 }
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqryall="select count(*) as appindent from fld_order_new where  status='2' and approve_by='".$user_id."'";
		$apprindntqryall_rslt=inventory_query($apprindntqryall);
		$apprindntqryall_rslt_rw=inventory_fetch_assoc($apprindntqryall_rslt);
		$all_apprindntqry=$apprindntqryall_rslt_rw['appindent'];
		if($all_apprindntqry>0){
			$all_apprindntqry=$apprindntqryall_rslt_rw['appindent'];
		}else{
			$all_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqryall="select count(*) as recepo from tbl_receive_entry where status='1' and crtdby='".$user_id."'";
		$receiveitemqryall_rslt=inventory_query($receiveitemqryall);
		$receiveitemqryall_rslt_rw=inventory_fetch_assoc($receiveitemqryall_rslt);
		$all_receiveitemqry=$receiveitemqryall_rslt_rw['recepo'];
		if($all_receiveitemqry>0){
			$all_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		}else{
			$all_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalall_qry="select sum(fld_total_amount) as totalv from fld_order_new where  status='2'  and approve_by='".$user_id."'";
		 $totoalall_qry_rslt=inventory_query($totoalall_qry);
		 $totoalall_qry_rslt_rw=inventory_fetch_assoc($totoalall_qry_rslt);
		 $alltotoal_qry_rslt_no=$totoalall_qry_rslt_rw['totalv'];
		 if($alltotoal_qry_rslt_no>0){
			$alltotoal_qry_rslt_no=$totoalall_qry_rslt_rw['totalv'];
		 }else{
			$alltotoal_qry_rslt_no=0;
		 }
		
		
		/*---------- Receive order value ----------*/
		$totalall_receive_qry="select sum(total) as total from tbl_receive_entry where  status='1' and crtdby='".$user_id."'";
		$totalall_receive_rslt=inventory_query($totalall_receive_qry);
		$totalall_receive_rw=inventory_fetch_assoc($totalall_receive_rslt);
		$totalall_receive_no=$totalall_receive_rw['total'];
		if($totalall_receive_no>0){
			$totalall_receive_no=$totalall_receive_rw['total'];
		}else{
			$totalall_receive_no=0;
		}
		
		
		/*----------------------  GET ALL DEPARTMENTS ---------------------------------------*/
		 $hoddep="select * from tbl_hod,tbl_user where tbl_hod.fld_hod_id=tbl_user.venid and tbl_user.fld_ai_id='".$user_id."' ";
		 $hod_rslt=inventory_query($hoddep);
		 $hodrow=inventory_fetch_assoc($hod_rslt);
		 $depp=explode(",",$hodrow['dep_id']);
		// $qry_departmnt="select * from tbl_department where fld_is_active='1' ";
		//$qry_department_rslt=inventory_query($qry_departmnt);
		
	
	
}






if($user_type=="user"){
	
	//get today data
		/*---------- New Indent No ----------*/
		
	$neindntqry="select count(*) as noindent from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='1' and cretaed_by='".$user_id."'";
	$neindntqry_rslt=inventory_query($neindntqry);
	$neindntqry_rslt_rw=inventory_fetch_assoc($neindntqry_rslt);
	$today_indent=$neindntqry_rslt_rw['noindent'];
	if($today_indent>0){
		$today_indent=$neindntqry_rslt_rw['noindent'];
	}else{
		$today_indent=0;
	}
	
	/*---------- New Indent No App ----------*/
		
	$apprindntqry="select count(*) as appindent from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='2' and cretaed_by='".$user_id."'";
	$apprindntqry_rslt=inventory_query($apprindntqry);
	$apprindntqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
	$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
	if($today_apprindntqry>0){
		$today_apprindntqry=$apprindntqry_rslt_rw['appindent'];
	}else{
		$today_apprindntqry=0;
	}
	
	
	/*---------- Receive item ----------*/
		
	$receiveitemqry="select count(*) as recepo from tbl_receive_entry where receiveon='".trim(date('Y-m-d'))."' and status='1' and crtdby='".$user_id."'";
	$receiveitemqry_rslt=inventory_query($receiveitemqry);
	$receiveitemqry_rslt_rw=inventory_fetch_assoc($apprindntqry_rslt);
	$today_receiveitemqry=$receiveitemqry_rslt_rw['recepo'];
	if($today_receiveitemqry>0){
		$today_receiveitemqry=$receiveitemqry_rslt_rw['recepo'];
	}else{
		$today_receiveitemqry=0;
	}
	
	/*---------- order value ----------*/
		
	$totoal_qry="select sum(fld_total_amount) as totalv from fld_order_new where indent_create_on='".trim(date('Y-m-d'))."' and status='2' and cretaed_by='".$user_id."'";
	$totoal_qry_rslt=inventory_query($totoal_qry);
	$totoal_qry_rslt_rw=inventory_fetch_assoc($totoal_qry_rslt);
	$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
	if($totoal_qry_rslt_no>0){
		$totoal_qry_rslt_no=$totoal_qry_rslt_rw['totalv'];
	}else{
		$totoal_qry_rslt_no=0;
	}
	/*---------- Receive order value ----------*/
	$total_receive_qry="select sum(total) as total from tbl_receive_entry where receiveon='".trim(date('Y-m-d'))."' and status='1' and crtdby='".$user_id."' ";
	$total_receive_rslt=inventory_query($total_receive_qry);
	$total_receive_rw=inventory_fetch_assoc($total_receive_rslt);
	$total_receive_no=$total_receive_rw['total'];
	if($total_receive_no>0){
		$total_receive_no=$total_receive_rw['total'];
	}else{
		$total_receive_no=0;
	}
	
	
	//get week data    
	
		/*--------------- get week no from particular date -----------------*/
		$ddate = date('Y-m-d');
		$date = new DateTime($ddate);
		$week = $date->format("W");
	   // "Weeknummer: $week";
		$year=date('Y');
		
		$dateTime = new DateTime();
	    $dateTime->setISODate($year, $week);
         $startdate = $dateTime->format('Y-m-d');
		//echo "<br>";
	    $dateTime->modify('+6 days');
	    $enddate = $dateTime->format('Y-m-d');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_wk="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1' and cretaed_by='".$user_id."'";
		$neindntqrywk_rslt=inventory_query($neindntqry_wk);
		$neindntqrywk_rslt_rw=inventory_fetch_assoc($neindntqrywk_rslt);
		$wk_indent=$neindntqrywk_rslt_rw['noindent'];
		if($wk_indent>0){
			$wk_indent=$neindntqrywk_rslt_rw['noindent'];
		}else{
			$wk_indent=0;
		}
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqrywk="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='2' and cretaed_by='".$user_id."'";
		$apprindntqrywk_rslt=inventory_query($apprindntqrywk);
		$apprindntqrywk_rslt_rw=inventory_fetch_assoc($apprindntqrywk_rslt);
		$wk_apprindntqry=$apprindntqrywk_rslt_rw['appindent'];
		if($wk_apprindntqry>0){
			$wk_apprindntqry=$apprindntqrywk_rslt_rw['appindent'];
		}else{
			$wk_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqrywk="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1' and crtdby='".$user_id."'";
		$receiveitemqrywk_rslt=inventory_query($receiveitemqrywk);
		$receiveitemqrywk_rslt_rw=inventory_fetch_assoc($receiveitemqrywk_rslt);
		$wk_receiveitemqry=$receiveitemqrywk_rslt_rw['recepo'];
		if($wk_receiveitemqry>0){
			$wk_receiveitemqry=$receiveitemqrywk_rslt_rw['recepo'];
		}else{
			$wk_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalwk_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='2' and cretaed_by='".$user_id."'";
		$totoalwk_qry_rslt=inventory_query($totoalwk_qry);
		$totoalwk_qry_rslt_rw=inventory_fetch_assoc($totoalwk_qry_rslt);
		$wktotoal_qry_rslt_no=$totoalwk_qry_rslt_rw['totalv'];
		if($wktotoal_qry_rslt_no>0){
			$wktotoal_qry_rslt_no=$totoalwk_qry_rslt_rw['totalv'];
		}else{
			$wktotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalwk_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($startdate)."' AND '".trim($enddate)."') and status='1' and crtdby='".$user_id."'";
		$totalwk_receive_rslt=inventory_query($totalwk_receive_qry);
		$totalwk_receive_rw=inventory_fetch_assoc($totalwk_receive_rslt);
		$totalwk_receive_no=$totalwk_receive_rw['total'];
		if($totalwk_receive_no>0){
			$totalwk_receive_no=$totalwk_receive_rw['total'];
		}else{
			$totalwk_receive_no=0;
		}
	
	
	
	
	 	
		//get month data    
	
		/*--------------- get week no from particular date -----------------*/
		 $first_day = date('Y-m-01'); 
		 $last_day = date('Y-m-t');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_mnth="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1' and cretaed_by='".$user_id."'";
		$neindntqrymnth_rslt=inventory_query($neindntqry_mnth);
		$neindntqrymnth_rslt_rw=inventory_fetch_assoc($neindntqrymnth_rslt);
		$mnth_indent=$neindntqrymnth_rslt_rw['noindent'];
		if($mnth_indent>0){
			$mnth_indent=$neindntqrymnth_rslt_rw['noindent'];
		}else{
			$mnth_indent=0;
		}
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqrymnth="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='2' and cretaed_by='".$user_id."'";
		$apprindntqrymnth_rslt=inventory_query($apprindntqrymnth);
		$apprindntqrymnth_rslt_rw=inventory_fetch_assoc($apprindntqrymnth_rslt);
		$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		if($mnth_apprindntqry>0){
			$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		}else{
			$mnth_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqrymnth="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1' and crtdby='".$user_id."'";
		$receiveitemqrymnth_rslt=inventory_query($receiveitemqrymnth);
		$receiveitemqrymnth_rslt_rw=inventory_fetch_assoc($receiveitemqrymnth_rslt);
		$mnth_receiveitemqry=$receiveitemqrymnth_rslt_rw['recepo'];
		if($mnth_receiveitemqry>0){
			$mnth_receiveitemqry=$receiveitemqrymnth_rslt_rw['recepo'];
		}else{
			$mnth_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalmnth_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='2' and cretaed_by='".$user_id."'";
		$totoalmnh_qry_rslt=inventory_query($totoalmnth_qry);
		$totoalmnth_qry_rslt_rw=inventory_fetch_assoc($totoalmnh_qry_rslt);
		$mnthtotoal_qry_rslt_no=$totoalmnth_qry_rslt_rw['totalv'];
		if($mnthtotoal_qry_rslt_no>0){
			$mnthtotoal_qry_rslt_no=$totoalmnth_qry_rslt_rw['totalv'];
		}else{
			$mnthtotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalmnth_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='1' and crtdby='".$user_id."'";
		$totalmnth_receive_rslt=inventory_query($totalmnth_receive_qry);
		$totalmnth_receive_rw=inventory_fetch_assoc($totalmnth_receive_rslt);
		$totalmnth_receive_no=$totalmnth_receive_rw['total'];
		if($totalmnth_receive_no>0){
			$totalmnth_receive_no=$totalmnth_receive_rw['total'];
		}else{
			$totalmnth_receive_no=0;
		}
	
	
	 
	
	//get Year  data    
	
		/*--------------- get week no from particular date -----------------*/
		 $first_day_year = date('Y-01-01'); 
		 $last_day_year = date('Y-12-31');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_yr="select count(*) as noindent from fld_order_new  where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1' and cretaed_by='".$user_id."'";
		 $neindntqryyr_rslt=inventory_query($neindntqry_yr);
		 $neindntqryyr_rslt_rw=inventory_fetch_assoc($neindntqryyr_rslt);
		 $yr_indent=$neindntqryyr_rslt_rw['noindent'];
		 if($yr_indent>0){
				$yr_indent=$neindntqryyr_rslt_rw['noindent'];
		}else{
				$yr_indent=0;
		 }
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqryyr="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='2' and cretaed_by='".$user_id."'";
		$apprindntqryyr_rslt=inventory_query($apprindntqryyr);
		$apprindntqryyr_rslt_rw=inventory_fetch_assoc($apprindntqryyr_rslt);
		$yr_apprindntqry=$apprindntqryyr_rslt_rw['appindent'];
		if($yr_apprindntqry>0){
			$yr_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		}else{
			$yr_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqryyr="select count(*) as recepo from tbl_receive_entry where  (`receiveon` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1' and crtdby='".$user_id."'";
		$receiveitemqryyr_rslt=inventory_query($receiveitemqryyr);
		$receiveitemqryyr_rslt_rw=inventory_fetch_assoc($receiveitemqryyr_rslt);
		$yr_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		if($yr_receiveitemqry>0){
			$yr_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		}else{
			$yr_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalyr_qry="select sum(fld_total_amount) as totalv from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='2' and cretaed_by='".$user_id."'";
		$totoalyr_qry_rslt=inventory_query($totoalyr_qry);
		$totoalyr_qry_rslt_rw=inventory_fetch_assoc($totoalyr_qry_rslt);
		$yrtotoal_qry_rslt_no=$totoalyr_qry_rslt_rw['totalv'];
		if($yrtotoal_qry_rslt_no>0){
			$yrtotoal_qry_rslt_no=$totoalyr_qry_rslt_rw['totalv'];
		}else{
			$yrtotoal_qry_rslt_no=0;
		}
		
		
		/*---------- Receive order value ----------*/
		$totalyr_receive_qry="select sum(total) as total from tbl_receive_entry where (`receiveon` BETWEEN '".trim($first_day_year)."' AND '".trim($last_day_year)."') and status='1' and crtdby='".$user_id."'";
		$totalyr_receive_rslt=inventory_query($totalyr_receive_qry);
		$totalyr_receive_rw=inventory_fetch_assoc($totalyr_receive_rslt);
		$totalyr_receive_no=$totalyr_receive_rw['total'];
		if($totalyr_receive_no>0){
			$totalyr_receive_no=$totalyr_receive_rw['total'];
		}else{
			$totalyr_receive_no=0;
		}
		
		
		
		 //All time   data    
	
		/*--------------- get week no from particular date -----------------*/
		// $first_day_year = date('Y-01-01'); 
		// $last_day_year = date('Y-12-31');
		
		/*---------- New Indent No ----------*/
		
		 $neindntqry_all="select count(*) as noindent from fld_order_new  where  status='1' and cretaed_by='".$user_id."'";
		 $neindntqryall_rslt=inventory_query($neindntqry_all);
		 $neindntqryall_rslt_rw=inventory_fetch_assoc($neindntqryall_rslt);
		 $all_indent=$neindntqryall_rslt_rw['noindent'];
		 if($all_indent>0){
				$all_indent=$neindntqryall_rslt_rw['noindent'];
		}else{
				$all_indent=0;
		 }
		
		
		/*---------- New Indent No App ----------*/
		
		$apprindntqryall="select count(*) as appindent from fld_order_new where  status='2' and cretaed_by='".$user_id."'";
		$apprindntqryall_rslt=inventory_query($apprindntqryall);
		$apprindntqryall_rslt_rw=inventory_fetch_assoc($apprindntqryall_rslt);
		$all_apprindntqry=$apprindntqryall_rslt_rw['appindent'];
		if($all_apprindntqry>0){
			$all_apprindntqry=$apprindntqryall_rslt_rw['appindent'];
		}else{
			$all_apprindntqry=0;
		}
		
		/*---------- Receive item ----------*/
		
		 $receiveitemqryall="select count(*) as recepo from tbl_receive_entry where status='1' and crtdby='".$user_id."'";
		$receiveitemqryall_rslt=inventory_query($receiveitemqryall);
		$receiveitemqryall_rslt_rw=inventory_fetch_assoc($receiveitemqryall_rslt);
		$all_receiveitemqry=$receiveitemqryall_rslt_rw['recepo'];
		if($all_receiveitemqry>0){
			$all_receiveitemqry=$receiveitemqryyr_rslt_rw['recepo'];
		}else{
			$all_receiveitemqry=0;
		}
		
		/*---------- order value ----------*/
		
		 $totoalall_qry="select sum(fld_total_amount) as totalv from fld_order_new where  status='2'  and cretaed_by='".$user_id."'";
		 $totoalall_qry_rslt=inventory_query($totoalall_qry);
		 $totoalall_qry_rslt_rw=inventory_fetch_assoc($totoalall_qry_rslt);
		 $alltotoal_qry_rslt_no=$totoalall_qry_rslt_rw['totalv'];
		 if($alltotoal_qry_rslt_no>0){
			$alltotoal_qry_rslt_no=$totoalall_qry_rslt_rw['totalv'];
		 }else{
			$alltotoal_qry_rslt_no=0;
		 }
		
		
		/*---------- Receive order value ----------*/
		$totalall_receive_qry="select sum(total) as total from tbl_receive_entry where  status='1' and crtdby='".$user_id."'";
		$totalall_receive_rslt=inventory_query($totalall_receive_qry);
		$totalall_receive_rw=inventory_fetch_assoc($totalall_receive_rslt);
		$totalall_receive_no=$totalall_receive_rw['total'];
		if($totalall_receive_no>0){
			$totalall_receive_no=$totalall_receive_rw['total'];
		}else{
			$totalall_receive_no=0;
		}
		
		
	  /*----------------------  GET ALL DEPARTMENTS ---------------------------------------*/
	   $qry_departmnt="select * from tbl_user where fld_is_active='1' and fld_ai_id='".$user_id."' ";
	  $qry_department_rslt=inventory_query($qry_departmnt);
	  $qry_department_row=inventory_fetch_assoc($qry_department_rslt);
	  $depp=$qry_department_row['deepuser_id'];
	
	
	
}

if($user_type=="user" ||  $user_type=="admin" || $user_type=="store_keeper" || $user_type=="hod" ){
	   
	   
	   $darrt=array();
	   for($ik=1;$ik<13;$ik++){
	    
		 $first_day = date("Y-$ik-01"); 
		 $last_day = date("Y-$ik-t");
		
	
	    $apprindntqrymnth="select count(*) as appindent from fld_order_new where (`indent_create_on` BETWEEN '".trim($first_day)."' AND '".trim($last_day)."') and status='2'";
		$apprindntqrymnth_rslt=inventory_query($apprindntqrymnth);
		$apprindntqrymnth_rslt_rw=inventory_fetch_assoc($apprindntqrymnth_rslt);
		$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		if($mnth_apprindntqry>0){
			$mnth_apprindntqry=$apprindntqrymnth_rslt_rw['appindent'];
		}else{
			$mnth_apprindntqry=0;
		}
			
			array_push($darrt,$mnth_apprindntqry);
		
		}
	
	//print_r($darrt);
}



?>


<div class="row">
    <div class="col-lg-12">
        <div class="tabs">
            <ul class="nav nav-tabs">
                <li class="nav-item active">
                    <a class="nav-link" href="#popular" data-toggle="tab"> Today</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#recent" data-toggle="tab">This Week</a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link" href="#this_month" data-toggle="tab">This Month</a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link" href="#this_year" data-toggle="tab">This Year</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#all_time" data-toggle="tab">All Time</a>
                </li>
            </ul>
            <div class="tab-content">
                <div id="popular" class="tab-pane active">
					<div class="row">
    					<div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_1">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $today_indent; ?></div>
                                    <hr class="hr_dashboard color_white">
                                    <p class="text-2 mb-0 color_white">New Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_2">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $today_apprindntqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Approved Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_3">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $today_receiveitemqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Receive Item</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_4">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($totoal_qry_rslt_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Indent Value</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_5">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($total_receive_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Receive Value</p>
                                </div>
                            </section>
                        </div>
                       
                    </div>
                </div>
                <div id="recent" class="tab-pane">
                	
                	<div class="row">
    					<div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_1">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $wk_indent; ?></div>
                                    <hr class="hr_dashboard color_white">
                                    <p class="text-2 mb-0 color_white">New Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_2">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $wk_apprindntqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Approved Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_3">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $wk_receiveitemqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Receive Item</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_4">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($wktotoal_qry_rslt_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Indent Value</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_5">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($totalwk_receive_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Receive Value</p>
                                </div>
                            </section>
                        </div>
                       
                    </div>
                	
                   
                </div>
                <div id="this_month" class="tab-pane">
                	
                	<div class="row">
    					<div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_1">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $mnth_indent; ?></div>
                                    <hr class="hr_dashboard color_white">
                                    <p class="text-2 mb-0 color_white">New Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_2">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $mnth_apprindntqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Approved Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_3">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $mnth_receiveitemqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Receive Item</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_4">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($mnthtotoal_qry_rslt_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Indent Value</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_5">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($totalmnth_receive_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Receive Value</p>
                                </div>
                            </section>
                        </div>
                       
                    </div>
                   
                </div>
                <div id="this_year" class="tab-pane">
                	
                	<div class="row">
    					<div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_1">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $yr_indent; ?></div>
                                    <hr class="hr_dashboard color_white">
                                    <p class="text-2 mb-0 color_white">New Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_2">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $yr_apprindntqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Approved Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_3">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $yr_receiveitemqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Receive Item</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_4">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($yrtotoal_qry_rslt_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Indent Value</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_5">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($totalyr_receive_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Receive Value</p>
                                </div>
                            </section>
                        </div>
                       
                    </div>
                	
                   
                </div>
                <div id="all_time" class="tab-pane">
                	
                	<div class="row">
    					<div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_1">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $all_indent; ?></div>
                                    <hr class="hr_dashboard color_white">
                                    <p class="text-2 mb-0 color_white">New Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_2">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $all_apprindntqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Approved Indent</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_3">
                                    <div class="h5 font-weight-bold mb-0"><?php echo $all_receiveitemqry;  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 mb-0 color_white">Receive Item</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_4">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($alltotoal_qry_rslt_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Indent Value</p>
                                </div>
                            </section>
                        </div>
                        <div class="col-lg-2">
                        	<section class="card">
                                <div class="card-body cart_5">
                                    <div class="h5 font-weight-bold mb-0"><i class="fa fa-inr"></i><?php  echo number_format((float)($totalall_receive_no), 2, '.', '');  ?></div>
                                    <hr class="hr_dashboard">
                                    <p class="text-2 text-muted mb-0 color_white">Receive Value</p>
                                </div>
                            </section>
                        </div>
                       
                    </div>
                	
                   
                </div>
            </div>
        </div>
    </div>
     <div class="col-lg-6">
        <section class="card">
            <div class="card-body">

                <!-- Flot: Bars -->
                <div class="chart chart-md" id="flotBars" style="height:260px"></div>
                <script type="text/javascript">

                    var flotBarsData = [
                        ["Jan", <?php echo $darrt[0]; ?>],
                        ["Feb", <?php echo $darrt[1]; ?>],
                        ["Mar", <?php echo $darrt[2]; ?>],
                        ["Apr", <?php echo $darrt[3]; ?>],
                        ["May", <?php echo $darrt[4]; ?>],
                        ["Jun", <?php echo $darrt[5]; ?>],
                        ["Jul", <?php echo $darrt[6]; ?>],
                        ["Aug", <?php echo $darrt[7]; ?>],
                        ["Sep", <?php echo $darrt[8]; ?>],
                        ["Oct", <?php echo $darrt[9]; ?>],
                        ["Nov", <?php echo $darrt[10]; ?>],
                        ["Dec", <?php echo $darrt[11]; ?>]
                    ];

                    // See: js/examples/examples.charts.js for more settings.

                </script>

            </div>
        </section>
    </div>
     <div class="col-lg-6">
        <section class="card">
            <div class="card-body">
           		<div class="row">
            	  <div class="col-lg-12">
            	  	   <select data-plugin-selectTwo class="form-control populate" id="depmnt">
            	  	   	
            	  	   	     <?php  if($user_type=="hod"){ ?>
            	  	   	     	 <?php  if(count($depp)>0){ ?>
            	  	   	     	 	<option value="">--Select Department--</option>
            	  	   	     	 	<?php    for($ik=0;$ik<count($depp);$ik++){  ?>
            	  	   	     	 		<?php   
            	  	   	     	 		
            	  	   	     	 			$qry_departmnt="select * from tbl_department where fld_is_active='1' and fld_ai_id='".trim($depp[$ik])."' ";
											$qry_department_rslt=inventory_query($qry_departmnt);
											$qry_department_rw=inventory_fetch_assoc($qry_department_rslt);
											//while($qry_department_rw=inventory_fetch_assoc($qry_department_rslt)){  ?>
            	  	   	     	 
            	  	   	     	          <option value="<?php echo $qry_department_rw['fld_ai_id'];  ?>"><?php echo $qry_department_rw['fld_department'];  ?></option>
								
								
							<?php   } } }
							 
							 if($user_type=="admin" || $user_type=="store_keeper"){   ?>
                 			<?php  if(inventory_num_rows($qry_department_rslt)>0){   ?>
                 				    <option value="">--Select Department--</option>
                 				<?php   while($rowst=inventory_fetch_assoc($qry_department_rslt)){   ?>
                                	<option value="<?php echo $rowst['fld_ai_id'];  ?>"><?php echo $rowst['fld_department'];  ?></option>
                            <?php  } } } ?>
                            
                            <?php  if($user_type=="user"){   ?>
                 			<?php  if(count($depp)>0){ ?>
            	  	   	     	 	<option value="">--Select Department--</option>
            	  	   	     	 	<?php    for($ik=0;$ik<count($depp);$ik++){  ?>
            	  	   	     	 		<?php   
            	  	   	     	 		
            	  	   	     	 			$qry_departmnt="select * from tbl_department where fld_is_active='1' and fld_ai_id='".trim($depp[$ik])."' ";
											$qry_department_rslt=inventory_query($qry_departmnt);
											$qry_department_rw=inventory_fetch_assoc($qry_department_rslt);
											//while($qry_department_rw=inventory_fetch_assoc($qry_department_rslt)){  ?>
            	  	   	     	 
            	  	   	     	          <option value="<?php echo $qry_department_rw['fld_ai_id'];  ?>"><?php echo $qry_department_rw['fld_department'];  ?></option>
								
								
							<?php   } } } ?>
                            
                       	</select>
                  </div>
                </div>
                <br>
                <div class="row">
                	<div class="col-lg-12">
                		<?php
                            		  $select_semester_query = "SELECT * FROM  tbl_semester ";
							        $select_semester_query_result = inventory_query($select_semester_query); 
									$row_data11 = inventory_fetch_assoc($select_semester_query_result);
                            	//echo $semester;
                        ?>
            	  	   <select data-plugin-selectTwo class="form-control populate" id="semester">
            	  	   	<option value="">--select--</option>
            	  	   	<?php if(isset($row_data11) && !empty($row_data11)){
                               		while($row_data2 = inventory_fetch_assoc($select_semester_query_result)){
                               	?>	
									<option value="<?php echo $row_data2['fld_ai_id']; ?>" ><?php echo $row_data2['fld_category'] ; ?></option>
									
                        <?php  }	} ?>
            	  	   	</select>
            	  	  </div>
                </div>
                <br>
                <div class="row">
                	<div class="col-lg-12">
                		<?php
                            		  $select_section_query = "SELECT * FROM  tbl_section ";
							        $select_section_query_result = inventory_query($select_section_query); 
									
                            	    //print_r($row_data1section);
                            	    //echo $section;
                         ?>
            	  	   <select data-plugin-selectTwo class="form-control populate" id="section" onchange="getdashboard_data()">
            	  	   	<option value="">--select--</option>
            	  	   	<?php 
                               		while($row_dat = inventory_fetch_assoc($select_section_query_result)){
                               	?>	
									<option value="<?php echo $row_dat['fld_ai_id']; ?>" ><?php echo $row_dat['fld_category'] ; ?></option>
									
                        <?php  	} ?>
            	  	   	</select>
            	  	  </div>
                	
                </div>
                <div class="row" id="department_wise_data">
            	  <div class="col-lg-6 mt-2">
                        <section class="card">
                            <div class="card-body cart_1">
                                <div class="h5 font-weight-bold mb-0" id="noindent">0</div>
                                <hr class="hr_dashboard color_white">
                                <p class="text-2 mb-0 color_white">No of Indent</p>
                            </div>
                        </section>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <section class="card">
                            <div class="card-body cart_2">
                                <div class="h5 font-weight-bold mb-0" id="appindent">0</div>
                                <hr class="hr_dashboard">
                                <p class="text-2 mb-0 color_white">Approve Indent</p>
                            </div>
                        </section>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <section class="card">
                            <div class="card-body cart_4">
                                <div class="h5 font-weight-bold mb-0" id="indentval"><i class="fa fa-inr"></i></div>
                                <hr class="hr_dashboard">
                                <p class="text-2 text-muted mb-0 color_white">Indent Value</p>
                            </div>
                        </section>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <section class="card">
                            <div class="card-body cart_5">
                                <div class="h5 font-weight-bold mb-0" id="receiveval"><i class="fa fa-inr"></i></div>
                                <hr class="hr_dashboard">
                                <p class="text-2 text-muted mb-0 color_white">Receive Value</p>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<script>
    /* function get_semester(){
     	
     		var depmnt=$("#depmnt").val();
			var semester=$("#semester").val();
			var section=$("#section").val();
			$.ajax({			
 			type :"POST",
  			url : "<?php //inventory_display(ROOT_PATH)?>///jquery_ajax/getsemester.php",
  			data :{'depmnt':depmnt,'semester':semester,'section':section},
  			success : function(data){
  				//console.log(data);
  				      var json=JSON.parse(data);
	  				  var noindent=json.noindent;
	  				  var appindent=json.appindent;
	  				  var indentval=json.indentval;
	  				  var receiveval=json.receiveval;
	  				  $("#noindent").text(noindent);
	  				  $("#appindent").text(appindent);
	  				  $("#indentval").text(indentval);
	  				  $("#receiveval").text(receiveval);
	  				   
  				 
  				}
  			
           }); 
     	
     }
     */
	 function getdashboard_data(){
			
			var depmnt=$("#depmnt").val();
			var semester=$("#semester").val();
			var section=$("#section").val();
			$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getdashboardinfo.php",
  			data :{'depmnt':depmnt,'semester':semester,'section':section},
  			success : function(data){
  				console.log(data);
  				      var json=JSON.parse(data);
	  				  var noindent=json.noindent;
	  				  var appindent=json.appindent;
	  				  var indentval=json.indentval;
	  				  var receiveval=json.receiveval;
	  				  $("#noindent").text(noindent);
	  				  $("#appindent").text(appindent);
	  				  $("#indentval").text(indentval);
	  				  $("#receiveval").text(receiveval);
	  				   
  				 
  				}
  			
           }); 
			
		}
		

	
	
</script>