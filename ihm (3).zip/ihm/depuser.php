<?php include('action/deepuser_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php if($case == "list"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		<?php
        			if( $user_w==0 ){ }else{ ?>
						<a class="btn custom_border" href="<?php inventory_display(ROOT_PATH)?>/addduser"><i class="fa fa-plus" aria-hidden="true"></i> Add Department user</a>
						
				<?php 	} ?>
				
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> User List</h2>
        </header>
        <div class="card-body">
        	 <table class="table table-bordered table-striped mb-0" id="datatable_with_search">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>User Type</th>
                        <th>Department</th>
                        <th>Status</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "edit"){ ?>
	
	<?php
		//$user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
        $sql_cat="select * from module_permission where user_id='".$user_ai_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		//print_r($rst_rw);
		if(isset($rst_rw) && !empty($rst_rw)){
		
		//////////////////////////////////  LEFT MENU CATEGORY    /////////////////////////////////////
					$category_r=$rst_rw['category_r'];
					 $category_w=$rst_rw['category_w'];
					$category_d=$rst_rw['category_d'];
					$tax_r=$rst_rw['tax_r'];
					$tax_w=$rst_rw['tax_w'];
					$tax_d=$rst_rw['tax_d'];
					$subcat_r=$rst_rw['subcat_r'];
					$subcat_w=$rst_rw['subcat_w'];
					$subcat_d=$rst_rw['subcat_d'];
					$deep_r=$rst_rw['deep_r'];
					$deep_w=$rst_rw['deep_w'];
					$deep_d=$rst_rw['deep_d'];
					$item_r=$rst_rw['item_r'];
					$item_w=$rst_rw['item_w'];
					$item_d=$rst_rw['item_d'];
					$indent_r=$rst_rw['indent_r'];
					$indent_w=$rst_rw['indent_w'];
					$indent_d=$rst_rw['indent_d'];
					$po_r=$rst_rw['po_r'];
					$po_w=$rst_rw['po_w'];
					$po_d=$rst_rw['po_d'];
					$cashp_r=$rst_rw['cashp_r'];
					$cashp_w=$rst_rw['cashp_w'];
					$cashp_d=$rst_rw['cashp_d'];
					$receiver_r=$rst_rw['receiver_r'];
					$receiver_w=$rst_rw['receiver_w'];
					$receiver_d=$rst_rw['receiver_d'];
					$vendorr_r=$rst_rw['vendorr_r'];
					$vendorr_w=$rst_rw['vendorr_w'];
					$vendorr_d=$rst_rw['vendorr_d'];
					$por_r=$rst_rw['por_r'];
					$por_w=$rst_rw['por_w'];
					$por_d=$rst_rw['por_d'];
					$indentr_r=$rst_rw['indentr_r'];
					$indentr_w=$rst_rw['indentr_w'];
					$indentr_d=$rst_rw['indentr_d'];
					$receiver_r=$rst_rw['receiver_r'];
					$receiver_w=$rst_rw['receiver_w'];
					$receiver_d=$rst_rw['receiver_d'];
					
					$user_r=$rst_rw['user_r'];
					$user_w=$rst_rw['user_w'];
					$user_d=$rst_rw['user_d'];
					$hod_r=$rst_rw['hod_r'];
					$hod_w=$rst_rw['hod_w'];
					$hod_d=$rst_rw['hod_d'];
					$storek_r=$rst_rw['storek_r'];
					$storek_w=$rst_rw['storek_w'];
					$storek_d=$rst_rw['storek_d'];
					
					$cashprecive_r=$rst_rw['cashprecive_r'];
					$cashprecive_w=$rst_rw['cashprecive_w'];
					$cashprecive_d=$rst_rw['cashprecive_d'];
					
					
	
	
	}
	
	?>
	
	
	
	
	<section class="card">
	    <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit User</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="edit_user_form" action = "<?php inventory_display(ROOT_PATH)?>/updateduser" enctype="multipart/form-data">
            	<div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Name</label>
                            <div class="col-lg-8">
                                <input type="text" class="form-control" id="name" name = "name" value="<?php inventory_display($name)?>" >
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="user_type">select Department</label>
                            <div class="col-lg-8">
                                <input type="hidden" class="form-control" id="user_type" name = "user_type" value="<?php inventory_display($user_type)?>" readonly>
                                 <?php
                               $select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='1'";
    							$select_department_query_result = inventory_query($select_department_query); 
    							if(inventory_num_rows($select_department_query_result)>0){
    							   
    								?>
    								<select class="form-control" id="hod_dep" name = "user_dep" required=""  id="ms_example0">
    									
    									
                            	       <option value="">--select--</option>
    								<?php
    								while($row_data2 = inventory_fetch_assoc($select_department_query_result)){
    									?>
    									<option value="<?php echo $row_data2['fld_ai_id']; ?>" <?php if($row_data2['fld_ai_id']==$deepid){ echo "selected"; } ?>><?php echo $row_data2['fld_department'];  ?></option>
    									<?php
    								}
								?>
								</select>
    							<?php }
    							?>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="form-group row">
                   
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="mobile_number">Mobile Number</label>
                            <div class="col-lg-8">
                                <input type="text" class="form-control" id="mobile_number" name = "mobile_number" value="<?php inventory_display($mobile_number)?>" readonly>
                            </div>
                        </div>
                    </div>
                     <div class="col-md-6">
                     	<div class="form-group row">
                            <label class="col-lg-3 control-label pt-2 text-lg-right" for="service_name">Isactive<span class="required">*</span></label>
                            <div class="col-lg-6">
                                <div class="switch switch-sm switch-primary">
                                    <input type="checkbox" name="is_active" data-plugin-ios-switch <?php if($is_active == '1'){?>  checked="checked" <?php }?> />
                                </div>
                            </div>
                        </div>
                    </div> 
                    
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="address">Username</label>
                            <div class="col-lg-8">
                                <input type="text" required="" class="form-control" id="username" name = "username"  value="<?php inventory_display($username)?>" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="address">Password</label>
                            <div class="col-lg-8">
                                <input type="password" required="" class="form-control" id="password" name = "password" value="<?php inventory_display($paewd)?>" >
                            </div>
                        </div>
                    </div>
                 </div>
                 <div class="form-group row">
                 	<div class="col-md-12">
	                 	<header class="card-header">
				            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Account Permission</h2>
				        </header>
			        </div>
                 </div>
                 <div class="form-group row">
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Category</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "category_r"  <?php if(isset($category_r) && !empty($category_r)){ if($category_r==1){echo "checked"; ?> value="1" <?php } }else{ ?> value="0" <?php }  ?> >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "category_w" <?php if(isset($category_w) && !empty($category_w)){ if($category_w==1){echo "checked"; ?> value="1" <?php } }else{ ?> value="0" <?php }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "category_d" value="1" <?php if(isset($category_d) && !empty($category_d)){ if($category_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Sub-Category</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "subcat_r" value="1"  <?php if(isset($subcat_r) && !empty($subcat_r)){ if($subcat_r==1){echo "checked";} }  ?> >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "subcat_w" value="1" <?php if(isset($subcat_w) && !empty($subcat_w)){ if($subcat_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "subcat_d" value="1" <?php if(isset($subcat_d) && !empty($subcat_d)){ if($subcat_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Department</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "deep_r" value="1" <?php if(isset($deep_r) && !empty($deep_r)){ if($deep_r==1){echo "checked";} }  ?> >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "deep_w" value="1" <?php if(isset($deep_w) && !empty($deep_w)){ if($deep_w==1){echo "checked";} }  ?>  >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "deep_d" value="1" <?php if(isset($deep_d) && !empty($deep_d)){ if($deep_w==1){echo "checked";} }  ?>  >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Tax</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "tax_r" value="1" <?php if(isset($tax_r) && !empty($tax_r)){ if($tax_r==1){echo "checked";} }  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "tax_w" value="1" <?php if(isset($tax_w) && !empty($tax_w)){ if($tax_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "tax_d" value="1" <?php if(isset($tax_d) && !empty($tax_d)){ if($tax_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                 </div>
                 
                 <div class="form-group row">
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Items</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "item_r" value="1" <?php if(isset($item_r) && !empty($item_r)){ if($item_r==1){echo "checked";} }  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "item_w" value="1" <?php if(isset($item_w) && !empty($item_w)){ if($item_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "item_d" value="1" <?php if(isset($item_d) && !empty($item_d)){ if($item_d==1){echo "checked";} }  ?>  >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Indent</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "indent_r" value="1" <?php if(isset($indent_r) && !empty($indent_r)){ if($indent_r==1){echo "checked";} }  ?> >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "indent_w" value="1" <?php if(isset($indent_w) && !empty($indent_w)){ if($indent_w==1){echo "checked";} }  ?>  >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "indent_d" value="1" <?php if(isset($indent_d) && !empty($indent_d)){ if($indent_d==1){echo "checked";} }  ?>  >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">PO</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "po_r" value="1" <?php if(isset($po_r) && !empty($po_r)){ if($po_r==1){echo "checked";} }  ?> >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "po_w" value="1" <?php if(isset($po_w) && !empty($po_w)){ if($po_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "po_d" value="1" <?php if(isset($po_d) && !empty($po_d)){ if($po_d==1){echo "checked";} }  ?>>&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Cash Purchase</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "cashp_r" value="1" <?php if(isset($cashp_r) && !empty($cashp_r)){ if($cashp_r==1){echo "checked";} }  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "cashp_w" value="1" <?php if(isset($cashp_w) && !empty($cashp_w)){ if($cashp_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "cashp_d" value="1" <?php if(isset($cashp_d) && !empty($cashp_d)){ if($cashp_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                 </div>
                 <div class="form-group row">
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">PO Receive</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "por_r" value="1" <?php if(isset($por_r) && !empty($por_r)){ if($por_r==1){echo "checked";} }  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "por_w" value="1" <?php if(isset($por_w) && !empty($por_w)){ if($por_w==1){echo "checked";} }  ?>>&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "por_d" value="1" <?php if(isset($por_d) && !empty($por_d)){ if($receiver_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Indent Report</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "indent_r" value="1"  <?php if(isset($indentr_r) && !empty($indentr_r)){ if($indentr_r==1){echo "checked";} }  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "indent_w" value="1" <?php if(isset($indentr_w) && !empty($indentr_w)){ if($indentr_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "indent_d" value="1" <?php if(isset($indentr_d) && !empty($indentr_d)){ if($indentr_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Vendors Report</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "vendorr_r" value="1" <?php if(isset($vendorr_r) && !empty($vendorr_r)){ if($vendorr_r==1){echo "checked";} }  ?>   >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "vendorr_w" value="1" <?php if(isset($vendorr_w) && !empty($vendorr_w)){ if($vendorr_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "vendorr_d" value="1" <?php if(isset($vendorr_d) && !empty($vendorr_d)){ if($vendorr_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">PO Report</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "por_r" value="1" <?php if(isset($por_r) && !empty($por_r)){ if($por_r==1){echo "checked";} }  ?>   >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "por_w" value="1" <?php if(isset($por_w) && !empty($por_w)){ if($por_w==1){echo "checked";} }  ?>  >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "por_d" value="1" <?php if(isset($por_d) && !empty($por_d)){ if($por_d==1){echo "checked";} }  ?>  >&nbsp;D
                            </div>
                        </div>
                    </div>
                 </div>
                 
                 <div class="form-group row">
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Recivable Report</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "receiver_r" value="1" <?php if(isset($receiver_r) && !empty($receiver_r)){ if($receiver_r==1){echo "checked";} }  ?>   >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "receiver_w" value="1" <?php if(isset($receiver_w) && !empty($receiver_w)){ if($receiver_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "receiver_d" value="1"  <?php if(isset($receiver_d) && !empty($receiver_d)){ if($receiver_d==1){echo "checked";} }  ?>>&nbsp;D
                            </div>
                        </div>
                    </div>
                   <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">User</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "user_r" value="1" <?php if(isset($user_r) && !empty($user_r)){ if($user_r==1){echo "checked";} }  ?>   >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "user_w" value="1"  <?php if(isset($user_w) && !empty($user_w)){ if($user_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "user_d" value="1" <?php if(isset($user_d) && !empty($user_d)){ if($user_d==1){echo "checked";} }  ?>  >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">HOD</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "hod_r" value="1" <?php if(isset($hod_r) && !empty($hod_r)){ if($hod_r==1){echo "checked";}}  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "hod_w" value="1" <?php if(isset($hod_w) && !empty($hod_w)){ if($hod_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "hod_d" value="1" <?php if(isset($hod_d) && !empty($hod_d)){ if($hod_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Store Keeper</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "storek_r" value="1" <?php if(isset($storek_r) && !empty($storek_r)){ if($storek_r==1){echo "checked";} }  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "storek_w" value="1" <?php if(isset($storek_w) && !empty($storek_w)){ if($storek_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "storek_d" value="1" <?php if(isset($storek_d) && !empty($storek_d)){ if($storek_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                 </div>
                 
                 <div class="form-group row">
                    <div class="col-md-3">
                        <div class="form-group row">
                            <label class="col-lg-6 control-label text-lg-right pt-2" for="address">Cash Purchase Receive</label>
                            <div class="col-lg-6">
                                <input type="checkbox"  id="username" name = "cashprecive_r" value="1" <?php if(isset($cashprecive_r) && !empty($cashprecive_r)){ if($cashprecive_r==1){echo "checked";} }  ?>  >&nbsp;R<br>
                                <input type="checkbox"  id="username" name = "cashprecive_w" value="1" <?php if(isset($cashprecive_w) && !empty($cashprecive_w)){ if($cashprecive_w==1){echo "checked";} }  ?> >&nbsp;W<br>
                                <input type="checkbox"  id="username" name = "cashprecive_d" value="1" <?php if(isset($cashprecive_d) && !empty($cashprecive_d)){ if($cashprecive_d==1){echo "checked";} }  ?> >&nbsp;D
                            </div>
                        </div>
                    </div>
                   
                    
                    
                 </div>
                 
                
                    
                    
                </div>
                 
                 <input type="hidden" name = "user_ai_id" value="<?php inventory_display(track64_encode($user_ai_id))?>"/>
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="edit_user">Update User</button>
					</div>
				</div>
            </form>
        </div>
     </section> 
<?php } ?>
<?php if($case == "add"){ ?>
	<section class="card">
	    <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Add Department User</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="edit_user_form" action = "<?php inventory_display(ROOT_PATH)?>/addduser" enctype="multipart/form-data">
            	<div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Name</label>
                            <div class="col-lg-8">
                                <input type="text" required="" class="form-control" id="name" name = "name" value="<?php inventory_display($name)?>" >
                                <input type="hidden" name="user_type" id="user_type" value="user" />
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="user_type">Select Department</label>
                            <div class="col-lg-8">
                                <?php
                               $select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='1'";
    							$select_department_query_result = inventory_query($select_department_query); 
    							if(inventory_num_rows($select_department_query_result)>0){
    							   
    								?>
    								<select class="form-control" id="hod_dep" name = "user_dep" required=""  id="ms_example0">
    									
    									
                            	       <option value="">--select--</option>
    								<?php
    								while($row_data2 = inventory_fetch_assoc($select_department_query_result)){
    									?>
    									<option value="<?php echo $row_data2['fld_ai_id']; ?>"><?php echo $row_data2['fld_department'];  ?></option>
    									<?php
    								}
								?>
								</select>
    							<?php }
    							?>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="form-group row">
                    
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="mobile_number">Mobile Number</label>
                            <div class="col-lg-8">
                                <input type="text" required="" class="form-control" id="mobile_number" name = "mobile_number" value="<?php inventory_display($mobile_number)?>" >
                            </div>
                        </div>
                    </div>
                     <div class="col-md-6">
                     	<div class="form-group row">
                            <label class="col-lg-3 control-label pt-2 text-lg-right" for="service_name">Isactive<span class="required">*</span></label>
                            <div class="col-lg-6">
                                <div class="switch switch-sm switch-primary">
                                    <input type="checkbox" name="is_active" data-plugin-ios-switch <?php if($is_active == '1'){?>  checked="checked" <?php }?> />
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
                
                 <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="address">Username</label>
                            <div class="col-lg-8">
                                <input type="text" required="" class="form-control" id="username" name = "username" value="<?php inventory_display($username)?>" >
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="address">Password</label>
                            <div class="col-lg-8">
                                <input type="password" required="" class="form-control" id="password" name = "password" value="<?php inventory_display($password)?>" >
                            </div>
                        </div>
                    </div>
                 </div>
                 <!--<input type="hidden" name = "user_ai_id" value="<?php inventory_display(track64_encode($user_ai_id))?>"/>-->
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_user">Add User</button>
					</div>
				</div>
            </form>
        </div>
     </section> 
<?php } ?>