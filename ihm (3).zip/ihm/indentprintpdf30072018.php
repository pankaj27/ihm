<?php include('include/fpdf/mctable.php');  ?>
<?php if($case == "print"){
	
	$indentid = track64_decode(inventory_get_get('user_id'));
	
	
	   $select_user_details_query = "SELECT  * from  fld_order_new WHERE `fld_ai_id` = '".$indentid."';";
		$select_user_details_query_result = inventory_query($select_user_details_query); 
		
	

$pdf=new PDF_MC_Table();
$pdf->AddPage();

$pdf->SetFont('Arial','B',16);
if(inventory_num_rows($select_user_details_query_result)>0){
			$row_data = inventory_fetch_assoc($select_user_details_query_result);
			$fld_order_id = $row_data['fld_order_id'];
			$no_of_student = $row_data['no_of_student'];
			$indent_create_on = $row_data['indent_create_on'];
			$material_req_on = $row_data['material_req_on'];
			$fsubmit=$row_data['fld_timestamp'];
			$depid=$row_data['dep_id'];
			$for_class = $row_data['for_class'];
			$menu_name = explode(",",$row_data['menu_name']);
			$menunamecount=count($menu_name);
			$sem=$row_data['semester'];
			$sec=$row_data['section'];
			$prepairedby=$row_data['prepairedby'];
			//getsemester
			
			$select_semester = "SELECT * FROM  tbl_semester WHERE fld_ai_id ='".$sem."'";
		    $select_semester_result = inventory_query($select_semester); 
			$row_data_semester = inventory_fetch_assoc($select_semester_result);
            $semmm=$row_data_semester['fld_category'];
			
			
			
			//Section  name
			
			$select_section = "SELECT * FROM  tbl_section WHERE fld_ai_id ='".$sec."'";
		    $select_section_result = inventory_query($select_section); 
			$row_data_section = inventory_fetch_assoc($select_section_result);
            $seccc=$row_data_section['fld_category'];
			
			
			
			$fld_total_amount=$row_data['fld_total_amount'];
			$fld_gross_total=$row_data['fld_gross_total'];
			$fld_cgst = $row_data['fld_cgst'];
			$crtdby=$row_data['cretaed_by'];
			$aprovby=$row_data['approve_by'];
			//get user and approver
			$select_userdeta = "SELECT * FROM  tbl_user WHERE fld_ai_id ='".$crtdby."'";
		    $select_user_result = inventory_query($select_userdeta); 
			$row_data_user = inventory_fetch_assoc($select_user_result);
            $crtd_by=$row_data_user['fld_name'];
			
			if($aprovby!=0){
			$select_userdeta = "SELECT * FROM  tbl_user WHERE fld_ai_id ='".$aprovby."'";
		    $select_user_result = inventory_query($select_userdeta); 
			$row_data_user = inventory_fetch_assoc($select_user_result);
            $appr_by=$row_data_user['fld_name'];
			}else{
				$appr_by="";
			}
			
			
			///get department name  
			$select_department_query = "SELECT * FROM tbl_department WHERE fld_is_active ='".$depid."'";
		    $select_department_query_result = inventory_query($select_department_query); 
			$row_data_department = inventory_fetch_assoc($select_department_query_result);
            $depnm=$row_data_department['fld_department'];
			
$pdf->Image('img/logo.png',5,8,25,0,'PNG');
$pdf->Cell(10);		
$pdf->MultiCell(180,5,'Institute of Hotel Management Catering Technology & Applied Nutrition',0,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(200,10,' P - 16, Taratala Road, Kolkata-700088',0,1,'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(60,5,"Indent No-  $fld_order_id",0,0,'L');
$pdf->Cell(60,5,"STORE ISSUE BOOK",0,0,'C');
$pdf->SetFont('Arial','',8);
$pdf->Cell(60,5,"No of Student/Others: $no_of_student",0,1,'L');
$pdf->Line(157,34,185,34);
//$pdf->Cell(10,5,"___________________",0,1,'R');

//second row  
$pdf->Cell(120);
//$pdf->Cell(60);
$pdf->SetFont('Arial','',8);
$pdf->Cell(60,5,"Indent Prepared on: $indent_create_on",0,1,'L');
$pdf->Line(157,39,185,39);
//$pdf->Cell(10,5,"___________________",0,1,'R');


//third row  
$pdf->Cell(120);
//$pdf->Cell(60);
$pdf->SetFont('Arial','',8);
$pdf->Cell(60,5,"Indent Submitted on:  $fsubmit",0,1,'L');
$pdf->Line(157,44,185,44);
//$pdf->Cell(10,5,"___________________",0,1,'R');


//fourth row  
$pdf->Cell(120);
//$pdf->Cell(60);
$pdf->SetFont('Arial','',8);
$pdf->Cell(60,5,"Material Required on: $material_req_on",0,1,'L');
$pdf->Line(157,49,185,49);
//$pdf->Cell(10,5,"___________________",0,1,'R');

//fifth row 
$pdf->SetFont('Arial','B',10); 
$pdf->Cell(120,5,"Supply to:   $depnm",0,0,'L');
$pdf->Line(25,54,120,54);
//$pdf->Cell(60);
$pdf->SetFont('Arial','',8);
$pdf->Cell(60,5,"Material Issued on: ",0,1,'L');
$pdf->Line(157,54,185,54);
//$pdf->SetFont('Arial','B',10);
//$pdf->Cell(60,5,"Department: $depnm",0,1,'L');

$pdf->ln(5);
$pdf->SetFont('Arial','B',10); 
$pdf->Cell(60,5,"Semester:   $semmm",0,0,'L');

//$pdf->Cell(60);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(60,5,"Section: $seccc",0,1,'L');


//$pdf->Cell(10,5,"___________________",0,1,'R');
$pdf->ln(8);

$pdf->SetFont('Arial','',10);
$pdf->SetWidths(array(35,152));
$pdf->SetAligns(array("C","L"));
$pdf->Row(array("Menu of the Day",$row_data['menu_name']));
$pdf->ln(5);
$pdf->SetFont('Arial','B',10);
$pdf->SetWidths(array(10,50,20,25,20,20,20,22));
$pdf->SetAligns(array("C","C","C","C","C","C","C","C","R"));
 
$pdf->Row(array("S.no","Item Name","Qty","Price/Unit","Taxable value","CGST","SGST","Total"));

									$query1 = "select * from tbl_order_item where order_id='".trim($fld_order_id)."'";
										$result1 = inventory_query($query1);
										$slno=0;$sln=0;
										$supplied_vendor=array();
										if(inventory_num_rows($result1)>0){
											
											while($row1=inventory_fetch_assoc($result1)){
												$fld_item_id=$row1['fld_item_id'];
												$fld_cat_id=$row1['fld_itm_cat'];
												$fls_subcat_id=$row1['fld_item_subcat'];
												$fld_quantity=$row1['fld_quantity'];
												$fld_amount=$row1['fld_amount'];
												$item_gross=$row1['item_gross'];
												$item_tax=$row1['item_tax'];
												$item_tax_amount=$row1['item_tax_amount'];
												$cgsttax=number_format((float)($item_tax_amount/2), 2, '.', '');
												$sgstax=number_format((float)($item_tax_amount/2), 2, '.', '');
												$item_total=$row1['item_total'];
												///get item unit
												$queryunit1 = "select * from tbl_item where fld_ai_id='".trim($fld_item_id)."'";
										        $resultunit = inventory_query($queryunit1);
												$rowunit=inventory_fetch_assoc($resultunit);
												$unitname2=$rowunit['fld_unit'];
												$itemname=$rowunit['fld_name'];
												$unitpr=$rowunit['fld_price'];
												
												//get print unit...
												
												$queryunt = "select * from tbl_unit where fld_ai_id='".trim($unitname2)."'";
										        $resultunt = inventory_query($queryunt);
												$rowunt=inventory_fetch_assoc($resultunt);
												$unitname=$rowunt['fld_unit'];
												
												$vendorsupl=$rowunit['supplied_vendor'];
												array_push($supplied_vendor,$vendorsupl);
												$pdf->SetFont('Arial','',8);
												$pdf->SetWidths(array(10,50,20,25,20,20,20,22));
												$pdf->SetAligns(array("C","C","C","R","R","R","R","R","R"));
 													$sll=$sln+1;
												
													//$menu_namen=$menu_name[$sln];
													//$pdf->Row(array("$menu_namen","","$sll","$itemname","$fld_quantity $unitname","","","",""));
													$pdf->Row(array("$sll","$itemname","$fld_quantity $unitname","$unitpr","$item_gross","$cgsttax($item_tax%)","$sgstax($item_tax%)","$item_total"));
												
												
												
												$sln++;
												
											}


									
										}


$pdf->SetWidths(array(145,20,22));
$pdf->SetAligns(array("C","C","R"));
$pdf->Row(array("","Total","$fld_total_amount"));


/*----------------- Product Supplied ------------------------------*/
$pdf->ln(5);
$pdf->SetFont('Arial','B',10);
$pdf->SetWidths(array(30,30,30,30));
$pdf->SetAligns(array("R","R","R","R"));
 $fld_cgstn=$fld_cgst/2;
$pdf->Row(array("Taxable Value","CGST","SGST","Total"));

$fld_gross_totaln=number_format((float)($fld_gross_total-$fld_cgst), 2, '.', '');

$pdf->SetFont('Arial','',10);
$pdf->SetWidths(array(30,30,30,30));
$pdf->SetAligns(array("R","R","R","R"));
 
$pdf->Row(array("$fld_gross_totaln","$fld_cgstn","$fld_cgstn","$fld_total_amount"));




/*----------------- Product Supplied ------------------------------*/
$pdf->ln(5);
$pdf->SetFont('Arial','B',10);
$pdf->SetWidths(array(30,30,50));
$pdf->SetAligns(array("L","L","L"));
 
$pdf->Row(array("Vendor ID","Vendor Name","GST"));
//print_r($supplied_vendor);
$supplied_vendorunq=array_unique($supplied_vendor);
//print_r($supplied_vendorunq);
$supplied_vendorimp=implode(",", $supplied_vendorunq);

$supplied_vendorimpexp=explode(",",$supplied_vendorimp);
//$supplied_vendorimpexp1=implode(",", $supplied_vendorimpexp);
//$supplied_vendorimpexp2=explode(",",$supplied_vendorimpexp1);
$supplied_vendorimpexpun=array_unique($supplied_vendorimpexp);
$supplied_vendorimpexpunim=implode(",",$supplied_vendorimpexpun);
$supplied_vendorimpex2=explode(",",$supplied_vendorimpexpunim);
//print_r($supplied_vendorimpex2);
$slno=0;$sln=0;
if(count($supplied_vendorimpex2)>0){
	for($ijj=0;$ijj<count($supplied_vendorimpex2);$ijj++){
		 $query3 = "select * from tbl_vendor where fld_ai_id='".trim($supplied_vendorimpex2[$ijj])."'";
	    $result3 = inventory_fetch_assoc(inventory_query($query3));
		$venorgst=$result3['gstno'];
		$venornam=$result3['fld_name'];
		$venorid=$result3['fld_vn_id'];
		$pdf->SetFont('Arial','',10);
		$pdf->SetWidths(array(30,30,50));
		$pdf->SetAligns(array("L","L","L"));
		 
		$pdf->Row(array("$venorid","$venornam","$venorgst"));
	}
}
									

$pdf->ln(5);



$pdf->SetFont('Arial','B',10); 
$pdf->Cell(90,5,"Indent Prepared by:  $prepairedby",0,0,'L');
//$pdf->Line(45,112,110,112);
//$pdf->Cell(60);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(100,5,"Received by:_________________________",0,1,'R');
$pdf->SetFont('Arial','B',10); 
$pdf->ln(3);
$pdf->Cell(80,5,"Approved by:  $appr_by",0,0,'L');
//$pdf->Line(35,121,110,121);


}else{
			
	$pdf->Cell(200,10,'No Data available',0,1,'C');	
	
}

$pdf->Output();
 
 
 } ?>