<?php include('action/reports_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php if($case == "indentlist"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
				
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Indent List</h2>
        </header>
        <div class="card-body">
        	
        	<div class="row">
        	 	<div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="startdateindent" placeholder="Start Date" />
        	     </div>
        	     <div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="enddateindent" placeholder="End Date" />
        	     </div>
        	     <div class="col-md-3">
        	 		<button type="button" class="mb-1 mt-1 mr-1 btn btn-primary" onclick="getindentlist()" >Search</button>
        	     </div>
        	 </div>
        	
        	<div id="indent_lst">
	        	 <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">
	                <thead>
	                    <tr>
	                        <th>Indent ID</th>
	                        <th>Required On</th>
	                        <th>Menu Name</th>
	                        <th>Order date</th>
	                        <th>Department</th>
							<th>Semester</th>
							<th>Section</th>
	                        <th>Total(+tax)</th>
	                        <th>Status</th>
	                        <!--<th class="center">Action</th>-->
	                    </tr>
	                </thead>
	                <tbody id="indlst">
	                    <?php inventory_display($list);?>
	                </tbody>
	            </table>
            </div>
        </div>
    </section>
<?php } ?>

<?php if($case == "vendorlist"){ 
	//echo $list;
	?>
	
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Vendor List</h2>
        </header>
        <div class="card-body" id="vendors">
        	 <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">
                <thead>
                    <tr>
                    	<th>Vendor ID</th>
                    	<th>Company Name</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Products</th>
                        <th>GST NO</th>
                        
                        <th>Status</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>

<?php if($case == "polist"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
				
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Department wise PO List</h2>
        </header>
        <div class="card-body">
        	<div class="row">
        	 	<div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="startdatepo"  placeholder="Start Date"/>
        	     </div>
        	     <div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="enddatepo" placeholder="End Date" />
        	     </div>
        	     <div class="col-md-3">
        	 		<button type="button" class="mb-1 mt-1 mr-1 btn btn-primary" onclick="getpolist()" >Search</button>
        	     </div>
        	 </div>
        	 <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">
                <thead>
                    <tr>
                    	<th>PO ID</th>
                        <th>Indent ID</th>
                        <th>Vendor ID</th>
                       <th>Approve on</th>
                         <th>Department</th>
                        <th>Required On</th>
                        
                       
                    </tr>
                </thead>
                <tbody id="polst">
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>

<?php if($case == "receivelist"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Department wise PO Receivable List</h2>
        </header>
        <div class="card-body">
        	 <div class="row">
        	 	<div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="startdatereceive" placeholder="Start Date" />
        	     </div>
        	     <div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="enddatereceive" placeholder="End Date" />
        	     </div>
        	     <div class="col-md-3">
        	 		<button type="button" class="mb-1 mt-1 mr-1 btn btn-primary" onclick="getreceivelist()"  >Search</button>
        	     </div>
        	 </div>
        	 <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">
                <thead>
                    <tr>
                    	<th>PO ID</th>
                        <th>Indent ID</th>
                        <th>Vendor ID</th>
                       <th>Received on</th>
                        <th>Department</th>
                        <th>Require On</th>
                       
                    </tr>
                </thead>
                <tbody id="porecive">
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "itemlist"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Item Reports</h2>
        </header>
        <div class="card-body">
        	 <!--<div class="row">
        	 	<div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="startdatereceive" placeholder="Start Date" />
        	     </div>
        	     <div class="col-md-4">
        	 		<input type="text" data-plugin-datepicker="" class="form-control" id="enddatereceive" placeholder="End Date" />
        	     </div>
        	     <div class="col-md-3">
        	 		<button type="button" class="mb-1 mt-1 mr-1 btn btn-primary" onclick="getreceivelist()"  >Search</button>
        	     </div>
        	 </div>-->
        	 <table class="table table-bordered table-striped mb-0" id="datatable-tabletools">
                <thead>
                    <tr>
                    	<th>Sl No</th>
                        <th>Category</th>
                        <th>Sub-category</th>
                       <th>Item Name</th>
                        <th>Qnty</th>
                        <th>Unit</th>
                       
                    </tr>
                </thead>
                <tbody id="porecive">
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<script>
	
	function getindentlist(){
		
		var startdt=$("#startdateindent").val();
		var startdtsplt=startdt.split("/");
		var newstrtdt=startdtsplt[2]+"-"+startdtsplt[0]+"-"+startdtsplt[1];
		var enddte=$("#enddateindent").val();
		var enddtesplt=enddte.split("/");
		var enddtedt=enddtesplt[2]+"-"+enddtesplt[0]+"-"+enddtesplt[1];
		
		if(startdt=="" || startdt==null){
			alert('Start date is mandatory');
			exit;
		}
		
		if(enddte=="" || enddte==null){
			alert('End date is mandatory');
			exit;
		}
		
		$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getindentreport.php",
  			data :{'startdt':newstrtdt,'enddte':enddtedt},
  			success : function(data){
  				//console.log(data);
  				  /*var json=JSON.parse(data);
  				  var pric=json.fld_price;
  				  var fld_unit=json.fld_unit;
  				  var taxval=json.fld_tax;
  				   $("#price_"+idsplit[1]).val(pric);
  				   $("#divqty_"+idsplit[1]).text(fld_unit);
  				   $("#tax_"+idsplit[1]).val(taxval)
  				   */
  				  $("#indlst").html(data);
  					//gettaxcal(id)
  				}
  			
           }); 
	
		
	}
	
	function getreceivelist(){
		
		var startdt=$("#startdatereceive").val();
		var startdtsplt=startdt.split("/");
		var newstrtdt=startdtsplt[2]+"-"+startdtsplt[0]+"-"+startdtsplt[1];
		
		var enddte=$("#enddatereceive").val();
		var enddtesplt=enddte.split("/");
		var enddtedt=enddtesplt[2]+"-"+enddtesplt[0]+"-"+enddtesplt[1];
		
		if(startdt=="" || startdt==null){
			alert('Start date is mandatory');
			exit;
		}
		
		if(enddte=="" || enddte==null){
			alert('End date is mandatory');
			exit;
		}
		
		$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getreceivereport.php",
  			data :{'startdt':newstrtdt,'enddte':enddtedt},
  			success : function(data){
  				
  				 $("#porecive").html(data);
  				
  				  /*var json=JSON.parse(data);
  				  var pric=json.fld_price;
  				  var fld_unit=json.fld_unit;
  				  var taxval=json.fld_tax;
  				   $("#price_"+idsplit[1]).val(pric);
  				   $("#divqty_"+idsplit[1]).text(fld_unit);
  				   $("#tax_"+idsplit[1]).val(taxval)
  				   */
  				  //$("#").html();
  					//gettaxcal(id)
  				}
  			
           }); 
	
		
	}
	
	function getpolist(){
		
		var startdt=$("#startdatepo").val();
		var startdtsplt=startdt.split("/");
		var newstrtdt=startdtsplt[2]+"-"+startdtsplt[0]+"-"+startdtsplt[1];
		
		var enddte=$("#enddatepo").val();
		var enddtesplt=enddte.split("/");
		var enddtedt=enddtesplt[2]+"-"+enddtesplt[0]+"-"+enddtesplt[1];
		
		if(startdt=="" || startdt==null){
			alert('Start date is mandatory');
			exit;
		}
		
		if(enddte=="" || enddte==null){
			alert('End date is mandatory');
			exit;
		}
		
		$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getpoport.php",
  			data :{'startdt':newstrtdt,'enddte':enddtedt},
  			success : function(data){
  				console.log(data);
  				 $("#polst").html(data);
  				
  				  /*var json=JSON.parse(data);
  				  var pric=json.fld_price;
  				  var fld_unit=json.fld_unit;
  				  var taxval=json.fld_tax;
  				   $("#price_"+idsplit[1]).val(pric);
  				   $("#divqty_"+idsplit[1]).text(fld_unit);
  				   $("#tax_"+idsplit[1]).val(taxval)
  				  */ 
  					//gettaxcal(id)
  				}
  			
           }); 
	
		
	}
	
	
	
	
</script>

