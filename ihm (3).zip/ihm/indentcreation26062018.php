<?php include('action/indentcreation_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>

<?php if($case == "list"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		<?php
        		if($indent_w==0  ){
					
					
				}else{
					?>
					<a class="btn custom_border" href="<?php inventory_display(ROOT_PATH)?>/addindent"><i class="fa fa-plus" aria-hidden="true"></i> Create New Indent</a>
			<?php
				}
				
				?>
				</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Department wise Indent List</h2>
        </header>
        <div class="card-body">
        	 <table class="table table-bordered table-striped mb-0" id="datatable_with_search">
                <thead>
                    <tr>
                        <th>Indent ID</th>
                        <th>Required On</th>
                        <th>Menu Name</th>
                        
                        <th>Order date</th>
                        <th>Department</th>
                        <th>Total(+tax)</th>
                        <th>Status</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "edit"){ ?>
	<section class="card">
	    <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Indent</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" action = "<?php inventory_display(ROOT_PATH)?>/updateindent" >
        	    <?php 
        	        
        	    ?>
        	    <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Indent ID</label>
                            <div class="col-lg-8">
                                <input type="text" readonly required="" class="form-control" id="menu" name = "indent" value="<?php  inventory_display($fld_order_id); ?>" >
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="user_type">No Of Student's</label>
                            <div class="col-lg-8">
                                <input type="number" required="" class="form-control" id="nostu" name = "nostu" value="<?php inventory_display($no_of_student)?>" >
                            </div>
                        </div>
                    </div>
                    
                </div>
            	<div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Menu Name</label>
                            <div class="col-lg-8">
                               <textarea required class="form-control" id="menu" name = "menu"><?php inventory_display($menu_name)?></textarea>
                               
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="address">Required On</label>
                            <div class="col-lg-8">
                                <div class="input-group">
									<span class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</span>
									<input type="text" id="datepicker2" class="form-control" name="reqon" value="<?php inventory_display($material_req_on)?>">
								</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="email">DEPARTMENT</label>
                            <div class="col-lg-8">
                            	<?php
                            		//$depid=inventory_get_session(VARIABLE_PREFIX."dep_id");
                            		$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$depid."'";
							        $select_department_query_result = inventory_query($select_department_query); 
									$row_data = inventory_fetch_assoc($select_department_query_result)
                            	
                            	?>
                                <input type="hidden"  required="" class="form-control" id="class" name = "class" value="<?php echo $row_data['fld_ai_id']; ?>" >
                                <input type="text" readonly  required="" class="form-control" id="class" name = "classf" value="<?php echo $row_data['fld_department']; ?>" >
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="mobile_number">Prepared On</label>
                            <div class="col-lg-8">
                                <input type="text" readonly required="" class="form-control" id="prepareon" name = "prepareon" value="<?php inventory_display($indent_create_on)?>" >
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="form-group row">
                   <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="email">SEMESTER</label>
                            <div class="col-lg-8">
                            	<?php
                            		  $select_semester_query = "SELECT * FROM  tbl_semester ";
							        $select_semester_query_result = inventory_query($select_semester_query); 
									$row_data11 = inventory_fetch_assoc($select_semester_query_result);
                            	//echo $semester;
                            	?>
                               <select class="form-control" name="semester" required="required">
                               	<option value="">--select--</option>
                               	<?php if(isset($row_data11) && !empty($row_data11)){
                               		while($row_data2 = inventory_fetch_assoc($select_semester_query_result)){
                               	?>	
									<option value="<?php echo $row_data2['fld_ai_id']; ?>" <?php   if($row_data2['fld_ai_id']==$semester){ echo "selected";} ?>><?php echo $row_data2['fld_category'] ; ?></option>
									
                              <?php  }	} ?>
                               </select> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="email">SECTION</label>
                            <div class="col-lg-8">
                            	<?php
                            		  $select_section_query = "SELECT * FROM  tbl_section ";
							        $select_section_query_result = inventory_query($select_section_query); 
									
                            	    //print_r($row_data1section);
                            	    //echo $section;
                            	?>
                               <select class="form-control" name="section" required="required">
                               	<option value="">--select--</option>
                               	<?php 
                               		while($row_dat = inventory_fetch_assoc($select_section_query_result)){
                               	?>	
									<option value="<?php echo $row_dat['fld_ai_id']; ?>" <?php   if($row_dat['fld_ai_id']==$section){ echo "selected"; } ?>><?php echo $row_dat['fld_category'] ; ?></option>
									
                              <?php  	} ?>
                               </select> 
                            </div>
                        </div>
                    </div>
                    
                    
                    
                </div>
                
                <div class="form-group row">
                    <div class="col-md-12" style="width: 100%;overflow: scroll;">
                        <table class="table table-bordered table-striped mb-0" style="overflow: scroll;">
			                <thead>
			                    <tr>
			                        <th>Action</th>
			                        <th>Category</th>
			                        <th>Sub-Category</th>
			                        <th>Item</th>
			                        <th>Qty</th>
			                        <th>Unit</th>
			                        <th>Price</th>
			                        <th>Gross</th>
			                        <th>Tax</th>
			                        <th style="width:50px;">Total</th>
			                        
			                    </tr>
			                </thead>
			                <tbody id="itemdetailsnn">
			                	<?php
			                	$sln=1;
			                		if(isset($fld_order_id) && !empty($fld_order_id)){
			                			
										$query1 = "select * from tbl_order_item where order_id='".trim($fld_order_id)."'";
										$result1 = inventory_query($query1);
										if(inventory_num_rows($result1)>0){
											$sln=1;
											while($row1=inventory_fetch_assoc($result1)){
												$fld_item_id=$row1['fld_item_id'];
												$fld_cat_id=$row1['fld_itm_cat'];
												$fls_subcat_id=$row1['fld_item_subcat'];
												$fld_quantity=$row1['fld_quantity'];
												$fld_amount=$row1['fld_amount'];
												$item_gross=$row1['item_gross'];
												$item_tax=$row1['item_tax'];
												$item_tax_amount=$row1['item_tax_amount'];
												$item_total=$row1['item_total'];
												///get item unit
												$queryunit1 = "select * from tbl_item where fld_ai_id='".trim($fld_item_id)."'";
										        $resultunit = inventory_query($queryunit1);
												$rowunit=inventory_fetch_assoc($resultunit);
												$unitname=$rowunit['fld_unit'];
												
												
								?>
								
								 <tr>
			                		<td><a href="javascript:void(0)" id="newrow_<?php echo $sln; ?>" onclick="addnewrow(this.id)"><i class="fa fa-plus" aria-hidden="true"></i></a>
			                			
			                		</td>
			                		<td>
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_category_query = "select * from tbl_category where fld_isactive='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="category_<?php echo $sln; ?>" name="category_<?php echo $sln; ?>" onchange="getsubcategory(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_ai_id']; ?>"<?php if($row_data_category['fld_ai_id']==$fld_cat_id){ echo 'selected'; } ?>><?php echo $row_data_category['fld_category'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                		</td>
			                		<td>
			                			
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_subcat_query = "select * from tbl_sub_category where fld_is_active='1'";
											$select_subcat_result = inventory_query($select_subcat_query);
											if(inventory_num_rows($select_subcat_result)>0){
										?>
											<select class="form-control" id="subcategory_<?php echo $sln; ?>" name="subcategory_<?php echo $sln; ?>" onchange="getitem(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_subcategory = inventory_fetch_assoc($select_subcat_result)){
										?>
												<option value="<?php echo $row_subcategory['fld_ai_id']; ?>"<?php if($row_subcategory['fld_ai_id']==$fls_subcat_id){ echo 'selected'; } ?>><?php echo $row_subcategory['fld_sub_category'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                			<!--
			                			
			                			<select class="form-control" id="subcategory_<?php echo $sln; ?>" name="subcategory_<?php echo $sln; ?>" onchange="getitem(this.id);">
			                				<option value="">--Select--</option>
			                			</select>
			                			
			                			-->
			                		</td>
			                		<td>
			                			
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_item = "select * from tbl_item where fld_is_active='1'";
											$select_item_result = inventory_query($select_item);
											if(inventory_num_rows($select_item_result)>0){
										?>
											<select class="form-control" id="item_<?php echo $sln; ?>" name="item_<?php echo $sln; ?>" onchange="getitemdetailsinfo(this.id)">	<option value="">--select--</option>
												
										<?php
												while($row_item = inventory_fetch_assoc($select_item_result)){
										?>
												<option value="<?php echo $row_item['fld_ai_id']; ?>"<?php if($row_item['fld_ai_id']==$fls_subcat_id){ echo 'selected'; } ?>><?php echo $row_item['fld_name'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                			<!--<select class="form-control" id="item_<?php echo $sln; ?>" name="item_<?php echo $sln; ?>" onchange="getitemdetailsinfo(this.id)">
			                				<option value="">--Select--</option>
			                			</select>-->
			                		</td>
			                		<td><input value="<?php if(isset($fld_quantity)&& !empty($fld_quantity)){ echo $fld_quantity; } ?>" style="width:50px;" type="text" class="form-control" name="qty_<?php echo $sln; ?>" id="qty_<?php echo $sln; ?>" style="width:80px" onblur="gettotalvalproduct(this.id);" ></td>
			                		<td><div id="divqty_<?php echo $sln; ?>" style="width:40px;"><?php echo $unitname;  ?></div></td>
			                		<td><input value="<?php if(isset($fld_amount)&& !empty($fld_amount)){ echo $fld_amount; } ?>" style="width:80px;" type="text" readonly class="form-control" name="price_<?php echo $sln; ?>" id="price_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td><input value="<?php if(isset($item_gross)&& !empty($item_gross)){ echo $item_gross; } ?>" style="width:80px;" type="text" readonly class="form-control" name="gross_<?php echo $sln; ?>" id="gross_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td>
			                		    <input readonly value="<?php if(isset($item_tax)&& !empty($item_tax)){ echo  number_format((float)($item_tax), 2, '.', '') ; } ?>" style="width:50px;" type="text" class="form-control" name="tax_<?php echo $sln; ?>" id="tax_<?php echo $sln; ?>"  >
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                			/*	$select_category_query = "select * from  tbl_tax where fld_is_active='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="tax_<?php echo $sln; ?>" name="tax_<?php echo $sln; ?>" onchange="gettaxcal(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_sgst']; ?>" <?php if($row_data_category['fld_sgst']==$item_tax){ echo 'selected'; }  ?>><?php echo $row_data_category['fld_sgst']."+".$row_data_category['fld_cgst'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
										*/	
			                			
			                			?>
			                		</td>
			                		<td><input value="<?php if(isset($item_total)&& !empty($item_total)){ echo $item_total; } ?>" style="width:80px;" type="text" readonly class="form-control" name="totar_<?php echo $sln; ?>" id="totar_<?php echo $sln; ?>" style="width:100px;text-align: right;" ></td>
			                	</tr>
								
								
								
								
								
								
								
								<?php		$sln++;
											
											}
													
												
											
										}
										
										
			                	?>
			                			
			                	
			                	
			                	
			                	<?php		
										
			                		}else{
			                	?>
			                	<tr>
			                		<td><!--<a href="javascript:void(0)" id="newrow_<?php echo $sln; ?>" onclick="addnewrow(this.id)"><i class="fa fa-plus" aria-hidden="true"></i></a>-->
			                			
			                		</td>
			                		<td>
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_category_query = "select * from tbl_category where fld_isactive='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="category_<?php echo $sln; ?>" name="category_<?php echo $sln; ?>" onchange="getsubcategory(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_ai_id']; ?>"><?php echo $row_data_category['fld_category'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                		</td>
			                		<td>
			                			<select class="form-control" id="subcategory_<?php echo $sln; ?>" name="subcategory_<?php echo $sln; ?>" onchange="getitem(this.id);">
			                				<option value="">--Select--</option>
			                			</select>
			                		</td>
			                		<td>
			                			<select class="form-control" id="item_<?php echo $sln; ?>" name="item_<?php echo $sln; ?>" onchange="getitemdetailsinfo(this.id)">
			                				<option value="">--Select--</option>
			                			</select>
			                		</td>
			                		<td><input style="width:50px;" type="text" class="form-control" name="qty_<?php echo $sln; ?>" id="qty_<?php echo $sln; ?>" style="width:80px" onblur="gettotalvalproduct(this.id);" ></td>
			                		<td><div id="divqty_1" style="width:40px;"></div></td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="price_<?php echo $sln; ?>" id="price_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="gross_<?php echo $sln; ?>" id="gross_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td>
			                			
			                			<input style="width:80px;" type="text" readonly class="form-control" name="tax_<?php echo $sln; ?>" id="tax_<?php echo $sln; ?>" style="width:100px" value="0" >
			                			
			                			
			                			
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				/*$select_category_query = "select * from  tbl_tax where fld_is_active='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="tax_<?php echo $sln; ?>" name="tax_<?php echo $sln; ?>" onchange="gettaxcal(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_sgst']; ?>"><?php echo $row_data_category['fld_sgst']."+".$row_data_category['fld_cgst'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			    */
			                			?>
			                		</td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="totar_<?php echo $sln; ?>" id="totar_<?php echo $sln; ?>" style="width:100px;text-align: right;" ></td>
			                	</tr>
			                	<?php  } ?>
			                		
			                    
			                </tbody>
			            </table>
                    </div>
                    
                    
                    
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <div class="form-group row">
                        	Remarks
                        	<textarea class="form-control" name="remarks" placeholder="Remarks....."> </textarea>
                            <input type="hidden" name="totalrow" id="totalrow" value="<?php echo $sln; ?>" >
                        </div>
                    </div>
                    <div class="col-md-4">
                     	<div class="form-group row">
                            
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="form-group row">
                            <table class="table table-bordered table-striped mb-0">
			                <thead>
			                    <tr>
			                        <td>Total</td>
			                        <td><input readonly required="" type="text" class="form-control" name="total" id="total" style="text-align:right;" value="<?php inventory_display($fld_gross_total)?>"/></td>
			                        
			                    </tr>
			                </thead>
			                <tbody>
			                    <tr>
			                        <td>Tax</td>
			                        <td><input value="<?php inventory_display($fld_cgst)?>" readonly type="text" class="form-control" name="total_tax" id="total_tax" style="text-align:right;"/></td>
			                        
			                    </tr>
			                    <tr>
			                        <td>Total Amount</td>
			                        <td><input value="<?php inventory_display($fld_total_amount)?>" readonly required="" type="text" class="form-control" name="total_amount" id="total_amount" style="text-align:right;"/></td>
			                        
			                    </tr>
			                </tbody>
			            </table>
                        </div>
                    </div>
                    
                    
                    
                </div>
                 
                 <!--<input type="hidden" name = "user_ai_id" value="<?php inventory_display(track64_encode($user_ai_id))?>"/>-->
                 <?php if($user_type=="user"){ ?>
                 		<div class="form-group row">
							<div class="col-md-12 align_center">
								<input type="hidden" value="" id="itemid">
								<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-primary" name="draft_indent">Save as Draft</button>
								&nbsp;&nbsp;&nbsp;&nbsp;
								<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-success" name="add_indent">Final Submit</button>
							</div>
						</div>
                 	
				 <?php }
					   if($user_type=="hod"){
				 ?>
				 
				 		<div class="form-group row">
							<div class="col-md-12 align_center">
								<input type="hidden" value="" id="itemid">
								<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-success" name="approve_indent">Approve</button>
								&nbsp;&nbsp;&nbsp;&nbsp;
								<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-danger" name="disapprove_indent">Disapprove</button>
							</div>
						</div>
										
				<?php } ?>
				
				<?php 
					   if($user_type=="store_keeper" || $user_type=="admin" ){
				 ?>
				 
				 		<div class="form-group row">
							<div class="col-md-12 align_center">
								<input type="hidden" value="" id="itemid">
								<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-success" name="finalapprove_indent">Final Approve & Generate PO</button>
								&nbsp;&nbsp;&nbsp;&nbsp;
								<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-danger" name="disapprove_indent">Disapprove</button>
								
								
							</div>
						</div>
										
				<?php } ?>
                
            </form>
        </div>
     </section> 
<?php } ?>
<?php if($case == "add" )
{ ?>
	<section class="card">
	    <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Create New Indent</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" action = "<?php inventory_display(ROOT_PATH)?>/addindent" >
        	    <?php 
        	        $indentqry = "select * from fld_order_new  order by fld_ai_id desc limit 1";
					$indentqry_result = inventory_query($indentqry);
					$indent_res = inventory_fetch_assoc($indentqry_result);
        	       if(isset($indent_res) && !empty($indent_res)){
        	           $indid=$indent_res['fld_order_id'];
        	           $newid=$indid+1;
        	           
        	       }else{
        	           
        	           $newid=1;
        	       }
        	    
        	    ?>
        	    <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Indent ID</label>
                            <div class="col-lg-8">
                                <input type="text" readonly required="" class="form-control" id="menu" name = "indent" value="<?php  echo $newid; ?>" >
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="user_type">No Of Student's</label>
                            <div class="col-lg-8">
                                <input type="number" class="form-control" id="nostu" name = "nostu" value="" >
                            </div>
                        </div>
                    </div>
                    
                </div>
            	<div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Menu Name</label>
                            <div class="col-lg-8">
                               <textarea required class="form-control" id="menu" name = "menu"><?php if(isset($name) && !empty($name)){ inventory_display($name) ;} ?></textarea>
                               
                            </div>
                        </div>
                    </div>
                    
                     <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="email">DEPARTMENT</label>
                            <div class="col-lg-8">
                            	<?php
                            		$depid=inventory_get_session(VARIABLE_PREFIX."dep_id");
                            		 $select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".trim($depid)."'";
							        $select_department_query_result = inventory_query($select_department_query); 
									$row_data = inventory_fetch_assoc($select_department_query_result)
                            	
                            	?>
                                <input type="hidden"  required="" class="form-control" id="class" name = "class" value="<?php echo $row_data['fld_ai_id']; ?>" >
                                <input type="text" readonly  required="" class="form-control" id="class" name = "classf" value="<?php echo $row_data['fld_department']; ?>" >
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                   <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="email">SEMESTER</label>
                            <div class="col-lg-8">
                            	<?php
                            		  $select_semester_query = "SELECT * FROM  tbl_semester ";
							        $select_semester_query_result = inventory_query($select_semester_query); 
									$row_data11 = inventory_fetch_assoc($select_semester_query_result);
                            	
                            	?>
                               <select class="form-control" name="semester" required="required">
                               	<option value="">--select--</option>
                               	<?php if(isset($row_data11) && !empty($row_data11)){
                               		while($row_data = inventory_fetch_assoc($select_semester_query_result)){
                               	?>	
									<option value="<?php echo $row_data['fld_ai_id']; ?>"><?php echo $row_data['fld_category'] ; ?></option>
									
                              <?php  }	} ?>
                               </select> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="email">SECTION</label>
                            <div class="col-lg-8">
                            	<?php
                            		  $select_section_query = "SELECT * FROM  tbl_section ";
							        $select_section_query_result = inventory_query($select_section_query); 
									
                            	    //print_r($row_data1section);
                            	?>
                               <select class="form-control" name="section" required="required">
                               	<option value="">--select--</option>
                               	<?php 
                               		while($row_dat = inventory_fetch_assoc($select_section_query_result)){
                               	?>	
									<option value="<?php echo $row_dat['fld_ai_id']; ?>"><?php echo $row_dat['fld_category'] ; ?></option>
									
                              <?php  	} ?>
                               </select> 
                            </div>
                        </div>
                    </div>
                    
                    
                    
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="address">Required On</label>
                            <div class="col-lg-8">
                                <div class="input-group">
									<span class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</span>
									<input type="text" id="datepicker" class="form-control" name="reqon">
								</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="mobile_number">Prepared On</label>
                            <div class="col-lg-8">
                                <input type="text" readonly required="" class="form-control" id="prepareon" name = "prepareon" value="<?php echo date('Y-m-d'); ?>" >
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
                
                <div class="form-group row">
                    <div class="col-md-12">
                        <table class="table table-bordered table-striped mb-0" style="overflow: scroll;">
			                <thead>
			                    <tr>
			                        <th>Action</th>
			                        <th>Category</th>
			                        <th>Sub-Category</th>
			                        <th>Item</th>
			                        <th>Qty</th>
			                        <th>Unit</th>
			                        <th>Price</th>
			                        <th>Gross</th>
			                        <th>Tax</th>
			                        <th style="width:50px;">Total</th>
			                        
			                    </tr>
			                </thead>
			                <tbody id="itemdetailsnn">
			                	<tr>
			                		<td><a href="javascript:void(0)" id="newrow_1" onclick="addnewrow(this.id)"><i class="fa fa-plus" aria-hidden="true"></i></a>
			                			
			                		</td>
			                		<td>
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_category_query = "select * from tbl_category where fld_isactive='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="category_1" name="category_1" onchange="getsubcategory(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_ai_id']; ?>"><?php echo $row_data_category['fld_category'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                		</td>
			                		<td>
			                			<select class="form-control" id="subcategory_1" name="subcategory_1" onchange="getitem(this.id);">
			                				<option value="">--Select--</option>
			                			</select>
			                		</td>
			                		<td>
			                			<select class="form-control" id="item_1" name="item_1" onchange="getitemdetailsinfo(this.id)">
			                				<option value="">--Select--</option>
			                			</select>
			                		</td>
			                		<td><input style="width:50px;" type="text" class="form-control" name="qty_1" id="qty_1" style="width:80px" onblur="gettotalvalproduct(this.id);" ></td>
			                		<td><div id="divqty_1" style="width:40px;"></div></td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="price_1" id="price_1" style="width:100px" ></td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="gross_1" id="gross_1" style="width:100px" ></td>
			                		<td>
			                			<input style="width:80px;" type="text" readonly class="form-control" name="tax_1" id="tax_1" style="width:100px" value="0" >
			                			
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				/*$select_category_query = "select * from  tbl_tax where fld_is_active='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="tax_1" name="tax_1" onchange="gettaxcal(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_sgst']; ?>"><?php echo $row_data_category['fld_sgst']."+".$row_data_category['fld_cgst'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											*/
			                			
			                			?>
			                		</td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="totar_1" id="totar_1" style="width:100px;text-align: right;" ></td>
			                	</tr>
			                		
			                    
			                </tbody>
			            </table>
                    </div>
                    
                    
                    
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <div class="form-group row">
                            <input type="hidden" name="totalrow" id="totalrow" value="1" >
                        </div>
                    </div>
                    <div class="col-md-4">
                     	<div class="form-group row">
                            
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="form-group row">
                            <table class="table table-bordered table-striped mb-0">
			                <thead>
			                    <tr>
			                        <td>Total</td>
			                        <td><input readonly required="" type="text" class="form-control" name="total" id="total" style="text-align:right;"/></td>
			                        
			                    </tr>
			                </thead>
			                <tbody>
			                    <tr>
			                        <td>Tax</td>
			                        <td><input readonly type="text" class="form-control" name="total_tax" id="total_tax" style="text-align:right;"/></td>
			                        
			                    </tr>
			                    <tr>
			                        <td>Total Amount</td>
			                        <td><input readonly required="" type="text" class="form-control" name="total_amount" id="total_amount" style="text-align:right;"/></td>
			                        
			                    </tr>
			                </tbody>
			            </table>
                        </div>
                    </div>
                    
                    
                    
                </div>
                 
                 <!--<input type="hidden" name = "user_ai_id" value="<?php inventory_display(track64_encode($user_ai_id))?>"/>-->
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<input type="hidden" value="" id="itemid">
						<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-primary" name="draft_indent">Save as Draft</button>
						&nbsp;&nbsp;&nbsp;&nbsp;
						<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-success" name="add_indent">Final Submit</button>
					</div>
				</div>
            </form>
        </div>
     </section> 
<?php } ?>
<?php if($case == "view"){ ?>
	<section class="card">
	    <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> View Indent</h2>
        </header>
        <div class="card-body">
        	    <?php 
        	        
        	    ?>
        	    <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Indent ID</label>
                            <div class="col-lg-8">
                                <input type="text" readonly required="" class="form-control" id="menu" name = "indent" value="<?php  inventory_display($fld_order_id); ?>" >
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="user_type">No Of Student's</label>
                            <div class="col-lg-8">
                                <input type="number" readonly required="" class="form-control" id="nostu" name = "nostu" value="<?php inventory_display($no_of_student)?>" >
                            </div>
                        </div>
                    </div>
                    
                </div>
            	<div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Menu Name</label>
                            <div class="col-lg-8">
                               <textarea required readonly class="form-control" id="menu" name = "menu"><?php inventory_display($menu_name)?></textarea>
                               
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="address">Required On</label>
                            <div class="col-lg-8">
                                <div class="input-group">
									<span class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</span>
									<input type="text" readonly data-plugin-datepicker="datepickek" class="form-control" name="reqon" value="<?php inventory_display($material_req_on)?>">
								</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="email">DEPARTMENT</label>
                            <div class="col-lg-8">
                            	<?php
                            		//$depid=inventory_get_session(VARIABLE_PREFIX."dep_id");
                            		$select_department_query = "SELECT * FROM tbl_department WHERE fld_ai_id ='".$depid."'";
							        $select_department_query_result = inventory_query($select_department_query); 
									$row_data = inventory_fetch_assoc($select_department_query_result)
                            	
                            	?>
                                <input type="hidden"  required="" class="form-control" id="class" name = "class" value="<?php echo $row_data['fld_ai_id']; ?>" >
                                <input type="text" readonly  required="" class="form-control" id="class" name = "classf" value="<?php echo $row_data['fld_department']; ?>" >
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="mobile_number">Prepared On</label>
                            <div class="col-lg-8">
                                <input type="text" readonly required="" class="form-control" id="prepareon" name = "prepareon" value="<?php inventory_display($indent_create_on)?>" >
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="form-group row">
                    <!--<div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2" for="city">Created By</label>
                            <div class="col-lg-8">
                                <input type="text" readonly required="" class="form-control" id="crtd" name = "crtd" value="<?php inventory_display($city)?>" >
                            </div>
                        </div>
                    </div>
                   -->
                    
                    
                </div>
                
                <div class="form-group row">
                    <div class="col-md-12" style="width: 100%;overflow: scroll;">
                        <table class="table table-bordered table-striped mb-0" style="overflow: scroll;">
			                <thead>
			                    <tr>
			                        <th>Action</th>
			                        <th>Category</th>
			                        <th>Sub-Category</th>
			                        <th>Item</th>
			                        <th>Qty</th>
			                        <th>Unit</th>
			                        <th>Price</th>
			                        <th>Gross</th>
			                        <th>Tax</th>
			                        <th style="width:50px;">Total</th>
			                        
			                    </tr>
			                </thead>
			                <tbody id="itemdetailsnn">
			                	<?php
			                	$sln=1;
			                		if(isset($fld_order_id) && !empty($fld_order_id)){
			                			
										$query1 = "select * from tbl_order_item where order_id='".trim($fld_order_id)."'";
										$result1 = inventory_query($query1);
										if(inventory_num_rows($result1)>0){
											$sln=1;
											while($row1=inventory_fetch_assoc($result1)){
												$fld_item_id=$row1['fld_item_id'];
												$fld_cat_id=$row1['fld_itm_cat'];
												$fls_subcat_id=$row1['fld_item_subcat'];
												$fld_quantity=$row1['fld_quantity'];
												$fld_amount=$row1['fld_amount'];
												$item_gross=$row1['item_gross'];
												$item_tax=$row1['item_tax'];
												$item_tax_amount=$row1['item_tax_amount'];
												$item_total=$row1['item_total'];
												///get item unit
												$queryunit1 = "select * from tbl_item where fld_ai_id='".trim($fld_item_id)."'";
										        $resultunit = inventory_query($queryunit1);
												$rowunit=inventory_fetch_assoc($resultunit);
												$unitname=$rowunit['fld_unit'];
												
												
								?>
								
								 <tr>
			                		<td>
			                			
			                		</td>
			                		<td>
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_category_query = "select * from tbl_category where fld_isactive='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="category_<?php echo $sln; ?>" name="category_<?php echo $sln; ?>" onchange="getsubcategory(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_ai_id']; ?>"<?php if($row_data_category['fld_ai_id']==$fld_cat_id){ echo 'selected'; } ?>><?php echo $row_data_category['fld_category'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                		</td>
			                		<td>
			                			
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_subcat_query = "select * from tbl_sub_category where fld_is_active='1'";
											$select_subcat_result = inventory_query($select_subcat_query);
											if(inventory_num_rows($select_subcat_result)>0){
										?>
											<select class="form-control" id="subcategory_<?php echo $sln; ?>" name="subcategory_<?php echo $sln; ?>" onchange="getitem(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_subcategory = inventory_fetch_assoc($select_subcat_result)){
										?>
												<option value="<?php echo $row_subcategory['fld_ai_id']; ?>"<?php if($row_subcategory['fld_ai_id']==$fls_subcat_id){ echo 'selected'; } ?>><?php echo $row_subcategory['fld_sub_category'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                			<!--
			                			
			                			<select class="form-control" id="subcategory_<?php echo $sln; ?>" name="subcategory_<?php echo $sln; ?>" onchange="getitem(this.id);">
			                				<option value="">--Select--</option>
			                			</select>
			                			
			                			-->
			                		</td>
			                		<td>
			                			
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_item = "select * from tbl_item where fld_is_active='1'";
											$select_item_result = inventory_query($select_item);
											if(inventory_num_rows($select_item_result)>0){
										?>
											<select class="form-control" id="item_<?php echo $sln; ?>" name="item_<?php echo $sln; ?>" onchange="getitemdetailsinfo(this.id)">	<option value="">--select--</option>
												
										<?php
												while($row_item = inventory_fetch_assoc($select_item_result)){
										?>
												<option value="<?php echo $row_item['fld_ai_id']; ?>"<?php if($row_item['fld_ai_id']==$fls_subcat_id){ echo 'selected'; } ?>><?php echo $row_item['fld_name'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                			<!--<select class="form-control" id="item_<?php echo $sln; ?>" name="item_<?php echo $sln; ?>" onchange="getitemdetailsinfo(this.id)">
			                				<option value="">--Select--</option>
			                			</select>-->
			                		</td>
			                		<td><input value="<?php if(isset($fld_quantity)&& !empty($fld_quantity)){ echo $fld_quantity; } ?>" style="width:50px;" type="text" class="form-control" name="qty_<?php echo $sln; ?>" id="qty_<?php echo $sln; ?>" style="width:80px" onblur="gettotalvalproduct(this.id);" ></td>
			                		<td><div id="divqty_<?php echo $sln; ?>" style="width:40px;"><?php echo $unitname;  ?></div></td>
			                		<td><input value="<?php if(isset($fld_amount)&& !empty($fld_amount)){ echo $fld_amount; } ?>" style="width:80px;" type="text" readonly class="form-control" name="price_<?php echo $sln; ?>" id="price_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td><input value="<?php if(isset($item_gross)&& !empty($item_gross)){ echo $item_gross; } ?>" style="width:80px;" type="text" readonly class="form-control" name="gross_<?php echo $sln; ?>" id="gross_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td>
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_category_query = "select * from  tbl_tax where fld_is_active='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="tax_<?php echo $sln; ?>" name="tax_<?php echo $sln; ?>" onchange="gettaxcal(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_sgst']; ?>" <?php if($row_data_category['fld_sgst']==$item_tax){ echo 'selected'; }  ?>><?php echo $row_data_category['fld_sgst']."+".$row_data_category['fld_cgst'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                		</td>
			                		<td><input value="<?php if(isset($item_total)&& !empty($item_total)){ echo $item_total; } ?>" style="width:80px;" type="text" readonly class="form-control" name="totar_<?php echo $sln; ?>" id="totar_<?php echo $sln; ?>" style="width:100px;text-align: right;" ></td>
			                	</tr>
								
								
								
								
								
								
								
								<?php		$sln++;
											
											}
													
												
											
										}
										
										
			                	?>
			                			
			                	
			                	
			                	
			                	<?php		
										
			                		}else{
			                	?>
			                	<tr>
			                		<td><!--<a href="javascript:void(0)" id="newrow_<?php echo $sln; ?>" onclick="addnewrow(this.id)"><i class="fa fa-plus" aria-hidden="true"></i></a>-->
			                			
			                		</td>
			                		<td>
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				$select_category_query = "select * from tbl_category where fld_isactive='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="category_<?php echo $sln; ?>" name="category_<?php echo $sln; ?>" onchange="getsubcategory(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_ai_id']; ?>"><?php echo $row_data_category['fld_category'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											
			                			
			                			?>
			                			
			                		</td>
			                		<td>
			                			<select class="form-control" id="subcategory_<?php echo $sln; ?>" name="subcategory_<?php echo $sln; ?>" onchange="getitem(this.id);">
			                				<option value="">--Select--</option>
			                			</select>
			                		</td>
			                		<td>
			                			<select class="form-control" id="item_<?php echo $sln; ?>" name="item_<?php echo $sln; ?>" onchange="getitemdetailsinfo(this.id)">
			                				<option value="">--Select--</option>
			                			</select>
			                		</td>
			                		<td><input style="width:50px;" type="text" class="form-control" name="qty_<?php echo $sln; ?>" id="qty_<?php echo $sln; ?>" style="width:80px" onblur="gettotalvalproduct(this.id);" ></td>
			                		<td><div id="divqty_1" style="width:40px;"></div></td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="price_<?php echo $sln; ?>" id="price_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="gross_<?php echo $sln; ?>" id="gross_<?php echo $sln; ?>" style="width:100px" ></td>
			                		<td>
			                			<input style="width:80px;" type="text" readonly class="form-control" name="tax_<?php echo $sln; ?>" id="tax_<?php echo $sln; ?>" style="width:100px" value="0" >
			                			<?php
			                				//$qrycat=mysqli_query($con,"select * from ");
			                				/*$select_category_query = "select * from  tbl_tax where fld_is_active='1'";
											$select_sub_category_query_result = inventory_query($select_category_query);
											if(inventory_num_rows($select_sub_category_query_result)>0){
										?>
											<select class="form-control" id="tax11_<?php echo $sln; ?>" name="tax_<?php echo $sln; ?>" onchange="gettaxcal(this.id);">
												<option value="">--select--</option>
												
										<?php
												while($row_data_category = inventory_fetch_assoc($select_sub_category_query_result)){
										?>
												<option value="<?php echo $row_data_category['fld_sgst']; ?>"><?php echo $row_data_category['fld_sgst']."+".$row_data_category['fld_cgst'];  ?></option>
										
										<?php			
													
												}
										?>
											</select>
										<?php		
												
											} 
											*/
			                			
			                			?>
			                		</td>
			                		<td><input style="width:80px;" type="text" readonly class="form-control" name="totar_<?php echo $sln; ?>" id="totar_<?php echo $sln; ?>" style="width:100px;text-align: right;" ></td>
			                	</tr>
			                	<?php  } ?>
			                		
			                    
			                </tbody>
			            </table>
                    </div>
                    
                    
                    
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <div class="form-group row">
                            <input type="hidden" name="totalrow" id="totalrow" value="<?php echo $sln; ?>" >
                        </div>
                    </div>
                    <div class="col-md-4">
                     	<div class="form-group row">
                            
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="form-group row">
                            <table class="table table-bordered table-striped mb-0">
			                <thead>
			                    <tr>
			                        <td>Total</td>
			                        <td><input readonly required="" type="text" class="form-control" name="total" id="total" style="text-align:right;" value="<?php inventory_display($fld_gross_total)?>"/></td>
			                        
			                    </tr>
			                </thead>
			                <tbody>
			                    <tr>
			                        <td>Tax</td>
			                        <td><input value="<?php inventory_display($fld_cgst)?>" readonly type="text" class="form-control" name="total_tax" id="total_tax" style="text-align:right;"/></td>
			                        
			                    </tr>
			                    <tr>
			                        <td>Total Amount</td>
			                        <td><input value="<?php inventory_display($fld_total_amount)?>" readonly required="" type="text" class="form-control" name="total_amount" id="total_amount" style="text-align:right;"/></td>
			                        
			                    </tr>
			                </tbody>
			            </table>
                        </div>
                    </div>
                    
                    
                    
                </div>
                 
                 <!--<input type="hidden" name = "user_ai_id" value="<?php inventory_display(track64_encode($user_ai_id))?>"/>-->
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<input type="hidden" value="" id="itemid">
						<!--<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-primary" name="draft_indent">Save to Draft</button>
						&nbsp;&nbsp;&nbsp;&nbsp;
						<button type="submit" id="oredadd" class="mb-1 mt-1 mr-1 btn btn-success" name="add_indent">Final Submit</button>-->
					</div>
				</div>
            </form>
        </div>
     </section> 
<?php } ?>

<script>
  
	function getitemdetails(){
	//alert('gg');
	var item=$("#item").val();
	if(item=="" || item==null){
		$("#item-error").text("Select any item from list");
		$("#oredadd").attr("disabled",true);
	}else{
		$("#item-error").text("");
		$("#oredadd").removeAttr("disabled");
		var itemid=$("#itemid").val();
		if(itemid=="" || itemid==null){
			var itemidsplit=[];
			itemidsplit.push(item+",");
			 var itemidsplitsrn=itemidsplit.toString();
  					    $("#itemid").val(itemidsplitsrn);
			//nsole.log('mmmm');
			var ki=0
			//emidsplit.push(item);
			//itemid.push(item);
		}else{
			var itemidsplit=itemid.split(",");
			var ki=1;
		}
		var tbl="";
			
			
			var flag=0;
			
			$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/getiteminfo.php",
  			data :{'item':item},
  			success : function(data){
  				//alert(data);
  				var json=JSON.parse(data);
  				
  				var fld_name=json.fld_name;
  				var fld_unit=json.fld_unit;
  				var fld_price=json.fld_price;
  				var stock_qty=json.stock_qty;
  				var tax=json.tax;
  				
  				tbl +='<tr>';
				tbl +='<td><button type="button" class="mb-1 mt-1 mr-1 btn btn-primary" id="newrow_1" onclick="addnewrow(this.id)"><i class="fa fa-plus" aria-hidden="true"></i></button</td>';
				tbl +='<td>'+fld_name+'</td>';
				tbl +='<td><input type="text" name="qty" class="form-control" style="width:100px;" onblur="getgross_total()"/></td>';                        
				tbl  +=' <td>'+fld_unit+'</td>' ;                   
				tbl +='<td>'+stock_qty+'</td>'  ; 
				tbl +='<td>'+fld_price+'</td>';
				tbl +='<td><input type="text" class="form-control" style="width:100px;" readonly name="gross" id="gross"/></td>';
				tbl +='<td>'+tax+'</td>' ; 
				tbl +='<td><input type="text" class="form-control" style="width:100px;" readonly name="total" id="total"/></td>' ;  
				tbl +='</tr>' ; 
  				$("#itemdetailsnn").append(tbl);
  				/*if(itemidsplit.indexOf(item)== -1){
  				 console.log("k");
  					
  						
  				}else{
  					if(ki==1){
  					itemidsplit.push(item+",");
  					    var itemidsplitsrn=itemidsplit.toString();
  					    $("#itemid").val(itemidsplitsrn);
  					}
  				}
  					
  					*/
  					
  					
  					
  					
  					
  				}
  				//alert(json);
  				//console.log(data);
				//$("#adjust").val(data);
  			  
              // 
           });                    
			                       
			                 
		
		
		
		
	}
}
function getsubcategory(id){
	
	var idsplit=id.split("_");
	var product_item=$("#category_"+idsplit[1]).val();
	$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getsubcategory.php",
  			data :{'product_item':product_item},
  			success : function(data){
  				
  					//console.log(data);
  					$("#subcategory_"+idsplit[1]).html(data);
  					$("#item_"+idsplit[1]).html("<option value=''>--select--</option>");
  				}
  			
           });         
	
	
}
function getitem(id){
	
	var idsplit=id.split("_");
	var categ=$("#category_"+idsplit[1]).val();
	var subcateg=$("#subcategory_"+idsplit[1]).val();
	$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getitem.php",
  			data :{'categ':categ,'subcateg':subcateg},
  			success : function(data){
  				
  					console.log(data);
  					$("#item_"+idsplit[1]).html(data);
  				}
  			
           });   
}

function addnewrow(id){
	var idsplit=id.split("_");
	var rowCount = $('#itemdetailsnn tr').length;
	//alert(rowCount);
	
	var newunid=parseInt(rowCount)+1;
	var categ=1;
	var subcateg=2;
	var tbl="";
	$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getcategory.php",
  			data :{'categ':categ,'subcateg':subcateg},
  			success : function(data){
  				
  					//console.log(data);
  					//$("#item_"+idsplit[1]).html(data);
  					var json=JSON.parse(data);
  					
  					var catg=json.reslt;
  					var res2=json.res2;
  					tbl +='<tr id="rowid_'+newunid+'">';
					tbl +='<td><a href="javascript:void(0)" id="newrow_'+newunid+'" onclick="addnewrow(this.id)"><i class="fa fa-plus" aria-hidden="true"></i></a>';
					tbl +='&nbsp;&nbsp;<a href="javascript:void(0" id="deletenewrow_'+newunid+'" onclick="deletenewrow(this.id)"><i class="fa fa-trash" aria-hidden="true"></i></a></td>';
					tbl +='<td><select class="form-control" id="category_'+newunid+'" name="category_'+newunid+'" onchange="getsubcategory(this.id);">'+catg+'</select></td>';
					tbl +='<td><select class="form-control" id="subcategory_'+newunid+'" name="subcategory_'+newunid+'" onchange="getitem(this.id);"><option value="">--Select--</option></select></td>';                        
					tbl  +=' <td><select class="form-control" id="item_'+newunid+'" name="item_'+newunid+'" onchange="getitemdetailsinfo(this.id)"><option value="">--Select--</option></select></td>' ;                   
					tbl +='<td><input style="width:50px;" type="text" onblur="gettotalvalproduct(this.id);" class="form-control" name="qty_'+newunid+'" id="qty_'+newunid+'" style="width:80px" ></td>'  ; 
					tbl +='<td><div id="divqty_'+newunid+'" style="width:40px;"></div></td>';
					tbl +='<td><input style="width:80px;" type="text" readonly class="form-control" name="price_'+newunid+'" id="price_'+newunid+'" style="width:100px" ></td>';
					tbl +='<td><input style="width:80px;" type="text" readonly class="form-control" name="gross_'+newunid+'" id="gross_'+newunid+'" style="width:100px" ></td>' ; 
					//tbl +='<td><select class="form-control" id="tax_'+newunid+'" name="tax_'+newunid+'" onchange="gettaxcal(this.id);">'+res2+'</select></td>' ; 
					tbl +='<td>	<input style="width:80px;" type="text" readonly class="form-control" name="tax_'+newunid+'" id="tax_'+newunid+'" style="width:100px"  ></td>';
					tbl +='<td><input style="width:80px;" readonly type="text" readonly class="form-control" name="totar_'+newunid+'" id="totar_'+newunid+'" style="width:100px;text-align:right;" ></td>' ;  
					tbl +='</tr>' ; 
					
					$("#itemdetailsnn").append(tbl);
					$("#totalrow").val(newunid);
					
  					
  					
  				}
  			
           }); 
	
	
	
	
	      
	
	
}

function deletenewrow(id){
	var idsplit=id.split("_");
	var rowCount = $('#itemdetailsnn tr').length;
	//alert(rowCount);
	
	//var newunid=parseInt(rowCount)+1;
	
	if(confirm('Are you sure')==true){
				var rowCount = $('#itemdetailsnn tr').length;
			    $("#rowid_"+idsplit[1]).remove();
			    var rowCount = $('#itemdetailsnn tr').length;
			    $("#totalrow").val(rowCount);
			    
			}
	
	
}
function getitemdetailsinfo(id){
	var idsplit=id.split("_");
	
	var itemcode=$("#item_"+idsplit[1]).val();
	//alert('hh');
	$.ajax({			
 			type :"POST",
  			url : "<?php inventory_display(ROOT_PATH)?>/jquery_ajax/getiteminfodet.php",
  			data :{'itemcode':itemcode},
  			success : function(data){
  				
  				  var json=JSON.parse(data);
  				  var pric=json.fld_price;
  				  var fld_unit=json.fld_unit;
  				  var taxval=json.fld_tax;
  				   $("#price_"+idsplit[1]).val(pric);
  				   $("#divqty_"+idsplit[1]).text(fld_unit);
  				   $("#tax_"+idsplit[1]).val(taxval)
  				   
  					//gettaxcal(id)
  				}
  			
           }); 
	
	
	
	
}
function gettotalvalproduct(id){
	var idsplit=id.split("_");
	var itemcode=$("#item_"+idsplit[1]).val();
	var gross=0;
	var total=0;
	var totaltax=0;
	var totalamount=0;
	var totar=0;
	
	var total_tax=$("#total_tax").val();
	if(total_tax=="" || total_tax==null){
		totaltax=0;
	}else{
		totaltax=$("#total_tax").val();
	}
	
	var rowCount = $('#itemdetailsnn tr').length;
	if(itemcode==null || itemcode==""){
		alert('please select Item from left');
	}else{
		
		var qty=$("#qty_"+idsplit[1]).val();
		var price=$("#price_"+idsplit[1]).val();
		var tax=$("#tax_"+idsplit[1]).val();
		
		gross=parseFloat(qty)*parseFloat(price);
		if(tax=="" || tax==null){ tax=0; }else{ tax=(parseFloat(gross)*parseFloat(tax)*2)/100 }
		totar=gross+tax;
		console.log(totar);
		for($ik=1;$ik<=rowCount;$ik++){
			total=total+($("#price_"+$ik).val()*$("#qty_"+idsplit[1]).val());
		}
		
		totalamount=totalamount+total;
		
		$("#gross_"+idsplit[1]).val(gross.toFixed(2));
		$("#total").val(total.toFixed(2));
		$("#totar_"+idsplit[1]).val(totar.toFixed(2));
		$("#total_amount").val(totalamount.toFixed(2));
		gettaxcal(id);
	}
	
}
function gettaxcal(id){
	var idsplit=id.split("_");
	var itemcode=$("#item_"+idsplit[1]).val();
	var gross=0;
	var total=0;
	var totaltax=0;
	var totalamount=0;
	var totar=0;
	
	var rowCount = $('#itemdetailsnn tr').length;
	if(itemcode==null || itemcode==""){
		alert('please select Item from left');
	}else{
		
		var qty=$("#qty_"+idsplit[1]).val();
		var price=$("#price_"+idsplit[1]).val();
		var tax=$("#tax_"+idsplit[1]).val();
		
		gross=parseFloat(qty)*parseFloat(price);
		if(tax=="" || tax==null){ tax=0; }else{ tax=(parseFloat(gross)*parseFloat(tax)*2)/100 }
		totar=gross+tax;
		console.log(totar);
		for(var ik=1;ik<=rowCount;ik++){
			
			totaltax=totaltax+($("#price_"+ik).val()*$("#qty_"+ik).val()*$("#tax_"+ik).val() *2)/100;
			total=total+($("#price_"+ik).val()*$("#qty_"+ik).val())+($("#price_"+ik).val()*$("#qty_"+ik).val()*$("#tax_"+ik).val() *2)/100;
		}
		
		totalamount=totalamount+total;
		
		$("#gross_"+idsplit[1]).val(gross.toFixed(2));
		$("#total").val(total.toFixed(2));
		$("#total_tax").val(totaltax.toFixed(2));
		$("#totar_"+idsplit[1]).val(totar.toFixed(2));
		$("#total_amount").val(totalamount.toFixed(2));
	}
	
	
}
</script>
