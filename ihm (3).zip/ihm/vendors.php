<?php include('action/vendor_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>
<?php if($case == "list"){ 
	//echo $list;
	?>
	
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		<?php
        		   if($user_type != 'admin' || $user_type != 'hod'){
						
					}else{ ?>
						<a class="btn custom_border" href="<?php inventory_display(ROOT_PATH)?>/addvendor"><i class="fa fa-plus" aria-hidden="true"></i> Add Vendor</a>
						
				<?php 	} ?>
        		
				
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Vendor List</h2>
        </header>
        <div class="card-body">
        	 <table class="table table-bordered table-striped mb-0" id="datatable_with_search">
                <thead>
                    <tr>
                    	<th>Vendor ID</th>
                    	<th>Company Name</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Products</th>
                        <th>GST NO</th>
                        
                        <th>Status</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "add"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> Add Vendor</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="add_ven_form" action = "<?php inventory_display(ROOT_PATH)?>/addvendor" >
            	     <?php  
            	     $select_department_query = "SELECT * FROM `tbl_vendor` order by fld_ai_id desc limit 1";
		            $select_department_query_result = inventory_query($select_department_query);
            	    $row_data = inventory_fetch_assoc($select_department_query_result);
            	    if(!empty($row_data) && isset($row_data)){
            	         $idn=$row_data['fld_vn_id'];
            	         $newidn=intval($idn)+1;
            	        
            	    }else{
            	        
            	        // $idn=$row_data['fld_ai_id'];
            	         $newidn=1001;
            	    }
            	   
            	     
            	     ?>
                    
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Vendor Id<span class="required">*</span></label>
                    <div class="col-lg-6">
                         <input type="text" readonly="readonly" required="" class="form-control" id="ven_id" name = "ven_id" value="<?php echo  $newidn ; ?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Company Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" required="" class="form-control" id="ven_name" name = "ven_name" value="<?php inventory_display($ven_name)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Contact Person<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" required="" class="form-control" id="ven_person" name = "ven_person" value="<?php inventory_display($ven_person)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Address<span class="required">*</span></label>
                    <div class="col-lg-6">
                       
                        <textarea class="form-control"  name = "ven_address" ><?php inventory_display($ven_address)?></textarea>
                    </div>
                </div>
               
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Phone<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="number" required="" class="form-control" id="ven_phone" name = "ven_phone" value="<?php inventory_display($ven_phone)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">GST NO</label>
                    <div class="col-lg-6">
                        <input type="text" required="" class="form-control" id="ven_gst" name = "ven_gst" value="<?php inventory_display($ven_gst)?>">
                    </div>
                </div>
                 <!--<div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Products<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <?php
                        $sql="select * from tbl_item where fld_is_active='1'";
						$qry = inventory_query($sql); 
						$q=1;
			   			while($res=inventory_fetch_assoc($qry)){
			   				if($q==1){
			   					echo '<input type="checkbox" name="products[]" value="'.$res['fld_name'].'" checked>'. $res['fld_name'].'<br>';
			   				}else{
			   					echo '<input type="checkbox" name="products[]" value="'.$res['fld_name'].'" >'. $res['fld_name'].'<br>';
			   				}
							 $q++;
			   			}
						//$qry=mysqli_
                        
                        ?>
                    </div>
                </div>-->
                 
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_ven">Add Vendor</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>
<?php if($case == "edit"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Vendor</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="add_ven_form" action = "<?php inventory_display(ROOT_PATH)?>/updatevendor" >
            	 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Vendor Id<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" readonly="readonly" required="" class="form-control" id="ven_id" name = "ven_id" value="<?php inventory_display($ven_id)?>">
                        <input type="hidden" name="venidd" value="<?php echo $vdd; ?>"/>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Company Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" required="" class="form-control" id="ven_name" name = "ven_name" value="<?php inventory_display($ven_name)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Contact Person<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" required="" class="form-control" id="ven_person" name = "ven_person" value="<?php inventory_display($ven_person)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Address<span class="required">*</span></label>
                    <div class="col-lg-6">
                        
                        <textarea class="form-control"  name = "ven_address" ><?php inventory_display($ven_address)?></textarea>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Phone<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="number" required="" class="form-control" id="ven_phone" name = "ven_phone" value="<?php inventory_display($ven_phone)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">GST NO</label>
                    <div class="col-lg-6">
                        <input type="text" required="" class="form-control" id="ven_gst" name = "ven_gst" value="<?php inventory_display($ven_gst)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Products<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <?php
                        $sql="select * from tbl_item where fld_is_active='1'";
						$qry = inventory_query($sql); 
						$q=1;
						$productsex=explode(",",$products);
			   			while($res=inventory_fetch_assoc($qry)){
			   				
			   				if($q==1){
			   					if(in_array($res['fld_name'], $productsex)){
			   						echo '<input type="checkbox" name="products[]" value="'.$res['fld_name'].'" checked >'. $res['fld_name'].'<br>';
			   					}else{
			   						echo '<input type="checkbox" name="products[]" value="'.$res['fld_name'].'" >'. $res['fld_name'].'<br>';
			   					}
			   					
			   				}else{
			   					if(in_array($res['fld_name'], $productsex)){
			   						echo '<input type="checkbox" name="products[]" value="'.$res['fld_name'].'" checked >'. $res['fld_name'].'<br>';
			   					}else{
			   						echo '<input type="checkbox" name="products[]" value="'.$res['fld_name'].'" >'. $res['fld_name'].'<br>';
			   					}
			   				}
							 $q++;
			   			}
						//$qry=mysqli_
                        
                        ?>
                    </div>
                </div>
                 
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="update_ven">Update Vendor</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>