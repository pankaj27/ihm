<?php
include('include/config.php');
include('include/db.php');
//echo 'hello';
$itemid=$_POST['item'];

$query=mysqli_query($con,"select * from tbl_item where fld_ai_id='".trim($itemid)."'");
$res=mysqli_fetch_array($query);
$fld_name=$res['fld_name'];
//$fldid=
$fld_unit=$res['fld_unit'];
$fld_price=$res['fld_price'];
$stock_qty=$res['stock_qty'];

///get tax rate

$qry2=mysqli_query($con,"select * from tbl_tax where fld_is_active='1'");
$slct="";
$slct .="<select class='form-control' id='taxcal' onchange='gettax_rate_calc()' style='width:150px;'>";
$slct .="<option value=''>--select--</option>";
while($res2=mysqli_fetch_array($qry2)){
	$slct .='<option value="'.$res2['fld_sgst'].'">SGST'.$res2['fld_sgst']."+ CGST".$res2['fld_sgst'].'</option>';
}

$slct .="</select>";

$rest=array("fld_name"=>"$fld_name","fld_unit"=>"$fld_unit","fld_price"=>"$fld_price","stock_qty"=>"$stock_qty","tax"=>"$slct");
echo json_encode($rest)

?>