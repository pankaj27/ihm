<section class="body-error error-inside">
	<div class="center-error">

		<div class="row">
			<div class="col-lg-12">
				<div class="main-error mb-3">
					<h5 class="error-code text-dark text-center font-weight-semibold m-0">No Permission Page <i class="fa fa-lock"></i></h5>
				</div>
			</div>
		</div>
	</div>
</section>