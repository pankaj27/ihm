<?php include('action/departments_action.php') ?>
<?php if(isset($succee_msg) && $succee_msg != "") {?><div class="alert alert-success"><?php inventory_display($succee_msg);?></div><?php } ?>
<?php if(isset($error_msg) && $error_msg != "") {?><div class="alert alert-danger"><?php inventory_display($error_msg);?></div><?php } ?>
<?php if($case == "list"){ ?>
	<section class="card">
        <header class="card-header">
        	<div class="card-actions-custom">
        		<?php
        			if($deep_w==0){  }else{ ?>
						
						<a class="btn custom_border" href="<?php inventory_display(ROOT_PATH)?>/adddepartment"><i class="fa fa-plus" aria-hidden="true"></i> Add Department</a>
			    <?php } ?>
        		
        		
				
			</div>
            <h2 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> Department List</h2>
        </header>
        <div class="card-body">
        	 <table class="table table-bordered table-striped mb-0" id="datatable_with_search">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Department Id</th>
                        <th>Section</th>
                        <th>Status</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php inventory_display($list);?>
                </tbody>
            </table>
        </div>
    </section>
<?php } ?>
<?php if($case == "add"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> Add Department</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="add_department_form" action = "<?php inventory_display(ROOT_PATH)?>/adddepartment" >
            	 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Department Id<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="dept_id" name = "dept_id" value="<?php inventory_display($dept_id)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Department Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="dept_name" name = "dept_name" value="<?php inventory_display($dept_name)?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Choose Section<span class="required">*</span></label>
                    <div class="col-lg-6">
                    	<?php
                            		  $select_semester_query2 = "SELECT * FROM  tbl_section ";
							        $select_semester_query_result2 = inventory_query($select_semester_query2); 
									//$row_data112 = inventory_fetch_assoc($select_semester_query_result2);
                            	//echo $semester;
                        ?>
                        <?php  if(inventory_num_rows($select_semester_query_result2)>0){
                               		while($row_data2 = inventory_fetch_assoc($select_semester_query_result2)){
                               	?>	
									<input type="checkbox"   name = "section[]" value="<?php echo $row_data2['fld_ai_id']; ?>"><?php echo $row_data2['fld_category'] ; ?> &nbsp;
									
									<?php   }	} ?>
                        
                    </div>
                </div>
                <div class="form-group row">
				
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="add_department">Add Department</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>
<?php if($case == "edit"){ ?>
	<section class="card">
        <header class="card-header">
            <h2 class="card-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Department</h2>
        </header>
        <div class="card-body">
        	<form class="form-horizontal form-bordered" method="post" id="edit_department_form" action = "<?php inventory_display(ROOT_PATH)?>/updatedepartment" >
            	 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Department Id<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="dept_id" name = "dept_id" value="<?php inventory_display($dept_id)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Department Name<span class="required">*</span></label>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" id="dept_name" name = "dept_name" value="<?php inventory_display($dept_name)?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label class="col-lg-3 control-label text-lg-right pt-2" for="name">Choose Section<span class="required">*</span></label>
                    <div class="col-lg-6">
                    	<?php
                    	   $seccc=explode(",",$row_data['section']);
                            		  $select_semester_query2 = "SELECT * FROM  tbl_section ";
							        $select_semester_query_result2 = inventory_query($select_semester_query2); 
									//$row_data112 = inventory_fetch_assoc($select_semester_query_result2);
                            	//echo $semester;
                        ?>
                        <?php if(inventory_num_rows($select_semester_query_result2)>0){
                               		while($row_data2 = inventory_fetch_assoc($select_semester_query_result2)){
                               	?>	
									<input type="checkbox"   name = "section[]" value="<?php echo $row_data2['fld_ai_id']; ?>" <?php if(in_array($row_data2['fld_ai_id'],$seccc)){ echo "checked"; }  ?>><?php echo $row_data2['fld_category'] ; ?> &nbsp;
									
                       <?php  }	} ?>
                        
                    </div>
                </div>
                <input type="hidden" name="department_id" value="<?php inventory_display(track64_encode($department_id))?>">
                <div class="form-group row">
					<div class="col-md-12 align_center">
						<button type="submit" class="mb-1 mt-1 mr-1 btn btn-primary" name="edit_department">Edit Department</button>
					</div>
				</div>
            </form>
        </div>
    </section>
<?php } ?>