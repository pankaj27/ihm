<?php
				 
$_SESSION['mail_query'] = "";
function inventory_include($file_name){	return include_once($file_name);}

function error_handling($msg = ''){	if($msg == "") 	echo "Connection problem , Please try again";	else 	echo $msg;	}
# Database query
function inventory_escape($string){inventory_debug(__LINE__,__FILE__,__FUNCTION__);global $con;return mysqli_real_escape_string($con,$string);}
function inventory_trim($value){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return trim($value," ");}
function inventory_fetch_array($value){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return mysqli_fetch_array($value);}
function inventory_fetch_assoc($result){inventory_debug(__LINE__,__FILE__,__FUNCTION__);global $con;return mysqli_fetch_assoc($result);}
function inventory_query($query){inventory_debug(__LINE__,__FILE__,__FUNCTION__);inventory_print_query(__LINE__,__FILE__,$query);global $con;return mysqli_query($con,$query);}
function inventory_num_rows($result){global $con;$rows = mysqli_num_rows($result);inventory_debug(__LINE__,__FILE__,__FUNCTION__); return $rows;}
function inventory_last_inserted(){inventory_debug(__LINE__,__FILE__,__FUNCTION__);global $con;return mysqli_insert_id($con);}
function find_position($string, $findme){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return strpos($string, $findme);}
function inventory_affected_rows(){global $con;$rows = mysqli_affected_rows($con); inventory_debug(__LINE__,__FILE__,__FUNCTION__); return $rows;}
function inventory_is_numeric($value){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return is_numeric($value);}
function inventory_commit_off(){global $con;mysqli_autocommit($con, FALSE); }
function inventory_commit_on(){global $con;mysqli_autocommit($con, TRUE); }
function inventory_commit(){global $con;mysqli_commit($con);}
function inventory_rollback(){global $con;mysqli_rollback($con);}
function inventory_upper($value){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return strtoupper($value);}
function inventory_date_function($date){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return $date;}
function inventory_email_function($email){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return $email;}
function inventory_phone_function($phone){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return $phone;}
function inventory_file_put_content($folder, $content)
{
	file_put_contents($folder."/".date('d-m-Y',time())."testFile.txt",date('d-m-Y H:i:s a',time())." ".print_r($content,true)."<br/>",FILE_APPEND);
	inventory_debug(__LINE__,__FILE__,__FUNCTION__);
	return true;
}
function inventory_remove_nonprintable_chars($string){ return preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $string);}

# Initialize session data
function inventory_start_session() {session_start();}
function inventory_set_session( $session_name,$session_value ){inventory_debug(__LINE__,__FILE__,__FUNCTION__,$session_name); $_SESSION[$session_name] = $session_value;}
function inventory_get_session($session_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return $_SESSION[$session_name];}
function inventory_session_isset($session_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return isset($_SESSION[$session_name]);}
function inventory_unset_session($session_name){	unset($_SESSION[$session_name]);}
function inventory_close_session(){	session_close();}		  
#session function end
function inventory_hsaspecialcharacter($string){if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $string)){return true;}else{return false;}}
function inventory_validation($string,$blank,$max,$min,$nospace,$nospecialch,$alphaonly,$numberonly,$field_name){
	if($blank){
		if($string == ""){
			return BLANK_FIELDS.$field_name;
		}
	}
	if(strlen($string) <$min){
			return "Please enter at least ".$min." characters in ".$field_name;
	}
	if(strlen($string) >$max){
			return "Please enter no more than ".$max." characters in ".$field_name;
	}
	if($nospecialch){
		if(inventory_hsaspecialcharacter($string)){
			return SPECIAL_CHARS. $field_name;
		}
	}
	if($nospace){
		if(preg_match('/\s/',$string)){
			return "No space please and don't leave it empty in ".$field_name;	
		}
	}
	if($alphaonly){
		if (!preg_match('/^[a-zA-Z ]+$/i', $string)) {
			return "Please enter only letters in ".$field_name;	
		}
	}
	if($numberonly){
		if (!is_numeric($string)) {
			return "Please enter only numeric value in ".$field_name;	
		}
	}
	return "";
	
}
function inventory_time_format_check($time){
	
	if(strlen($time) == 4)
	{
		$time = "0".$time;
	}
	return preg_match("/(2[0-3]|[01][0-9]):([0-5][0-9])/", $time)."";

};//HH:MM
function inventory_getLatLong($address, $state){
	$data = array();
    if(!empty($address)){
        //Formatted address
        $formattedAddr = urlencode(str_replace(' ','+',$address));
		
        //Send request and receive json data by address
        $geocodeFromAddr = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address='.$formattedAddr.'&sensor=false&key=AIzaSyCvt9EkhVeANMe224B5oTDC76YskzQKaPk'); 
        $output = json_decode($geocodeFromAddr);
	

		if (!empty($output->results)) {
		
				//Get latitude and longitute from json data
				$data['latitude']  = $output->results[0]->geometry->location->lat; 
				$data['longitude'] = $output->results[0]->geometry->location->lng;
				//Return latitude and longitude of the given address
		}
       
    }
	
	if((empty($address)) || (empty($data))){
		$state = urlencode(str_replace(' ','+',$state));
		$url = 'https://maps.googleapis.com/maps/api/geocode/json?address='.$state.'&sensor=false&key=AIzaSyCvt9EkhVeANMe224B5oTDC76YskzQKaPk';	
		
        $geocodeFromAddr = file_get_contents($url); 
      		 $output = json_decode($geocodeFromAddr);	
			
			 if (!empty($output->results)) {
		
					//Get latitude and longitute from json data
					$data['latitude']  = $output->results[0]->geometry->location->lat; 
					$data['longitude'] = $output->results[0]->geometry->location->lng;
					
					//Return latitude and longitude of the given address
			}else{
					return false;	
			}   
    }
	
	 if(!empty($data)){
            return $data;
		}else{
			return false;
		}
}
function inventory_gmt_datetime(){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return gmdate('Y-m-d H:i:s');}
function inventory_today_date(){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return date('Y-m-d H:i:s');}
function inventory_yesterday_date(){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return date("Y-m-d", strtotime("yesterday"));}
function inventory_yesterday_date_for_datepicker(){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return date("m/d/Y", strtotime("yesterday"));}
function inventory_display($content){ echo $content;}
function inventory_html_display($content){ echo $content;}
function inventory_strip($str){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return stripslashes($str);}
function inventory_hash($content)	{$output =sha1($content);	if(!$output) {inventory_display("error in hashing md5 input "."\r\n"); } else { inventory_debug(__LINE__,__FILE__,__FUNCTION__);return $output;}}

# Post function
function inventory_get_post_escape($post_name){	inventory_debug(__LINE__,__FILE__,__FUNCTION__);global $con;return mysqli_real_escape_string($con,trim($_POST[$post_name]," "));	}
function inventory_get_post($post_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return $_POST[$post_name];	}
function inventory_get_files($post_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return $_FILES[$post_name];	}
function inventory_post_isset($post_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__); return isset($_POST[$post_name]);}
function inventory_all_post(){inventory_debug(__LINE__,__FILE__,__FUNCTION__); return $_POST;}
function inventory_get_user_browser(){ inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return $_SERVER['HTTP_USER_AGENT'];}
function inventory_ucwords($value){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return  ucwords($value); }
#End post function
function inventory_debug($line_number,$file_name,$function,$var = NULL)
{
	$somecontent = "[".date('Y-m-d H:i:s')."]  \t ".$file_name."\t".$function."\t Line_number:".$line_number."\t".$var."\r\n";
	$filename = dirname(__FILE__) . '/debug_log.txt';
	if (!$handle = fopen($filename, 'a')) {
         echo "Cannot open file ($filename)";
         exit;
    }

    if (fwrite($handle, $somecontent) === FALSE) {
        echo "Cannot write to file ($filename)";
        exit;
    }
}
function inventory_print_post_data($content,$page)
{
	
		$somecontent = "[".date('Y-m-d H:i:s')."]  \n".print_r($content,true)."\r\n";
		/*echo(dirname(__FILE__));
		
		file_put_contents('./filename_2.txt', dirname(__FILE__));
*/
		$filename = dirname(__FILE__) . '/app_post_data/'.$page.date('Y-m-d').'.txt';
		if (!$handle = fopen($filename, 'a')) {
			 echo "Cannot open file ($filename)";
			 exit;
		}
	
		if (fwrite($handle, $somecontent) === FALSE) {
			echo "Cannot write to file ($filename)";
			exit;
		}
	
}
function inventory_print_send_data($content,$page)
{
	
		$somecontent = "[".date('Y-m-d H:i:s')."]  \n".print_r($content,true)."\r\n" ;
		$filename = dirname(__FILE__) . '/app_send_data/'.$page.date('Y-m-d').'.txt';
		if (!$handle = fopen($filename, 'a')) {
			 echo "Cannot open file ($filename)";
			 exit;
		}
	
		if (fwrite($handle, $somecontent) === FALSE) {
			echo "Cannot write to file ($filename)";
			exit;
		}
	
}
function inventory_print_otp_log($content)
{
	
		$somecontent = "[".date('Y-m-d H:i:s')."]  \n".$content."\r\n";
		
		$filename = dirname(__FILE__) . '/app_otp_log/'.date('Y-m-d').'.txt';
		if (!$handle = fopen($filename, 'a')) {
			 echo "Cannot open file ($filename)";
			 exit;
		}
	
		if (fwrite($handle, $somecontent) === FALSE) {
			echo "Cannot write to file ($filename)";
			exit;
		}
	
}
inventory_url_log();
function inventory_url_log()
{
		$somecontent = "[".date('Y-m-d H:i:s')."]  \t ".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."\r\n";
		$filename = dirname(__FILE__) . '/url_log/'.date('Y-m-d').'.txt';
		if (!$handle = fopen($filename, 'a')) {
			 echo "Cannot open file ($filename)";
			 exit;
		}
	
		if (fwrite($handle, $somecontent) === FALSE) {
			echo "Cannot write to file ($filename)";
			exit;
		}
	
}
function inventory_print_query($line_number,$file_name,$query)
{
	
		$somecontent = "[".date('Y-m-d H:i:s')."]  \t ".$file_name."\t Line_number:".$line_number."\t".$query."\r\n";
		$filename = dirname(__FILE__) . '/query_log/'.date('Y-m-d').'.txt';
		if (!$handle = fopen($filename, 'a')) {
			 echo "Cannot open file ($filename)";
			 exit;
		}
	
		if (fwrite($handle, $somecontent) === FALSE) {
			echo "Cannot write to file ($filename)";
			exit;
		}
	
}

function inventory_debug_print($var, $print_stack = 0, $exit_here = 0){
	
	if(1 == $print_stack) 
	{
		var_dump(debug_backtrace());
	}
	if(1 == $exit_here)
	{
		exit();
	}
}
function inventory_json_encode($string){ inventory_debug(__LINE__,__FILE__,__FUNCTION__);return json_encode($string);}
function track64_encode($string){ inventory_debug(__LINE__,__FILE__,__FUNCTION__);return base64_encode($string);}
function track64_decode($string){ inventory_debug(__LINE__,__FILE__,__FUNCTION__);return base64_decode($string);}
#Cookie handler functions
function inventory_cookie_isset($cookie_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return isset($_COOKIE[$cookie_name]);}
function inventory_get_cookie($cookie_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return $_COOKIE[$cookie_name];}
#End cookie handler functions

# Get function
function inventory_get_get($get_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__); global $con; return mysqli_real_escape_string($con,trim($_GET[$get_name]));	}
function inventory_get_isset($get_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return isset($_GET[$get_name]);}
#End get function

# Request function
function inventory_get_request($request_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return $_REQUEST[$request_name];	}
function inventory_request_isset($request_name){inventory_debug(__LINE__,__FILE__,__FUNCTION__,$request_name);	return isset($_REQUEST[$request_name]);}
#End request function

#Get the ip address of the visitor's machine
function inventory_get_ip(){ inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return $_SERVER["REMOTE_ADDR"]; }
#End

#Page redirect
function inventory_redirect($url){inventory_debug(__LINE__,__FILE__,__FUNCTION__);return (header('Location: '.$url));	}

#Return number of element in the array
function inventory_array_count($ar_data){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	 return count($ar_data);}
#End
function inventory_log($place,$message,$type)
{
	$admin_id = "";
	if(inventory_session_isset(VARIABLE_PREFIX."admin_id"))
		$admin_id = inventory_get_session(VARIABLE_PREFIX."admin_id");
	return inventory_query("INSERT INTO `log`  (admin_id,ip,`text`,place,`type`) VALUES ('".$admin_id."','".$_SERVER['REMOTE_ADDR']."','".$message."',".$place.",'".$type."')");
}
function genRandomString() {
	$length=6;
	if($length>0) 
	{ 
		$rand_id="";
	   	for($i=1; $i<=$length; $i++)
	   	{
	   		mt_srand((double)microtime() * 1000000);
	   		$num = mt_rand(1,36);
	   		$rand_id .= assign_rand_value($num);
	   	}
	}
	return $rand_id;
}
function inventory_genRandomString_for_number_only($length) {
	if($length>0) 
	{ 
		$rand_id="";
	   	for($i=1; $i<=$length; $i++)
	   	{
	   		mt_srand((double)microtime() * 1000000);
	   		$num = mt_rand(27,36);
	   		$rand_id .= assign_rand_value($num);
	   	}
	}
	return $rand_id;
}
function inventory_substring($string,$value){ inventory_debug(__LINE__,__FILE__,__FUNCTION__);return substr($string,$value);}
function inventory_array_search($search_str, $array){ 
	if(array_search($search_str, $array) !== FALSE)
	{return true;}
	else {return false;
	}
}

function inventory_array_key_search($search_str, $array){ 
	return (array_search($search_str, $array));
	
}
function inventory_array_key_exists($search_str, $array){ return array_key_exists($search_str, $array);}

function inventory_in_array($value, $arr){return in_array($value, $arr);}

# desc: Get user type list
# param: user type array, and profile type id (oprtion for exit profile)
# returns: string
// <?php if( isset($_COOKIE['username']) )  echo $_COOKIE['username']; 

function inventory_set_cookie($cookie_name, $cookie_value, $time_days)
{
$time = time()+60*60*24*$time_days  ;
setcookie($cookie_name, $cookie_value, $time);
}

function inventory_has_access($page)
{
	$level = inventory_get_session(VARIABLE_PREFIX."level");
	$query = "SELECT ".$page." FROM admin_permissions WHERE ai_serial_no = ".$level;
	$result = inventory_query($query);
	$row = inventory_fetch_assoc($result);
	return $row[$page];
}

function assign_rand_value($num)
{
// accepts 1 - 36
  switch($num)
  {
    case "1":
     $rand_value = "a";
    break;
    case "2":
     $rand_value = "b";
    break;
    case "3":
     $rand_value = "c";
    break;
    case "4":
     $rand_value = "d";
    break;
    case "5":
     $rand_value = "e";
    break;
    case "6":
     $rand_value = "f";
    break;
    case "7":
     $rand_value = "g";
    break;
    case "8":
     $rand_value = "h";
    break;
    case "9":
     $rand_value = "i";
    break;
    case "10":
     $rand_value = "j";
    break;
    case "11":
     $rand_value = "k";
    break;
    case "12":
     $rand_value = "l";
    break;
    case "13":
     $rand_value = "m";
    break;
    case "14":
     $rand_value = "n";
    break;
    case "15":
     $rand_value = "o";
    break;
    case "16":
     $rand_value = "p";
    break;
    case "17":
     $rand_value = "q";
    break;
    case "18":
     $rand_value = "r";
    break;
    case "19":
     $rand_value = "s";
    break;
    case "20":
     $rand_value = "t";
    break;
    case "21":
     $rand_value = "u";
    break;
    case "22":
     $rand_value = "v";
    break;
    case "23":
     $rand_value = "w";
    break;
    case "24":
     $rand_value = "x";
    break;
    case "25":
     $rand_value = "y";
    break;
    case "26":
     $rand_value = "z";
    break;
    case "27":
     $rand_value = "0";
    break;
    case "28":
     $rand_value = "1";
    break;
    case "29":
     $rand_value = "2";
    break;
    case "30":
     $rand_value = "3";
    break;
    case "31":
     $rand_value = "4";
    break;
    case "32":
     $rand_value = "5";
    break;
    case "33":
     $rand_value = "6";
    break;
    case "34":
     $rand_value = "7";
    break;
    case "35":
     $rand_value = "8";
    break;
    case "36":
     $rand_value = "9";
    break;
  }
  inventory_debug(__LINE__,__FILE__,__FUNCTION__);
return $rand_value;
}

function get_rand_id($length)                                     
{
 	if($length>0) 
  	{ 
 		$rand_id="";
	   	for($i=1; $i<=$length; $i++)
	   	{
		   mt_srand((double)microtime() * 1000000);
		   $num = mt_rand(1,36);
		   $rand_id .= assign_rand_value($num);
	   	}
  	}
  	inventory_debug(__LINE__,__FILE__,__FUNCTION__);
	return $rand_id;                                                      
}

function isValidEmail($Email)
	{
	$regexp='/^(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){255,})(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){65,}@)(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22))(?:\.(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-[a-z0-9]+)*\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-[a-z0-9]+)*)|(?:\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\]))$/iD';
	inventory_debug(__LINE__,__FILE__,__FUNCTION__);
	return preg_match($regexp, trim($Email));
	}
	
# Implode Function
function inventory_implode($format,$val){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return implode($format,$val);}
#End

function validate_alphanumeric_underscore($str) 
{
    if(preg_match('/^[a-zA-Z0-9_]+$/',$str) && substr($str, 0, 1)!="_"){inventory_debug(__LINE__,__FILE__,__FUNCTION__);	return true;}
	else{inventory_debug(__LINE__,__FILE__,__FUNCTION__);return false;}
}

function validate_phone_number($phone)
{
	if($phone === '0000000000')
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
		return false;
	}
	if( !preg_match("/^[7-9][0-9]{9}$/i", $phone))
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
		return false;
	}
	else
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
	 	return true;
	}
}
function validate_alternate_phone_number($phone)
{

	if( !preg_match("/^[\s()+-]*([0-9][\s()+-]*){6,20}$/", $phone))
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
		return false;
	}
	else
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
	 	return true;
	}
}
function inventory_replace_message($message_date_array, $message_value_array, $string)
{
	$message_date_array = array_map("add_email_template_code", $message_date_array);
	return str_replace($message_date_array, $message_value_array, $string);
}
function inventory_send_mail($template,$template_date_array,$template_value_array,$receiver,$subject)
{
	$template_date_array = array_map("add_email_template_code", $template_date_array);
	$email_data = str_replace($template_date_array, $template_value_array, $template);
	$subject = str_replace($template_date_array, $template_value_array, $subject);
	$email_id = "";
	$from = "Track App <noreply@track.codez.in>";
	if(LOCAL)
	{
		$email_id =	"user1@codezserver1.codez.in";
	}
	else
	{
		$email_id =	$receiver;
	}
	$list = '';
	
	$message = '<html>
<head>
<title>Track App</title>
</head>
<body>
<table width="655" border="0" cellspacing="0" cellpadding="0" align="center" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; line-height:18px;">
  <tr>
    
    <table width="246" border="0" cellspacing="0" cellpadding="0" align="center" style="padding:20px 0 20px 0;">
    
</table>
</td>
  </tr>
  <tr>
    <td scope="row" style="padding:10px;">
   '.$email_data.'
    </td>
  </tr>
  <tr>
    <td scope="row" style="padding:10px 10px 10px 10px;">
Thank you,<br />

Administrator<br />
Track App<br />  
    </td>
  </tr>
  
</table>

</body>
</html>';
	
    $headers = "Reply-To: ".$from."\r\n"; 
    $headers .= "Return-Path: ".$from."\r\n"; 
    $headers .= "From: ".$from."\r\n"; 
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\nX-Priority: 3\r\nX-Mailer: PHP". phpversion() ."\r\n";
	
	//mail("kousik@codez.in","My subject","hello world");
	
	if(!mail($email_id,$subject,$message,$headers, 'O DeliveryMode=b'))
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
		return "FAIL";
	}
	else
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
		return "SUCCESS";
	}
}

function add_email_template_code($n)
{
	inventory_debug(__LINE__,__FILE__,__FUNCTION__);
    return("%%".$n."%%");
}

function lower($str)
{
	return strtolower($str);
}
function lower_all_array_values($array)
{
	return array_map('strtolower', $array);
}
function inventory_send_sms($template,$template_date_array,$template_value_array,$receiver)
{
	$template_date_array = array_map("add_email_template_code", $template_date_array);
	$sms_data = str_replace($template_date_array, $template_value_array, $template);
	
	$smssend = "";
	
	if(LOCAL)
	{
		$smssend =	"8336045741";
	}
	else
	{
		$smssend =	$receiver;
	}
	$url = "http://www.saleampm.com/smsapi/sms.php?msg=".urlencode($sms_data)."&number=".$smssend;
	inventory_print_otp_log($url);
	//echo $url;
//	file_put_contents("testFile.txt", print_r($url), FILE_APPEND);
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, '');
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$result = curl_exec($ch);
	curl_close($ch);
	
	
	$result = explode(",",$result);
	$status = explode("=",$result[0]);
					
	if(isset($status[1]) && $status[1] == 1)
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
		return "FAIL";
	}
	else
	{
		inventory_debug(__LINE__,__FILE__,__FUNCTION__);
		return "SUCCESS";
	} 			
}
function display_notification()
{
		$user_id = inventory_get_session(VARIABLE_PREFIX."admin_id");
		$notice_view = inventory_fetch_assoc(inventory_query("select noticeview from admin_info where ai_admin_id=".$user_id));
		$query ="SELECT `text`,`time` FROM log WHERE type = 2 ORDER BY `time` DESC LIMIT 0,8";
		$result = inventory_query($query);
		$count = inventory_num_rows($result);
		$notice = "";
		$new_count = 0;
		while($row = inventory_fetch_assoc($result))
		{
			
			if($notice_view['noticeview'] != "" && $row['time'] > $notice_view['noticeview'])
				$new_count++; 
		 	$notice .='<li><span class="event">'.$row['text'].'</span></li>';
    	}
		if($notice_view['noticeview'] == "")
			$new_count = $count ; 
	
	?>
 	  <li class="dropdown" id="notification">
            <a href="" class="dropdown-toggle" data-toggle="dropdown" >
                <span class="icon16 icomoon-icon-bell-2"></span><?php if($new_count > 0) { ?> <span class="notification"><?php inventory_display($new_count);?></span><?php } ?>
            </a>
            <ul class="dropdown-menu">
                <li class="menu">
                    <ul class="notif">
                    <li class="header"><strong>Notifications</strong>: </li>
                    <?php 	echo $notice; ?>
                    </ul>
                </li>
            </ul>
        </li>
			
<?php
}

function get_user_detail($user_id)
{
	$query = "SELECT `name`,`level`,email,ai_admin_id FROM admin_info WHERE ai_admin_id = ".$user_id;
	$result = inventory_query($query); 
	return inventory_fetch_assoc($result);
}
function statelist($select_city = "")
{
	global $indian_all_states;
	$option = "<option></option>";
	foreach($indian_all_states as $key => $val)
	{
		$selected = "";
		if($key == $select_city)
			$selected = "selected='selected'";
		
		$option .= "<option value='".$key."' ".$selected .">".$val."</option>";
	}
	inventory_display($option);
}

function getmo($select_mo = "")
{
	$query ="SELECT marketing_officer_id,`name` FROM view_marketing_officer_info WHERE is_active = 1";
	$result = inventory_query($query);
	$count = inventory_num_rows($result);
	$notice = "";
	$new_count = 0;
	while($row = inventory_fetch_assoc($result))
	{
		$selected = "";
		if($row['marketing_officer_id'] == $select_mo)
			$selected = "selected='selected'";
		
		$option .= "<option value='".$row['marketing_officer_id']."' ".$selected .">".$row['name']."</option>";
	}
	inventory_display($option);
}
function get_all_state_options($select_city = "")
{
	global $indian_all_states;
	$option = "";
	foreach($indian_all_states as $key => $val)
	{
		$selected = "";
		if($key == $select_city)
			$selected = "selected='selected'";
		$option .= "<option value='".$key."' ".$selected .">".$val."</option>";
	}
	inventory_display($option);
}
function inventory_date_format($date)
{
	return date("j M Y (g:i A)",strtotime($date));
}
function inventory_full_date_format()
{
	return date("l\, jS \of F Y");	
}
function inventory_database_date_format($date)
{
	return date("Y-m-d", strtotime($date));
}
function inventory_date_format_date($date)
{
	if($date != "")
	{
		return date("j, M Y ",strtotime($date));
	}
	else
	{
		return "-";
	}
}
function inventory_date_format_date_csv($date)
{
	if($date != "")
	{
		return date("d-M-y",strtotime($date));
	}
	else
	{
		return "-";
	}
}
function inventory_time_format_in_am_pm($date)
{
	return date("h:i:sa");
}
function inventory_date_format_date2($date)
{
	return date("Y-m-d",strtotime($date));
}
function inventory_time_format($date)
{
	return date("g:i:s A ",strtotime($date));
}
function inventory_get_date($val)
{
	$pos = strrpos($val, "-");
	if($pos === false)
	{
		$date_modify = explode("/",$val);
	}	
	else
	{
		$date_modify = explode("-",$val);
	}
	if(isset($date_modify[1]) && isset($date_modify[0]) && isset($date_modify[2]))
	{
 		return date("Y-m-d", mktime(0, 0, 0, intval($date_modify[1]), intval($date_modify[0]), intval($date_modify[2])));
	}
	else	
	{
		return ;
	}
}
function inventory_get_date_month($val)
{
	$pos = strrpos($val, "-");
	if($pos === false)
	{
		$date_modify = explode("/",$val);
	}	
	else
	{
		$date_modify = explode("-",$val);
	}
	if(isset($date_modify[1]) && isset($date_modify[0]) && isset($date_modify[2]))
	{
 		return date("Y-m-d", mktime(0, 0, 0, intval($date_modify[0]), intval($date_modify[1]), intval($date_modify[2])));
	}
	else	
	{
		return ;
	}
}
function inventory_get_date_full_month($val)
{
	$months = array( 'jan'=>1, 'feb'=>2, 'mar'=>3, 'apr' => 4,'may' => 5,'jun' => 6,'jul' => 7,'aug' => 8,'sep' => 9,'oct' => 10,'nov' => 11,'dec' => 12);
	$pos = strrpos($val, "-");
	if($pos === false)
	{
		$date_modify = explode("/",$val);
	}	
	else
	{
		$date_modify = explode("-",$val);
	}
	if(isset($date_modify[1]) && isset($date_modify[0]) && isset($date_modify[2]))
	{
 		return date("Y-m-d", mktime(0, 0, 0, intval(($months[strtolower($date_modify[1])])), intval($date_modify[0]), intval($date_modify[2])));
	}
	else	
	{
		return ;
	}
}

function inventory_date_compare($date_1, $date_2){
	$difference = date_diff($date_1, $date_2);
	return $difference;
}

function inventory_round($val)
{
	echo  round($val);
}
function add_download_log($file_name, $count, $message,$parameters)
{
	
	inventory_query("INSERT INTO download_log (file_name,total_log,message,parameters) VALUE ('".$file_name."','".$count."','".$message."','".$parameters."')");
}
function all_excel_token_list($date_to,$date_from,$Search_type)
{
	$user_account_type = array("1" => "Wholeseller/Dealer","2" => "Retailer", "3" => "Painter", "4" => "Others");
	$user_array = array();
	$query = "SELECT ai_token_id,`name`,user_type,pancard,pancard_verified,contact_no,email,expiry_date,account_no,current_state,account_name,account_type,ifsc_code,bank_name,organization,dealercode,`serial`,token_no,`value`,`datetime`,transaction_id,inventory_charges,inventory_charges_percent,(`value`+inventory_charges) AS total,process_date,paid_date, tokeninfo.utr_number,mode_of_validation
				FROM tokeninfo 
				LEFT JOIN user_info ON user_info.ai_user_id = tokeninfo.user_id
				WHERE (current_state = 4 OR current_state = 5 OR current_state = 6) ";
		 $parameters ="";
		 $token_downloaded = "";
		switch($Search_type)
		{
			case 1:	
				 if($date_to == $date_from)
				 {
					$query .= " AND DATE(`datetime`)='".$date_from."'";
					$parameters .="validated date :".$date_from;
				 }
				else
				{
					$query .= " AND `datetime` BETWEEN '".$date_from."' AND DATE_ADD('".$date_to."', INTERVAL 1 DAY)";
					$parameters .=" validated date from :".$date_from." validated date to : ".$date_to;
				}
			break;
			case 2:	
				 if($date_to == $date_from)
				 {
					$query .= " AND DATE(`process_date`)='".$date_from."'";
					$parameters .="process date :".$date_from;
				 }
				else
				{
					$query .= " AND `process_date` BETWEEN '".$date_from."' AND DATE_ADD('".$date_to."', INTERVAL 1 DAY)";
					$parameters .=" process date from :".$date_from." process date to : ".$date_to;
				}
			break;
			case 3:	
				 if($date_to == $date_from)
				 {
					$query .= " AND DATE(`paid_date`)='".$date_from."'";
					$parameters .="Paid date :".$date_from;
				 }
				else
				{
					$query .= " AND `paid_date` BETWEEN '".$date_from."' AND DATE_ADD('".$date_to."', INTERVAL 1 DAY)";
					$parameters .=" paid date from :".$date_from." paid date to : ".$date_to;
				}
			break;
		}
	
		$query = inventory_query($query);
		while($row = inventory_fetch_array($query))
		{
			$user_array[] = $row;
		}
		
		$fn = "All_Token_".date('d_m_Y');
		$table = "";
		$update_user = "";
		/** PHPExcel */
	  require_once 'Classes/PHPExcel.php';
	
	  /** PHPExcel_IOFactory */
	  require_once 'Classes/PHPExcel/IOFactory.php';
	
	  // Create new PHPExcel object
	  $objPHPExcel = new PHPExcel();
	  $type = array("3" => "Not Validated","4" => "Validated", "5" => "Processing", "6" => "Paid"); 
	  // Set properties
	  $objPHPExcel->getProperties()->setCreator("Team Codez")
								   ->setLastModifiedBy("Team Codez")
								   ->setTitle("Office 2007 XLSX Test Document")
								   ->setSubject("Office 2007 XLSX Test Document")
								   ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
								   ->setKeywords("office 2007 openxml php")
								   ->setCategory("Test result file");
		if(count($user_array))
		{
				$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('A1', 'Serial No')
							->setCellValue('B1', 'SAP Code')
							->setCellValue('C1', 'Customer Type')
							->setCellValue('D1', 'Name')
							->setCellValue('E1', 'Organization')
							->setCellValue('F1', 'Contact')
							->setCellValue('G1', 'Email')
							->setCellValue('H1', 'Bank account Holder Name')
							->setCellValue('I1', 'A/C Type')
							->setCellValue('J1', 'A/C Number')
							->setCellValue('K1', 'Bank Name')
							->setCellValue('L1', 'Ifsc Code')
							->setCellValue('M1', 'Pan Card')
							->setCellValue('N1', 'Pan Card Verified')
							->setCellValue('O1', 'Token Number')
							->setCellValue('P1', 'Token Serial')
							->setCellValue('Q1', 'Expiry Date')
							->setCellValue('R1', 'Validated Date')
							->setCellValue('S1', 'Validated Time')
							->setCellValue('T1', 'Transaction Id')
							->setCellValue('U1', 'Amount')
							->setCellValue('V1', 'Service Charges')
							->setCellValue('W1', 'Service Charge Percentage')
							->setCellValue('X1', 'Total Amount')
							->setCellValue('Y1', 'Processed date')
							->setCellValue('Z1', 'UTR Number/Credit note number')
							->setCellValue('AA1', 'Payment date')
							->setCellValue('AB1', 'Current State')
							->setCellValue('AC1', 'Mode of verification');
										
							
							
	
				$user_counter = 1;
				$update_token = "";		
				
				foreach ($user_array as $row) {
					$user_counter++;	 
					
					if($row['pancard_verified'] == 1)
					{
						$pan_verified = "Yes";
					}
					else	
					{
						$pan_verified = "No";	
					}	
					if($token_downloaded != "")
					{
						$token_downloaded .= ",";
					}
				$token_downloaded .= $row['ai_token_id'];	
					$validated_date = inventory_date_format_date($row['datetime']);
					$validated_time = inventory_time_format($row['datetime']);
						
					$objPHPExcel->setActiveSheetIndex(0)
								->setCellValue('A'.$user_counter, $user_counter-1)
								->setCellValueExplicit('B'.$user_counter, $row['dealercode'],PHPExcel_Cell_DataType::TYPE_STRING)
								->setCellValue('C'.$user_counter, $user_account_type[$row['user_type']])
								->setCellValue('D'.$user_counter, $row['name'])
								->setCellValue('E'.$user_counter, $row['organization'])
								->setCellValueExplicit('F'.$user_counter, $row['contact_no'],PHPExcel_Cell_DataType::TYPE_STRING)
								->setCellValue('G'.$user_counter, $row['email'])
								->setCellValue('H'.$user_counter, $row['account_name'])
								->setCellValue('I'.$user_counter, $row['account_type'])
								->setCellValueExplicit('J'.$user_counter, $row['account_no'],PHPExcel_Cell_DataType::TYPE_STRING)
								->setCellValue('K'.$user_counter, $row['bank_name'])
								->setCellValue('L'.$user_counter, $row['ifsc_code'])
								->setCellValueExplicit('M'.$user_counter, $row['pancard'],PHPExcel_Cell_DataType::TYPE_STRING)
								->setCellValue('N'.$user_counter, $pan_verified)
								->setCellValue('O'.$user_counter, $row['token_no'])
								->setCellValueExplicit('P'.$user_counter, $row['serial'],PHPExcel_Cell_DataType::TYPE_STRING)
								->setCellValue('Q'.$user_counter, inventory_date_format_date($row['expiry_date']))
								->setCellValue('R'.$user_counter, $validated_date)
								->setCellValue('S'.$user_counter, $validated_time)
								->setCellValue('T'.$user_counter, $row['transaction_id'])
								->setCellValueExplicit('U'.$user_counter, $row['value'],PHPExcel_Cell_DataType::TYPE_NUMERIC)
								->setCellValueExplicit('V'.$user_counter, $row['inventory_charges'],PHPExcel_Cell_DataType::TYPE_NUMERIC)
								->setCellValueExplicit('W'.$user_counter, $row['inventory_charges_percent'],PHPExcel_Cell_DataType::TYPE_NUMERIC)
								->setCellValueExplicit('X'.$user_counter, $row['total'],PHPExcel_Cell_DataType::TYPE_NUMERIC)
								->setCellValue('y'.$user_counter, inventory_date_format_date($row['process_date']))
								->setCellValueExplicit('Z'.$user_counter, $row['utr_number'],PHPExcel_Cell_DataType::TYPE_STRING)
								->setCellValue('AA'.$user_counter, inventory_date_format_date($row['paid_date']))
								->setCellValue('AB'.$user_counter,  $type[$row['current_state']])
								->setCellValue('AC'.$user_counter,  $row['mode_of_validation']);
				}
				add_download_log($fn, ($user_counter -1), "Token ID = ".$token_downloaded,$parameters);
		} 
		else 
		{
     		$objPHPExcel->setActiveSheetIndex(0)
						->setCellValue('A1', 'No Token Found') ;
     	}
		
		// Set active sheet index to the first sheet, so Excel opens this as the first sheet
		$objPHPExcel->setActiveSheetIndex(0);
		
		
		header('Content-Type: application/vnd.ms-excel');
		header("Content-Disposition: attachment; filename=$fn.xls");
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');
		 
		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 2015 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
		$objWriter->save('php://output');
}

function inventory_territory($parent,$territoryStr="")
{
	/*$parent = inventory_replace(',','","',$parent);
	$query = 'SELECT fld_code,fld_name FROM tbl_territory WHERE parent_territory IN("'.$parent.'")';
	$select_str = "";
	$option_str = "";
	if($result = inventory_query($query))
	{
		if(inventory_num_rows($result))
		{
			while($row = inventory_fetch_assoc($result))
			{
				$option_str .= '<option value="'.$row['fld_code'].'">'.$row['fld_name'].'</option>';
			}
			$select_str = ' <div class="col-lg-3 col-md-3"><select name="territory[]" class="territory_class form-control select2 " multiple>'.$option_str.'</select></div>';
		}
	}
	echo $select_str ;*/
	?>
    <p id="menuLog">You chose: <span id="menuSelection"></span></p>
<a tabindex="0" href="#news-items" class="fg-button fg-button-icon-right ui-widget ui-state-default ui-corner-all" id="flyout">
  <span class="ui-icon ui-icon-triangle-1-s"></span> Territory
</a>
<div id="news-items" class="hidden"><?php echo inventory_findchild("INDIA","INDIA"); ?></div>
    <?php
}
function inventory_findchild($parent,$name)
{
	$query2 = "SELECT fld_code,fld_ai_id,fld_name FROM tbl_territory WHERE parent_territory = '".$parent."' ";
	if($result2 = inventory_query($query2))
	{
		if(inventory_num_rows($result2))
		{
			$str ="";
			if($parent != "INDIA")
			{
				$str .= '<li><a href="#">'.$name." (".$parent.")".'</a>';
			}
			$str .='<ul>';
			while($row = inventory_fetch_assoc($result2))
			{
				$str .= inventory_findchild($row['fld_code'],$row['fld_name']);
			}
			$str .="</ul></li>";
			return $str;
		}
		else
		{
			$str = '<li><a href="#">'.$name." (".$parent.")".'</a></li>';
			return $str;
		}
	}
}
function getallterritory($territoryarr)
{
	$territorystr = inventory_implode(",",$territoryarr);
	$territoryarr  = explode(",",$territorystr);
	var_dump($territoryarr);
	$territorystr = inventory_replace(',','","',$territorystr);
	$child_selected = 0;
	$current_temp_parent = "";
	$find_all_child = '';
	$temp_child = '';
	$temp_selected_child = "";
	echo $query = 'SELECT code,parent_territory FROM view_territory WHERE parent_territory IN("'.$territorystr.'") order by parent_territory';
	if($result = inventory_query($query))
	{
		if(inventory_num_rows($result))
		{
			while($row = inventory_fetch_assoc($result))
			{
				if($row['parent_territory'] != $current_temp_parent)
				{
					if($current_temp_parent	!= "" && $child_selected == 0)
					{
						if($find_all_child != "")
						{
							$find_all_child .= ',';	
						}
						$find_all_child .= $temp_child;
					}
					else
					{
						if($current_temp_parent	!= "")
						{
							if($find_all_child != "")
							{
								$find_all_child .= ',';	
							}
							$find_all_child .= $temp_selected_child;
						}
					}
					$child_selected = 0;
					$temp_child = '';
					$current_temp_parent = $row['parent_territory'];
				}
				
				echo "<br>".$row['code']."---------------------".inventory_in_array($row['code'],$territoryarr);
				if(inventory_in_array($row['code'],$territoryarr))
				{
					$child_selected = 1;
					if($temp_selected_child != "")
					{
						$temp_selected_child .= ',';	
					}
					$temp_selected_child .= '"'.$row['code'].'"';
				}
				
				if($temp_child != "")
				{
					$temp_child .= ',';	
				}
				$temp_child .= '"'.$row['code'].'"';
				
			}
			echo $find_all_child;
			
		}
	}
}

function get_all_enums($select_value = "", $select_table = "", $select_column = "")
{
	global $indian_all_states;
	$option = "";
        $query="SELECT COLUMN_TYPE  FROM information_schema.columns WHERE 
                TABLE_NAME = '".$select_table."' AND column_name = '".$select_column."'";
        if($result=  inventory_query($query))
        {
            $option = "<option value''>Please Select</option>";
	    $row=  inventory_fetch_assoc($result);
            $rawValue = $row['COLUMN_TYPE'];
            //$rawValue = "enum('DMO','Sales Representative','Area Sales Manager','Regional Sales Head','DY Zonal Head','Head Sales')";
            $enumValue = substr($rawValue,5,strlen($rawValue)-6);
            $enumData=explode(",", $enumValue);
            for($i=0;  $i < count($enumData); $i++)
            {
                 $eachValue=  substr($enumData[$i], 1, strlen($enumData[$i])-2);
                 $selected = "";
		if($eachValue == $select_value)
			$selected = "selected='selected'";
		$option .= "<option value='".$eachValue."' ".$selected .">".$eachValue."</option>";
            }            
        }
	inventory_display($option);
}
function  get_marketing_role($select_value="")
{
    get_all_enums($select_value, "tbl_marketing_officer_info", "fld_role");
}
function  get_marketing_profile($select_value="")
{
    get_all_enums($select_value, "tbl_marketing_officer_info", "fld_profile");
}
function  get_stockist_distribution_chanel($select_value="")
{
    get_all_enums($select_value, "tbl_stockist_info", "fld_distribution_channel");
}
function  get_stockist_division($select_value="")
{
    get_all_enums($select_value, "tbl_stockist_info", "fld_division");
}
function inventory_left_pad($input)
{
	return str_pad($input, 6, "0", STR_PAD_LEFT);
}
#excllent mobile number check
function inventory_checkMobileFormat($value)
{
	$value=inventory_replace_message(array(" "),array(""), $value);
	return preg_match('/^[0-9\+.-]/', $value)&&(preg_match_all('/[0-9]/',$value)>8);
}
function inventory_update_id($type,$company_id)
{
	$fld_type = '';
	if($type === 'shipping')
	{
		$fld_type = 'fld_last_shipping_id';
	}
	else
	{
		$fld_type = 'fld_last_order_id';
	}
	$update_query = 'UPDATE tbl_company_list SET '.$fld_type.' = '.$fld_type.'+1 WHERE ai_id = '.$company_id.';';
	
	if($result=  inventory_query($update_query))
    {
		return true;
	}
	else
	{
		return false;
	}
}
function inventory_generate_id($type,$company_id)
{
	$generated_id = '';
	$id_query ='';
	$generated_id = '';
	$last_shipping_id = '';
	if($type === 'shipping')
	{
		$generated_id = 'SP';
		$id_query = 'SELECT fld_last_shipping_id FROM tbl_company_list WHERE ai_id = "'.$company_id.'";';
		if($result=  inventory_query($id_query))
		{
			if($row=  inventory_fetch_assoc($result))
			{
				$last_shipping_id = $row['fld_last_shipping_id'];
			}
		}
	}
	else
	{
		$generated_id = 'OD';
		$id_query = 'SELECT fld_last_order_id FROM tbl_company_list WHERE ai_id = "'.$company_id.'";';
		if($result=  inventory_query($id_query))
		{
			if($row=  inventory_fetch_assoc($result))
			{
				$last_shipping_id = $row['fld_last_order_id'];
			}
		}
	}
//	var_dump($id_query);
	$generated_id .= date('Y').'/'.date('m').'/'.date('d').'-'.$last_shipping_id;
	return $generated_id;
}
function inventory_fetch_retailer_by_group($staff_id)
{
	$retailer = '';
	$id_query = 'SELECT DISTINCT tbl_retailer_group.fld_retailer_id FROM tbl_retailer_group WHERE tbl_retailer_group.fld_group_id IN (SELECT tbl_staff_group_details.fld_group_id FROM tbl_staff_group_details WHERE tbl_staff_group_details.fld_staff_id = '.$staff_id.');';
	if($result=  inventory_query($id_query))
	{
		if(inventory_num_rows($result))
		{
			while($row = inventory_fetch_assoc($result))
			{
				if($retailer!='')
				{
					$retailer .= ' OR ';
				}
				$retailer .= "fld_retailer_id = ".$row['fld_retailer_id'];
			}
		}else{
			$retailer .= "fld_retailer_id = 0";
		}
		return $retailer; 
	}
	
}
function inventory_fetch_retailer_by_group_app($staff_id)
{
	$retailer = '';
	$id_query = 'SELECT DISTINCT tbl_retailer_group.fld_retailer_id FROM tbl_retailer_group WHERE tbl_retailer_group.fld_group_id IN (SELECT tbl_staff_group_details.fld_group_id FROM tbl_staff_group_details WHERE tbl_staff_group_details.fld_staff_id = '.$staff_id.');';
	if($result=  inventory_query($id_query))
	{
		if(inventory_num_rows($result))
		{
			while($row = inventory_fetch_assoc($result))
			{
				if($retailer!='')
				{
					$retailer .= ',';
				}
				$retailer .= $row['fld_retailer_id'];
			}
		}else{
			$retailer .= "0";
		}
		return $retailer; 
	}
	
}
function inventory_base64_to_image($imageData,$imageName)
{
	$imageData = base64_decode($imageData);
	$source = imagecreatefromstring($imageData);
	$imageSave = imagejpeg($rotate,$imageName,100);
	imagedestroy($source);
}
function inventory_date_difference($str_date1,$str_date2)
{
	$date1=date_create($str_date1); 
	$date2=date_create($str_date2);
	$diff=date_diff($date1,$date2);
	return $diff->days;
}
// Is date 1 more than date 2? 
function inventory_date_more($str_date1,$str_date2)
{
	$date1=date_create($str_date1); 
	$date2=date_create($str_date2);
	$diff=date_diff($date1,$date2);
	if($diff->invert == 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function inventory_distance($lat1, $lon1, $lat2, $lon2) {
	
	
	  $theta = $lon1 - $lon2;
	  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
	  $dist = acos($dist);
	  $dist = rad2deg($dist);
	  $miles = $dist * 60 * 1.1515;
	  $meters = $miles * 1.609344 * 1000; 
	  if($meters <= 50.00)
	  {
		 
		  return true;
	  }
	  else
	  {
	
		  return false;
	  }

}

function inventory_find_distance($lat1, $lon1, $lat2, $lon2) {
	
	//function distance($lat1, $lon1, $lat2, $lon2, $unit) {
	$theta = $lon1 - $lon2;
	$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
	$dist = acos($dist);
	$dist = rad2deg($dist);
	$miles = $dist * 60 * 1.1515;
	$meters = $miles * 1.609344 * 1000; //distance in meters
	if(!is_nan($meters))
	{
		return $meters;
	}
	else
	{
		return 0.0;
	}
}

function inventory_gmt_to_user_time($gmt_time, $timezone)
{
	//var_dump($gmt_time);
	date_default_timezone_set('GMT');
	$date = new DateTime($gmt_time);
	$date = $date->getTimestamp();
	date_default_timezone_set($timezone);
	//var_dump(date_default_timezone_get());
	
	$current_date_time = date('Y-m-d H:i:s', $date);
	//var_dump($current_date_time);
	
	return $current_date_time;
}

function inventory_user_time_to_gmt($user_time)
{
	//var_dump($gmt_time);
	//date_default_timezone_set('GMT');
	$date = new DateTime($user_time);
	$date = $date->getTimestamp();
	date_default_timezone_set('GMT');
	//var_dump(date_default_timezone_get());
	
	$current_date_time = date('Y-m-d H:i:s', $date);
	//var_dump($current_date_time);
	
	return $current_date_time;
}
function inventory_push_notification_from_web($title, $message, $user_id, $type, $reg_Id)
{
	//var_dump($title);var_dump($message);var_dump($patient_id);var_dump($reg_Id);	
	error_reporting(-1);
	ini_set('display_errors', 'On');
	//var_dump(__DIR__);
	require_once '\action\firebase.php';
	require_once '\action\push.php';

	$firebase = new Firebase();
	$push = new Push();

	$push->setTitle($title);
	$push->setMessage($message);
	$push->setUserID($user_id);
	//$push->setType($type);
	
	$json = '';
	$response = '';
	
	$json = $push->getPush();
	$response = $firebase->send($reg_Id, $json);

}
function transactionid($id){
	$pad_id = inventory_left_pad($id);
	return date('y').date('m').$pad_id;	
}

function usertype($usertype){
	switch($usertype){
		case "admin":
			return "Admin";
			break;
		case "hod":
			return "HOD";
			break;
		case "user":
			return "User";
			break;	
		case "store_keeper":
			return "Store Keeper";
			break;	
		case "vendor":
			return "Vendor";
			break;	
	}
}


/*  Freelancer.com */
function get_all_department(){
	$query = "SELECT * FROM tbl_department WHERE fld_is_active ='1' ";
	$result = inventory_query($query);
	$row = inventory_fetch_assoc($result);
	return $row;
}


    ?>
