<?php

$title_array = array();

$title_array['dashboard']['title']="Dashboard";
$title_array['dashboard']['heading']="Dashboard";
$title_array['dashboard']['icon']="fa fa-home";


$title_array['hod']['title']="HOD";
$title_array['hod']['heading']="HOD";
$title_array['hod']['icon']="fa fa-user";

$title_array['vendors']['title']="Vendor";
$title_array['vendors']['heading']="Vendor";
$title_array['vendors']['icon']="fa fa-user";

$title_array['depuser']['title']="Department User";
$title_array['depuser']['heading']="Department User";
$title_array['depuser']['icon']="fa fa-user";

$title_array['storekeeper']['title']="Storekeeper User";
$title_array['storekeeper']['heading']="Storekeeper User";
$title_array['storekeeper']['icon']="fa fa-user";

$title_array['indentcreation']['title']="Indent Creation";
$title_array['indentcreation']['heading']="Indent Creation";
$title_array['indentcreation']['icon']="fa fa-user";

$title_array['cashpurchase']['title']="Cash Purchase";
$title_array['cashpurchase']['heading']="Cash Purchase";
$title_array['cashpurchase']['icon']="fa fa-user";

$title_array['cash_purchase_receive']['title']="Cash Purchase Receivable";
$title_array['cash_purchase_receive']['heading']="Cash Purchase Receivable";
$title_array['cash_purchase_receive']['icon']="fa fa-user";


$title_array['indentprintpdf']['title']="Print Indent";
$title_array['indentprintpdf']['heading']="Print Indent";
$title_array['indentprintpdf']['icon']="fa fa-print";

$title_array['poorder']['title']="PO Order";
$title_array['poorder']['heading']="PO Order";
$title_array['poorder']['icon']="fa fa-print";


$title_array['printorder']['title']="PO Order Print";
$title_array['printorder']['heading']="PO Order Print";
$title_array['printorder']['icon']="fa fa-print";

$title_array['receiveorder']['title']="PO Order Receivable";
$title_array['receiveorder']['heading']="PO Order Receivable";
$title_array['receiveorder']['icon']="fa fa-user";

$title_array['reports']['title']="Reports";
$title_array['reports']['heading']="Reports";
$title_array['reports']['icon']="fa fa-print";


$title_array['getiteminfo']['title']="Ajax";
$title_array['getiteminfo']['heading']="ajax";
$title_array['getiteminfo']['icon']="fa fa-user";



$title_array['departments']['title']="Departments";
$title_array['departments']['heading']="Departments";
$title_array['departments']['icon']="fa fa-ticket";

$title_array['category']['title']="Category";
$title_array['category']['heading']="Category";
$title_array['category']['icon']="fa fa-cube";

$title_array['semester']['title']="Semester";
$title_array['semester']['heading']="Semester";
$title_array['semester']['icon']="fa fa-cube";


$title_array['section']['title']="Section";
$title_array['section']['heading']="Section";
$title_array['section']['icon']="fa fa-cube";

$title_array['subcategory']['title']="Subcategory";
$title_array['subcategory']['heading']="Subcategory";
$title_array['subcategory']['icon']="fa fa-cubes";

$title_array['item']['title']="Item";
$title_array['item']['heading']="Item";
$title_array['item']['icon']="fa fa-archive";

$title_array['tax']['title']="Tax";
$title_array['tax']['heading']="Tax";
$title_array['tax']['icon']="fa fa-tasks";

?>