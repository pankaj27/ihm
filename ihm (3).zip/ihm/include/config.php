<?php

date_default_timezone_set('Asia/Kolkata');
define('DB_SERVER', "localhost"); 	//database server
define('DB_USER', "root");	//database login name
define('DB_PASS', "");	//database login password
define('DB_DATABASE', "iihm");	//database name

//define('ROOT_PATH',"http://192.168.1.1/ihm/");//root path
define('ROOT_PATH',"http://localhost/ihm/");


define('LOCAL_DATETIME',date("Y-m-d H:i:s")); //sets local timezone

define('LOCAL',1);

define('TIME_OUT_SECONDS', 5000);
define('VARIABLE_PREFIX',"inventory_");
define('RECORDS',10);
$ALLOWED_FILE_EXT = array('xls','xlsx');



?>