<!doctype html>
<html class="fixed sidebar-light  sidebar-left-sm" data-style-switcher-options="{'sidebarColor': 'light'}">
	
<!-- Mirrored from preview.oklerthemes.com/porto-admin/2.0.0/layouts-header-menu.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Dec 2017 17:47:48 GMT -->
<head>

		<!-- Basic -->
		<meta charset="UTF-8">

		<title><?php inventory_display($title_array[$page]['title'])?></title>
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/animate/animate.css">

		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />

		<!-- Specific Page Vendor CSS -->		
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-ui/jquery-ui.css" />		
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-ui/jquery-ui.theme.css" />		
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />		
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/morris/morris.css" />
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
        <link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/select2/css/select2.css" />		
        <link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/select2-bootstrap-theme/select2-bootstrap.min.css" />
		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/css/theme.css" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/css/custom.css">

		<!-- Head Libs -->
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/modernizr/modernizr.js"></script>		
        <link rel="stylesheet" href="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/media/css/dataTables.bootstrap4.css" />

	</head>
	<body>
		<section class="body">

			<!-- start: header -->
			<header class="header">
				<div class="logo-container">
					<a href="<?php inventory_display(ROOT_PATH)?>" class="logo">						
                    	<img src="<?php inventory_display(ROOT_PATH)?>/img/logo.png" width="75" height="35" alt="Porto Admin" />					
                    </a>					
                    <div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">						
                    	<i class="fa fa-bars" aria-label="Toggle sidebar"></i>					
                    </div>
				</div>
			
				<!-- start: search & user box -->
				<div class="header-right">
					
					<!-- Notificatio Area -->
					
					<span class="separator"></span>
			
					<div id="userbox" class="userbox">
						<a href="#" data-toggle="dropdown">
							<figure class="profile-picture">
								<img src="<?php inventory_display(ROOT_PATH)?>/img/logged.png" alt="Joseph Doe" class="rounded-circle" data-lock-picture="img/%21logged-user.jpg" />
							</figure>
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name"><?php inventory_display(inventory_get_session(VARIABLE_PREFIX."name")); ?></span>
								<span class="role"><?php inventory_display(usertype(inventory_get_session(VARIABLE_PREFIX."user_type"))); ?></span>
							</div>
			
							<i class="fa custom-caret"></i>
						</a>
			
						<div class="dropdown-menu">
							<ul class="list-unstyled mb-2">
								<li class="divider"></li>
								<!-- <li>
									<a role="menuitem" tabindex="-1" href="#" data-lock-screen="true"><i class="fa fa-lock"></i> Change Password</a> 
								</li>-->
								<li>
									<a role="menuitem" tabindex="-1" href="<?php inventory_display(ROOT_PATH)?>/logout"><i class="fa fa-power-off"></i> Logout</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- end: search & user box -->
			</header>
			<!-- end: header -->