<?php 

define("BLANK_FIELDS","Please Enter or select value in ");
define("MANDATORY"," is a mandatory field");
define("EXISTS","  already exists");
define("SPECIAL_CHARS","special character not allowed in ");
define("SERVER_ERROR","Could Not Connect To The Database!");
define("ORDER_CREATE_MESSAGE","Order No %%order_no%% has been created by %%staff_name%% for %%customer_name%%");
define("ORDER_CREATE_MESSAGE_WEB","%%items%% have been ordered for the same.");
define("ORDER_CREATE_MESSAGE_TITLE","Order No %%order_no%% has been created");
define("ORDER_SHIP_MESSAGE_TITLE","Order No %%order_no%% has been shipped");
define("ORDER_SHIP_CREATE_MESSAGE","Various Items of Order No %%order_no%% has been shipped.");
define("ORDER_SHIP_CREATE_MESSAGE_WEB","%%items%% of Order No %%order_no%% has been shipped.");
define("INSUFFICIENT_STOCK"," has insufficient stocks.");
//define("ORDER_CREATE_MESSAGE","Order No %%order_no%% has been created by %%staff_name%% for %%customer_name%%");

?>