</section>

		<!-- Vendor -->
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery/jquery.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-cookie/jquery-cookie.js"></script>			
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/popper/umd/popper.min.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap/js/bootstrap.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/common/common.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/nanoscroller/nanoscroller.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/magnific-popup/jquery.magnific-popup.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-placeholder/jquery-placeholder.js"></script>
		
		<!-- Specific Page Vendor -->		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-ui/jquery-ui.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqueryui-touch-punch/jqueryui-touch-punch.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-appear/jquery-appear.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/flot/jquery.flot.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/flot.tooltip/flot.tooltip.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/flot/jquery.flot.pie.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/flot/jquery.flot.categories.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/flot/jquery.flot.resize.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-sparkline/jquery-sparkline.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/raphael/raphael.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/morris/morris.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/gauge/gauge.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/snap.svg/snap.svg.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/liquid-meter/liquid.meter.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/jquery.vmap.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/maps/jquery.vmap.world.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>	
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/gmaps/gmaps.js"></script>
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/jquery-validation/jquery.validate.js"></script>
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>		
		<script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/media/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>	
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/ios7-switch/ios7-switch.js"></script>
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/select2/js/select2.js"></script>
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/media/js/jquery.dataTables.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/media/js/dataTables.bootstrap4.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/extras/TableTools/Buttons-1.4.2/js/dataTables.buttons.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/extras/TableTools/Buttons-1.4.2/js/buttons.bootstrap4.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/extras/TableTools/Buttons-1.4.2/js/buttons.html5.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/extras/TableTools/Buttons-1.4.2/js/buttons.print.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/extras/TableTools/JSZip-2.5.0//jszip.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/extras/TableTools/pdfmake-0.1.32/pdfmake.min.js"></script>		
        <script src="<?php inventory_display(ROOT_PATH)?>/vendor/datatables/extras/TableTools/pdfmake-0.1.32/vfs_fonts.js"></script>
		<!-- Theme Base, Components and Settings -->
		<script src="<?php inventory_display(ROOT_PATH)?>/js/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="<?php inventory_display(ROOT_PATH)?>/js/custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="<?php inventory_display(ROOT_PATH)?>/js/theme.init.js"></script>
		<script src="<?php inventory_display(ROOT_PATH)?>/js/examples/examples.datatables.default.js"></script>
		<script src="<?php inventory_display(ROOT_PATH)?>/js/examples/examples.datatables.row.with.details.js"></script>
		<script src="<?php inventory_display(ROOT_PATH)?>/js/examples/examples.datatables.tabletools.js"></script>
	</body>
</html>
