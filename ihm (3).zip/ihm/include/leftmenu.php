<?php 


        $user_id = inventory_get_session(VARIABLE_PREFIX."user_id");
        $sql_cat="select * from module_permission where user_id='".$user_id."'";
		$sql_cat_rslt=inventory_query($sql_cat);
		$rst_rw=inventory_fetch_assoc($sql_cat_rslt);
		
		//////////////////////////////////  LEFT MENU CATEGORY    /////////////////////////////////////
					$category_r=$rst_rw['category_r'];
					
	   /////////////////////////////////////////// LEFT MENU TAX  //////////////////////////////////////////////
					$tax_r=$rst_rw['tax_r'];
					
	  ////////////////////////////////  LEFT MENU SUB-CATEGORY    /////////////////////////////////////
					$subcat_r=$rst_rw['subcat_r'];
					
	 /////////////////////////////////////////// LEFT MENU DEPAETMENTS  //////////////////////////////////////////////
					$deep_r=$rst_rw['deep_r'];
					
	/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/				
	//////////////////////////////////  LEFT MENU ITEM    /////////////////////////////////////
					$item_r=$rst_rw['item_r'];
					
	   /////////////////////////////////////////// LEFT MENU INDENT  //////////////////////////////////////////////
					$indent_r=$rst_rw['indent_r'];
					
	  ////////////////////////////////  LEFT MENU PO    /////////////////////////////////////
					$po_r=$rst_rw['po_r'];
					
	 /////////////////////////////////////////// LEFT MENU CASH PURCHASE  //////////////////////////////////////////////
					$cashp_r=$rst_rw['cashp_r'];
	
	
	/////////////////////////////////////////// LEFT MENU CASH PURCHASE RECEIVE  //////////////////////////////////////////////
					$cashprecive_r=$rst_rw['cashprecive_r'];
					
					
	 /////////////////////////////////////////// LEFT MENU RCEIVABLE  //////////////////////////////////////////////
					$receiver_r=$rst_rw['receiver_r'];
	
					
	/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/				
	//////////////////////////////////  LEFT MENU VENDOR REPORT   /////////////////////////////////////
					$vendorr_r=$rst_rw['vendorr_r'];
					
	   /////////////////////////////////////////// LEFT MENU PURCHASE ORDER REPORT  //////////////////////////////////////////////
					$por_r=$rst_rw['por_r'];
					
	 ////////////////////////////////  LEFT MENU RECEIVE REPORT    /////////////////////////////////////
	  
					$cashpr_r=$rst_rw['cashpr_r'];
					
					
	  ////////////////////////////////  LEFT MENU RECEIVE REPORT    /////////////////////////////////////
	  
					$receiver_r=$rst_rw['receiver_r'];
					
	 /////////////////////////////////////////// LEFT MENU INDENT REPORT  //////////////////////////////////////////////
					$indent_r=$rst_rw['indent_r'];
		
	/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/				
	//////////////////////////////////  LEFT MENU USERS   /////////////////////////////////////
					$user_r=$rst_rw['user_r'];
					
	   /////////////////////////////////////////// LEFT MENU HOD  //////////////////////////////////////////////
					$hod_r=$rst_rw['hod_r'];
					
	  ////////////////////////////////  LEFT MENU STOREKEEPER    /////////////////////////////////////
					$storek_r=$rst_rw['storek_r'];
					$semester_r=$rst_rw['semester_r'];
					
	///////////////////////////////////ITEM TAGGING /////////////////////////////////////////////
					$item_tag=$rst_rw['item_tagg_write'];
					
	 				
	


?>
			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">
				
				    <div class="sidebar-header">
				        <div class="sidebar-title">
				            Navigation
				        </div>
				        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
				            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
				        </div>
				    </div>
				
				    <div class="nano">
				        <div class="nano-content">
				            <nav id="menu" class="nav-main" role="navigation">
				            
				                <ul class="nav nav-main">
				                    <li class="<?php if($page == "dashboard"){?> nav-active <?php } ?>">
				                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>">
				                            <i class="fa fa-home" aria-hidden="true"></i>
				                            <span>Dashboard</span>
				                        </a>                        
				                    </li>
				                    <?php if($item_r == 1){ ?>
                                    <li class="<?php if($page == "item"){?> nav-active <?php } ?>">
                                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/item">
                                            <i class="fa fa-archive" aria-hidden="true"></i>
                                            <span>Items</span>
                                        </a>                        
                                    </li>
                                    <?php } ?>
                                    
                                    <?php if($item_tag == 1){ ?>
                                    <li class="<?php if($page == "item"){?> nav-active <?php } ?>">
                                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/itemtagging">
                                            <i class="fa fa-archive" aria-hidden="true"></i>
                                            <span>Item Tagging</span>
                                        </a>                        
                                    </li>
                                    <?php } ?>
                                    
                                    <?php if($indent_r == 1){ ?>
                                    <li class="<?php if($page == "user"){?> nav-active <?php } ?>">
                                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/indent">
                                            <i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
                                            <span>Indent</span>
                                        </a>                        
                                    </li>
                                    <?php }  ?>
                                     <?php if($po_r == 1){ ?>
                                    <li class="<?php if($page == "item"){?> nav-active <?php } ?>">
                                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/poorder">
                                            <i class="fa fa-archive" aria-hidden="true"></i>
                                            <span>PO</span>
                                        </a>                        
                                    </li>
                                    <?php  } ?>
                                    <?php if($cashp_r == 1){ ?>
                                    <li class="<?php if($page == "item"){?> nav-active <?php } ?>">
                                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/cashpurchase">
                                            <i class="fa fa-archive" aria-hidden="true"></i>
                                            <span>Cash Purchase</span>
                                        </a>                        
                                    </li>
                                   <?php } ?>
                                   <?php if($cashprecive_r == 1){ ?>
                                    <li class="<?php if($page == "item"){?> nav-active <?php } ?>">
                                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/receive_cashpurchase">
                                            <i class="fa fa-archive" aria-hidden="true"></i>
                                            <span>Cash Purchase Receivable</span>
                                        </a>                        
                                    </li>
                                   <?php } ?>
                                   <?php if($receiver_r == 1){ ?>
                                    <li class="<?php if($page == "item"){?> nav-active <?php } ?>">
                                        <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/receive">
                                            <i class="fa fa-archive" aria-hidden="true"></i>
                                            <span>PO Receivable</span>
                                        </a>                        
                                    </li>
                                    <?php }  ?>
                                    <li class="nav-parent">
                                        <a class="nav-link" href="#">
                                            <i class="fa fa-file" aria-hidden="true"></i>
                                            <span>Reports</span>
                                        </a> 
                                        <ul class="nav nav-children">
				                        	 <?php if($indent_r == 1){ ?>
				                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/indentreports">
				                                    <i class="fa fa-print" aria-hidden="true"></i>
				                            		<span>Indent Reports</span>
				                                </a>
				                            </li>
				                            <?php } ?>
				                            <?php if($vendorr_r == 1){ ?>
				                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/vendorreport">
				                                    <i class="fa fa-print" aria-hidden="true"></i>
				                            		<span>Vendors Reports</span>
				                                </a>
				                            </li>
				                            <?php  } ?>
				                            <?php if($por_r == 1){ ?>
				                             <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/poreport">
				                                    <i class="fa fa-print" aria-hidden="true"></i>
				                            		<span>PO Reports</span>
				                                </a>
				                            </li>
				                            <?php  }  ?>
				                             <?php if($receiver_r == 1){ ?>
				                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/receivablereport">
				                                    <i class="fa fa-print" aria-hidden="true"></i>
				                            		<span>Receivable Reports</span>
				                                </a>
				                            </li>
				                            <?php }  ?>
				                           
				                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/itemreports">
				                                    <i class="fa fa-print" aria-hidden="true"></i>
				                            		<span>Item Reports</span>
				                                </a>
				                            </li>
				                          
				                            
				                        </ul>
                                        
                                        
                                                               
                                    </li>
                                    <li class="nav-parent">
				                        <a class="nav-link" href="#">
				                            <i class="fa fa-users" aria-hidden="true"></i>
				                            <span>Users</span>
				                        </a>
				                        <ul class="nav nav-children">
				                        	 <?php if($hod_r == 1){ ?>
                                   			<li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/hod">
				                                    <i class="fa fa-user" aria-hidden="true"></i>
				                            		<span>HOD</span>
				                                </a>
				                            </li>
				                            <?php  } ?>
				                             <?php if($user_r == 1){ ?>
                                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/depuser">
				                                   <i class="fa fa-user" aria-hidden="true"></i>
				                            		<span>User</span>
				                                </a>
				                            </li>
				                            <?php }  ?>
				                             <?php if($storek_r == 1){ ?>
                                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/storekeeper">
				                                   <i class="fa fa-user" aria-hidden="true"></i>
				                            		<span>Storekeeper</span>
				                                </a>
				                            </li>
				                            <?php } ?>
				                             <?php if(inventory_get_session(VARIABLE_PREFIX."user_type") == "admin"){ ?>
                                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/vendors">
				                                   <i class="fa fa-user" aria-hidden="true"></i>
				                            		<span>Vendor</span>
				                                </a>
				                            </li>
				                            <?php  }  ?>
                                          </ul>
                                      </li>
                                     
                                      <li class="nav-parent">
				                        <a class="nav-link" href="#">
				                            <i class="fa fa-cogs" aria-hidden="true"></i>
				                            <span>Settings</span>
				                        </a>
				                        <ul class="nav nav-children">
				                        	<?php if($tax_r == 1){ ?>
				                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/tax">
				                                    <i class="fa fa-tasks" aria-hidden="true"></i>
				                            		<span>Tax</span>
				                                </a>
				                            </li>
				                            
				                            <?php } ?>
                                             <?php if($deep_r==1){ ?>
                                             <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/departments">
				                                    <i class="fa fa-ticket" aria-hidden="true"></i>
				                            		<span>Department</span>
				                                </a>
				                            </li>
				                            <?php } ?>
				                             <?php if($category_r == 1){ ?>
                                            
                                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/category">
				                                    <i class="fa fa-cube" aria-hidden="true"></i>
				                            		<span>Category</span>
				                                </a>
				                            </li>
				                            <?php } ?>
				                             <?php if($subcat_r == 1){ ?>
                                            
                                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/subcategory">
				                                    <i class="fa fa-cubes" aria-hidden="true"></i>
				                            		<span>Subcategory</span>
				                                </a>
				                            </li>
                                            <?php } ?>
                                            <?php if($semester_r == 1){ ?>
                                            
                                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/semester">
				                                    <i class="fa fa-cubes" aria-hidden="true"></i>
				                            		<span>Semester</span>
				                                </a>
				                            </li>
                                            <?php } ?>
                                           <?php if($semester_r == 1){ ?>
                                            
                                            <li>
				                                <a class="nav-link" href="<?php inventory_display(ROOT_PATH)?>/section">
				                                    <i class="fa fa-cubes" aria-hidden="true"></i>
				                            		<span>Section</span>
				                                </a>
				                            </li>
                                            <?php } ?>
                                            
                                         </ul>
                                       </li>
				                </ul>
				            </nav>
				
				            <hr class="separator" />
				        </div>
				    </div>
				
				</aside>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2><i class="<?php inventory_display($title_array[$page]['icon'])?>" aria-hidden="true"></i> <?php inventory_display($title_array[$page]['heading'])?></h2>
					</header>