$(document).ready(function(){
	//alert('gg');
	$( "#datepicker,#datepicker2,#datepicker3,#datepicker4" ).datepicker({ dateFormat: 'yy-mm-dd' });
	jQuery.validator.addMethod("specialChars", function( value, element ) {
        var regex = new RegExp("^[a-zA-Z0-9 ]+$");
        var key = value;
		if(value != ""){
			if (!regex.test(key)) {
			   return false;
			}
		}
        return true;
    }, "please use only alphanumeric or alphabetic characters");
	jQuery.validator.addMethod("specialChars1", function( value, element ) {
        var regex = new RegExp("^[a-zA-Z0-9]+$");
        var key = value;
		if(value != ""){
			if (!regex.test(key)) {
			   return false;
			}
		}
        return true;
    }, "please use only alphanumeric or alphabetic characters");
	jQuery.validator.addMethod("charOnly", function( value, element ) {
        var regex = new RegExp("^[a-zA-Z ]+$");
        var key = value;
		if(value != ""){
			if (!regex.test(key)) {
			   return false;
			}
		}
        return true;
    }, "please use only alphabetic characters");
	jQuery.validator.addMethod("validDL", function( value, element ) {
        var regex = new RegExp("^[A-Za-z]{2}[0-9]{13}$");
        var key = value;
		if(value != ""){
			if (!regex.test(key)) {
			   return false;
			}
		}
        return true;
    }, "please enter valid driving licence number");
	jQuery.validator.addMethod("ValidCar", function( value, element ) {
        var regex = new RegExp("^[A-Z]{2}[ -][0-9]{1,2}(?: [A-Z])?(?: [A-Z]*)? [0-9]{4}$");
        var key = value;
		if(value != ""){
			if (!regex.test(key)) {
			   return false;
			}
		}
        return true;
    }, "Enter a valid car number");
	jQuery.validator.addMethod("ValidMob", function( value, element ) {
        var regex = new RegExp("^[7-9][0-9]{9}$");
        var key = value;
		if(value != ""){
			if (!regex.test(key)) {
			   return false;
			}
		}
        return true;
    }, "Enter a valid Mobie number");
	jQuery.validator.addMethod("ValidNum", function( value, element ) {
        var regex = new RegExp("/^\d+(\.\d{1,2})?$/");
        var key = value;
		if(value != ""){
			if (!regex.test(key)) {
			   return false;
			}
		}
        return true;
    }, "Enter a valid Number");
	jQuery.validator.addMethod("custom_required", function( value, element ) {
       if($('#device_type').val()=="mobile"){
		  if(value == ""){
			 return false; 
		  }
	   }
		return true; 
    }, "This Field is Required");
	jQuery.validator.addMethod("equal_to_custom", function( value, element ) {
       if($('#device_type').val()=="mobile"){
		  if(value != $('#password').val()){
			 return false; 
		  }
	   }
		return true; 
    }, "Enter same value again");
	jQuery.validator.addMethod("notEqual", function(value, element, param) {
	  return this.optional(element) || value != $(param).val();
	}, "Please specify a different value");
	
	$.validator.addMethod("email", function(value, element) {
	
	   
	    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
       	if(value == ''){
			return true;
		}else{
	    	return pattern.test(value);
		}
}, "Please enter valid email address.");
jQuery.validator.addMethod("upload_File_size", function (val, element) {
	   if((element.files).length !== 0){
	  var size = element.files[0].size;
	   // console.log(size);
	  }
	  else{
		 var size = 0; 
	  }
		   if (size > 1000000){
			  // console.log("returning false");
				return false;
		   } else {
			   //console.log("returning true");
			   return true;
		   }
			
	}, "Please Upload a file less than 1MB");
	
	
	
		jQuery.validator.addMethod("upload_File_type", function (val, element) {
		 if((element.files).length !== 0){
			var name = element.files[0].name.toLowerCase();
		 }
		if(val != ''){
			var regex = new RegExp("(.*?)\.(jpg|png|jpeg)$");
			if(!(regex.test(name))) {
				console.log("returning false");
				return false;
			}
			else {
				console.log("returning true");
				return true;
			}
		}
		else{
			return true;
		}
	}, "Please Upload only JPG or PNG or JPEG file.");
	$.validator.addMethod('positiveNumber',
		function (value) { 
			return Number(value) > 0;
		}, 'Enter a positive number.');
		
	$("#log_in_form").validate({
		rules: {
			username: {
				required: true,
				maxlength: 20,
				minlength: 4
        	},
			password: {
				required: true,
				maxlength: 20,
				minlength: 4
        	}
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	 
	if($('#datatable-default').length){
	  $('#datatable-default').dataTable({
		dom: '<"row"<"col-lg-6"l><"col-lg-6"f>><"table-responsive"t>p',
		"order": [],
		"searching": false
	  }); 
	}
	if($('#datatable_with_search').length){
	  $('#datatable_with_search').dataTable({
		dom: '<"row"<"col-lg-6"l><"col-lg-6"f>><"table-responsive"t>p',
		"order": [],
	  }); 
	}
	$("#add_department_form").validate({
		rules: {
			dept_id: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars1: true,
        	},
			dept_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				charOnly: true
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	$("#edit_department_form").validate({
		rules: {
			dept_id: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars1: true,
        	},
			dept_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				charOnly: true
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	$("#add_category_form").validate({
		rules: {
			category_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars: true,
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	$("#edit_category_form").validate({
		rules: {
			category_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars: true,
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	$("#add_subcategory_form").validate({
		rules: {
			category: {
				required: true,
        	},
			subcategory_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars: true,
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	$("#edit_subcategory_form").validate({
		rules: {
			category: {
				required: true,
        	},
			subcategory_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars: true,
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	$("#add_tax_form").validate({
		rules: {
			sgst: {
				required: true,
				maxlength: 5,
				minlength: 1,
				number: true,
				min: 1
        	},
			cgst: {
				required: true,
				maxlength: 5,
				minlength: 1,
				number: true,
				min: 1
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	$("#edit_tax_form").validate({
		rules: {
			sgst: {
				required: true,
				maxlength: 5,
				minlength: 1,
				number: true,
				min: 1
        	},
			cgst: {
				required: true,
				maxlength: 5,
				minlength: 1,
				number: true,
				min: 1
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	 $('#is_stockable').change(function() {
        if($(this).is(":checked")) {
            $("#sotockable_div").show();
        }else{
			 $("#sotockable_div").hide();
		}
    });
	$("#item_category").on('change', function() {
		//get the selected value
		var selectedValue = this.value;
		//make the ajax call
		$.ajax({
			url: 'getsubcategory',
			type: 'POST',
			data: {category : selectedValue},
			success: function(data) {
				$('#sub_category_div').html(data);
				(function($) {

					'use strict';
				
					if ( $.isFunction($.fn[ 'select2' ]) ) {
				
						$(function() {
							$('[data-plugin-selectTwo]').each(function() {
								var $this = $( this ),
									opts = {};
				
								var pluginOptions = $this.data('plugin-options');
								if (pluginOptions)
									opts = pluginOptions;
				
								$this.themePluginSelect2(opts);
							});
						});
				
					}
				
				}).apply(this, [jQuery]);
			}
		});
	});
	$("#add_item_form").validate({
		ignore: ':hidden',
		rules: {
			item_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars: true,
        	},
			category: {
				required: true,
        	},
			subcategory: {
				required: true,
        	},
			item_unit: {
				required: true,
        	},
			price: {
				required: true,
				positiveNumber: true,
        	},
			stock: {
				required: true,
				positiveNumber: true,
        	},
			alert_quantity: {
				required: true,
				positiveNumber: true,
        	},
			tax: {
				required: true,
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	
	/*--------------------------------------------------------------*/
	
	$("#add_hod_form").validate({
		rules: {
			hod_id: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars1: true,
        	},
			hod_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				charOnly: true
        	},
        	hod_user: {
				required: true,
				maxlength: 10,
				minlength: 4,
				charOnly: true
        	},
        	hod_pass: {
				required: true,
				maxlength: 10,
				minlength: 5
				
        	},
        	hod_dep: {
				required: true,
				
				
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	
	
	
	/*------------------Add vendor form -----------------------------------*/
	$("#add_ven_form").validate({
		rules: {
			ven_id: {
				required: true,
				maxlength: 40,
				minlength: 2,
				specialChars1: true,
        	},
			ven_name: {
				required: true,
				maxlength: 40,
				minlength: 2,
				charOnly: true
        	},
        	ven_pin: {
				required: true,
				maxlength: 6,
				minlength: 6
				
        	},
        	hod_pass: {
				required: true,
				maxlength: 10,
				minlength: 5
				
        	},
        	hod_dep: {
				required: true,
				
				
        	},
    	},
		highlight: function( label ) {
			$(label).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function( label ) {
			$(label).closest('.form-group').removeClass('has-error');
			label.remove();
		},
		errorPlacement: function( error, element ) {
			var placement = element.closest('.input-group');
			if (!placement.get(0)) {
				placement = element;
			}
			if (error.text() !== '') {
				placement.after(error);
			}
		}
	});
	
	
	/*  item select change */
		
	
	
	
	
	
	
	
	
	
	(function() {
		if( $('#flotBars').get(0) ) {
			var plot = $.plot('#flotBars', [flotBarsData], {
				colors: ['#8CC9E8'],
				series: {
					bars: {
						show: true,
						barWidth: 0.8,
						align: 'center'
					}
				},
				xaxis: {
					mode: 'categories',
					tickLength: 0
				},
				grid: {
					hoverable: true,
					clickable: true,
					borderColor: 'rgba(0,0,0,0.1)',
					borderWidth: 1,
					labelMargin: 15,
					backgroundColor: 'transparent'
				},
				tooltip: true,
				tooltipOpts: {
					content: '%y',
					shifts: {
						x: -10,
						y: 20
					},
					defaultTheme: false
				}
			});
		}
	})();
});

